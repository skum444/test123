package com.stepdef.businessDetails;



import java.util.Map;

import com.jayway.restassured.response.Response;
import com.rbs.pages.Service;
import com.rbs.pages.ServiceURLAndInputs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefinition01 {
	
	ServiceURLAndInputs serviceInputs;
	Map<String, String> dataMap;
	Service serURL;
	Response servResponse;
	
	@Given("^To Access the micro service \"([^\"]*)\" for \"([^\"]*)\"$")
	public void to_Access_the_micro_service_for(String msName, String sceNum) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		serviceInputs=new ServiceURLAndInputs();
		dataMap = serviceInputs.getScenarioDetails(msName, sceNum);
	}

	@When("^The service request for \"([^\"]*)\" is passed to the \"([^\"]*)\" microservice and response is obtained$")
	public void service_request_passed_to_service(String sceNum,String msName) throws Throwable {
		serURL = new Service();
		servResponse=serURL.postURL(msName,sceNum,dataMap);
	}

	@Then("^Validate the response of the \"([^\"]*)\" microservice and update \"([^\"]*)\" test result$")
	public void validate_the_response_of_the_microservice_and_update_test_result(String msName, String sceNum) throws Throwable {
		serURL.valiateResponse(msName,sceNum,servResponse,dataMap);
	    System.out.println(msName+": End of Scenario::"+sceNum);
	}
}
