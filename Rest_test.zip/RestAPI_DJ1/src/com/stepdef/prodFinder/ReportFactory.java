package com.stepdef.prodFinder;

import com.relevantcodes.extentreports.ExtentReports;

public class ReportFactory {
	private static ExtentReports reporter;
	public static String extentReportFile = "C:\\TEMP\\ExtentReports\\extentReportFile.html";
	
	public static ExtentReports getreporter()
	{
		 
		if(reporter==null)
		{
		 reporter = new ExtentReports(extentReportFile, true);
		
		}
		return reporter;
	}
		public static void closereporter()
		{
			reporter.flush();
			reporter.close();
	}

}
