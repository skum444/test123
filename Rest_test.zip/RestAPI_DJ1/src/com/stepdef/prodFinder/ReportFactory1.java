package com.stepdef.prodFinder;

import com.relevantcodes.extentreports.ExtentReports;

public class ReportFactory1 {
	private static ExtentReports reporter;
	
	public static ExtentReports getreporter(String testName)
	
	
	{
		 String extentReportFile = "C:\\TEMP\\ExtentReports\\extentReportFile_"+testName+".html";
		//String extentReportFile = "C:\\TEMP\\ExtentReports\\extentReportFileTS.html";
		 reporter = new ExtentReports(extentReportFile, true);
		
		
		return reporter;
	}
		public static void closereporter()
		{
			reporter.flush();
			reporter.close();
	}

}
