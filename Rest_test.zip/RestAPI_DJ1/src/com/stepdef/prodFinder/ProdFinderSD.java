package com.stepdef.prodFinder;

import java.io.*;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.jayway.restassured.response.Response;
import com.rbs.automation.commonutils.CSVDBUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.bpm.automation.bbconnect.tests.TestBase;
import com.rbs.pages.BusinessBankingLoginPage1;
import com.rbs.pages.BusinessBankingLoginPage2;
import com.rbs.pages.ScrProcessPortal;
import com.rbs.pages.Service;
import com.rbs.pages.ServiceURLAndInputs;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.*;

public class ProdFinderSD extends TestBase {

	static ScrProcessPortal processPortal = null;

	static String sheetName = null;
	String currentXml = null;
	ServiceURLAndInputs serviceInputs;
	Map<String, String> dataMap;
	Service serURL;
	Response servResponse;
	WebDriver driver;
	public ExtentReports extent = ReportFactory.getreporter();
	public ExtentTest extentTestSce;
	public static ExtentReports extentTS;
	public String ScenarioStatus;
	BusinessBankingLoginPage1 loginPage = new BusinessBankingLoginPage1();
	BusinessBankingLoginPage2 loginPage2 = new BusinessBankingLoginPage2();

	public static String Reg_Brand;

	@Given("^URL has been launched for the \"([^\"]*)\" for the \"([^\"]*)\"$")
	public void url_has_been_launched_for_the_for_the(String testName, String RegBrand) throws Throwable {
		String TN = "ScenarioNo:" + testName;
		extentTestSce = extent.startTest(TN, "BB Regression Scenario");
		extentTS = ReportFactory1.getreporter(testName);
		String Ts1 = testName + "_ApplicationHomePage";
		ExtentTest extent1 = extentTS.startTest(Ts1, "Verify BBApplication Launch is succesful");

		processPortal = new ScrProcessPortal();
		processPortal.OpenURL(RegBrand);
		Reg_Brand = RegBrand;
		extent1.log(LogStatus.PASS, RegBrand + "Browser Launched is succesful");
		extentTS.endTest(extent1);
		extentTS.flush();
	}

	@When("^customer Number is entered in Business Banking Login page one for the coresponding \"([^\"]*)\" of the \"([^\"]*)\" and clicks on continue button\\.$")
	public void customer_Number_is_entered_in_Business_Banking_Login_page_one_for_the_coresponding_and_clicks_on_continue_button(
			String testName, String sheetName) throws Throwable {
		setupTestSuite(testName);
		loginPage.inputCustomerID(testName,sheetName);
		String Ts1 = testName + "loginPage1";
		ExtentTest extent1 = extentTS.startTest(Ts1, "User enters DBID in the BBconnect_Login1_page");
		String Pagestatus = loginPage.Status;
		reportUpdate(Pagestatus, "loginPage1", testName, extent1);
		extentTS.endTest(extent1);
		extentTS.flush();

	}

	@Then("^user enters Business Banking Login page two\\.$")
	public void user_enters_Business_Banking_Login_page_two() throws Throwable {
		if (loginPage.Status == "Pass") {
			System.out.println("BB login1 page details updated successfully");
		}
	}

	@When("^Customer enters the security code and password for the \"([^\"]*)\" and clicks on login button for \"([^\"]*)\", cookie is generated for \"([^\"]*)\"$")
	public void customer_enters_the_security_code_and_password_for_the_and_clicks_on_login_button(String sTestName,
			String rownum, String sheetName) throws Throwable {
		System.out.println("----------------Sheet Name----------"+sheetName);
		if (loginPage.Status == "Pass") {
			loginPage2.inputValuesInBBlogin2Page(sTestName, rownum,sheetName);
			String Ts1 = sTestName + "loginPage2";
			ExtentTest extent1 = extentTS.startTest(Ts1,
					"User enters security pin details in the BBconnect_Login2_page");
			String Pagestatus = loginPage2.Status;
			reportUpdate(Pagestatus, "loginPage2", sTestName, extent1);
			extentTS.endTest(extent1);
			extentTS.flush();
		}

	}

	@Then("^Welcome page opens successfully\\.$")
	public void welcome_page_opens_successfully() throws Throwable {
		if (loginPage2.Status == "Pass") {
			System.out.println("BB login2 page details updated successfully");
		}
	}

	@When("^To Access the micro service \"([^\"]*)\" for \"([^\"]*)\"$")
	public void to_Access_the_micro_service_for(String msName, String sceNum) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		serviceInputs = new ServiceURLAndInputs();
		dataMap = serviceInputs.getScenarioDetails(msName, sceNum);
	}

	@When("^The service request for \"([^\"]*)\" is passed to the \"([^\"]*)\" microservice and response is obtained$")
	public void service_request_passed_to_service(String sceNum, String msName) throws Throwable {
		processPortal.closebrower();
		serURL = new Service();
		if(msName.equals("Purpose")){
			servResponse = serURL.getURL(msName, sceNum, dataMap);
		}else if(msName.equals("SubPurpose")||msName.equals("BorrowingNeeds")){
			servResponse = serURL.postURL(msName, sceNum, dataMap);
		}
	}

	@Then("^Validate the response of the \"([^\"]*)\" microservice and update \"([^\"]*)\" test result$")
	public void validate_the_response_of_the_microservice_and_update_test_result(String msName, String sceNum)
			throws Throwable {
		serURL.valiateResponse(msName, sceNum, servResponse, dataMap);
		System.out.println(msName + ": End of Scenario::" + sceNum);
	}

	public void setupTestSuite(String testName) throws FileNotFoundException, IOException, InterruptedException {

		// StafLogger.LogMessage.initReporter();
		// Logger.LogMessage("Entering setup suite");

		Logger.initLogger();
		// Logger.LogMessage("Entering Before Suite");

		ReporterA.initReporter(testName);
		CSVDBUtils.initConnection();
		// Logger.LogMessage("Exiting Before Suite");
		// Logger.LogMessage("exiting setup suite");

		// processPortal = new ScrProcessPortal();
	}

	public void reportUpdate(String Pagestatus, String Pagename, String testName, ExtentTest extent1) {
		if (Pagestatus.equalsIgnoreCase("Pass")) {
			extent1.log(LogStatus.PASS, "User input details in the " + Pagename + "_page ");
		} else if (Pagestatus.equalsIgnoreCase("Fail")) {
			extent1.log(LogStatus.FAIL, "Exception Occured in the " + Pagename + "_page");
			extentTestSce.log(LogStatus.FAIL, testName + " is not succesful" + "Exception Occured in " + Pagename
					+ "_page while creating the Application");

		}
	}
	/*
	@When("^The service request for \"([^\"]*)\" is passed to the SubPurpose \"([^\"]*)\" microservice and response is obtained$")
	public void service_request_passed_to_SubPurposeservice(String scenario, String serviceName) throws Throwable {
		processPortal.closebrower();
		serURL = new Service();
		servResponse = serURL.postSubPurpose(serviceName, scenario, dataMap);
	}
	*/


}
