package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class CustomerSearchPageObjects extends BasePage{
	
	
	//By.xpath("//div[contains(text(),'‪Account Opening Process Id')]']")
	
	/*private By radioTradingAddress = By.xpath("//div[contains(@class,'Table  CoachView BPMTable')]//div[@class='dojoxGridRow' or @class='dojoxGridRow dojoxGridRowOdd'][1]//td[1]/div");
	private By radioTradingAddress1 = By.xpath("//div[contains(@class,'Table  CoachView BPMTable')]//div[@class='dojoxGridRow' or @class='dojoxGridRow dojoxGridRowOdd']//td[5]/div//span[contains(text(),'"+expRadioText+"')]/../../../../../../td[1]/div");
	*/
	
	public WebElement selectCust() {
		
		//return driver.findElement(By.xpath("//div[contains(@class,'Table  CoachView BPMTable')]//div[@class='dojoxGridRow' or @class='dojoxGridRow dojoxGridRowOdd']//td[5]/div//span[contains(text(),'"+expTradingDesc+"')]/../../../../../../td[1]/div"));
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitRadio')]"));
		return expRB;
		
	}
	
}
