package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class ApplicationBasketPageObjects extends BasePage{
	
	
	
	
	public WebElement selectfacil() {
		
		//return driver.findElement(By.xpath("//div[contains(@class,'Table  CoachView BPMTable')]//div[@class='dojoxGridRow' or @class='dojoxGridRow dojoxGridRowOdd']//td[5]/div//span[contains(text(),'"+expTradingDesc+"')]/../../../../../../td[1]/div"));
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-binding,'facilityTableHTML')]//input[@type='radio']"));
		return expRB;
		
	}
	

	public WebElement selectfacilBasedOnFacNAme(String FacName) {
		//a[text()='01_Fac']/../preceding-sibling::td//input
		
		WebElement expRB = driver.findElement(By.xpath("//a[text()='"+FacName+"']/../preceding-sibling::td//input[@type='radio']"));
		return expRB;
		
	}
	
public WebElement alertMsg() {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'Confirm Borrowing Requirements')]/../..//div[contains(@class,'dijitDialogPaneContent')]//button[text()='Yes']"));
		return expRB;
		
	}
	
}
