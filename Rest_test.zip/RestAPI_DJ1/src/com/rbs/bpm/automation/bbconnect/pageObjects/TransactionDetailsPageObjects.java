package com.rbs.bpm.automation.bbconnect.pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class TransactionDetailsPageObjects extends BasePage{
	
	
	
	public WebElement selectRetailBuyToLet(String expradiobutton) {
		
		
		WebElement expRB = driver.findElement(By.xpath("//a[text()='Retail Buy to Let']/ancestor::div[contains(@class,'Vertical_Section  CoachView BPMSection BPMHSectionChild CoachView_show')]/following-sibling::div//div[contains(@class,'dojoxCheckedMultiSelectWrapper')]//div[contains(@class,'dijitInline dojoxMultiSelectItemLabel')][text()='"+expradiobutton+"']/preceding-sibling::div/input"));
		return expRB;
		
	}
	
public WebElement alertMsg() {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'CCA Alert')]/../..//div[contains(@class,'dijitDialogPaneContent')]//button[text()='Close']"));
		return expRB;
		
	}
	
public WebElement elementfind() {
	
	
	WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'CCA Alert')]"));
	return expRB;
	
}
	
}
