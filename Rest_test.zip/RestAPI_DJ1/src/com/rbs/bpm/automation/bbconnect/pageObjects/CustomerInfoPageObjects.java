package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class CustomerInfoPageObjects extends BasePage{
	
	
	
	
	public WebElement selectCustomerInfo(String codedesc) {
		
		
		List<WebElement> expRB = driver.findElements(By.xpath("//div[contains(@data-binding,'local.sicSearchResults[]')]//div[contains(@data-binding,'local.sicSearchResults[index]')]//span[contains(text(),'"+codedesc+"')]/../preceding::div[contains(@class,'dojoxGridRowSelector dijitReset')]"));
		if(expRB.size()>1)
		{
			return expRB.get(1);
		}
		else
		{
		return expRB.get(0);
		}
	}
	


public WebElement selectCustomerInfoSearch(String cin) {
	
	
	WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-binding,'local.searchResults[index].CIN')]//span[contains(text(),'"+cin+"')]/../preceding::div[contains(@class,'dojoxGridRowSelector dijitReset')]"));
	return expRB;
	
}

public WebElement alertMsg() {
	
	
	WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'Link the New to bank customer')]/../..//div[contains(@class,'dijitDialogPaneContent')]//button[text()='Yes']"));
	return expRB;
	
}

}


