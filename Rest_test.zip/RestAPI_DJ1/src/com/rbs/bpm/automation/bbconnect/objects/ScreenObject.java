package com.rbs.bpm.automation.bbconnect.objects;

public class ScreenObject {
	public String logicalName;
	public String identifier;
}
