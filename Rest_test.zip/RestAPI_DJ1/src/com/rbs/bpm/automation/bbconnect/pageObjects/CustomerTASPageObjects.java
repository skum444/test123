package com.rbs.bpm.automation.bbconnect.pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class CustomerTASPageObjects extends BasePage{
	
	
	
	public WebElement selectCustOpSale(String expradiobutton) {
		
		
		WebElement expRB = driver.findElement(By.xpath("//a[text()='new to bank']/ancestor::div[contains(@class,'Horizontal_Section  CoachView BPMSection BPMHSectionChild CoachView_show')]/following-sibling::div//div[contains(@class,'dojoxCheckedMultiSelectWrapper')]//div[contains(@class,'dijitInline dojoxMultiSelectItemLabel')][text()='"+expradiobutton+"']/preceding-sibling::div/input"));
		return expRB;
		
	}
	
}
