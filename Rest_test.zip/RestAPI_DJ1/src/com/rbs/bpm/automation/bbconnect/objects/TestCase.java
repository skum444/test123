package com.rbs.bpm.automation.bbconnect.objects;

import java.util.HashMap;

import com.rbs.automation.commonutils.GenericUtils;

public class TestCase {
	
	private static HashMap<String, String> innerTable = null;
	private HashMap<String, HashMap<String,String>> testData = new HashMap<String, HashMap<String,String>>();
	
	private String name;
	private String startTime;
	private String endtime;
	private String status;
	private String browser;
	private Integer iteration;
	private String resultFolder;
	private String description;
	private String e2eSetName;
	
	public static String TestName;
	public static String TestE2ESetName;
		
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((browser == null) ? 0 : browser.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestCase other = (TestCase) obj;
		
//		if (browser == null) {
//			if (other.browser != null)
//				return false;
//		} 
//		else if (!browser.equals(other.browser))
//			return false;
		
		if (e2eSetName == null) {
			if (other.e2eSetName != null)
				return false;
		} else if (!e2eSetName.equals(other.e2eSetName))
			return false;
		
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public TestCase() {
		
	}
	
	public TestCase(String name) {
		setName(name);
		setStartTime(GenericUtils.getDateTime());
	}
	
	
	public TestCase(String name, String browser) {
		setName(name);
		setStartTime(GenericUtils.getDateTime());
		setBrowser(browser);
	}
	
	public HashMap<String, HashMap<String,String>> getTestData() {
		return testData;
	}

	public void setTestData(HashMap<String, HashMap<String,String>> testData) {
		this.testData = testData;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		TestName = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public Integer getIteration() {
		return iteration;
	}

	public void setIteration(Integer iteration) {
		this.iteration = iteration;
	}

	public String getResultFolder() {
		return resultFolder;
	}

	public void setResultFolder(String resultFolder) {
		this.resultFolder = resultFolder;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getE2eSetName() {
		return e2eSetName;
	}

	public void setE2eSetName(String e2eSetName) {
		this.e2eSetName = e2eSetName;
		TestE2ESetName=e2eSetName;
	}
	
	
}