package com.rbs.bpm.automation.bbconnect.objects;

import java.sql.Timestamp;

public class Step{
		private String sDesc;
		private String sStatus;
		private String sExpected;
		private String sActual;
		private String sExecutionTimestamp;
		private String sSnapshotPath;
		
		Step(String sStepDesc,
				String sStepStatus, String sExpected, String sActual ){
			setsDesc(sStepDesc);
			setsStatus(sStepStatus);
			setsExpected(sExpected);
			setsActual(sActual);
		}
		
		public Step(String sStepDesc,
			String sStepStatus, String sExpected, String sActual,String sSnapshotPath ){
			setsDesc(sStepDesc);
			setsStatus(sStepStatus);
			setsExpected(sExpected);
			setsActual(sActual);
			setsSnapshotPath(sSnapshotPath);
			setsExecutionTimestamp(new Timestamp(System.currentTimeMillis()).toString());
		}

		public String getsDesc() {
			return sDesc;
		}

		public void setsDesc(String sDesc) {
			this.sDesc = sDesc;
		}

		public String getsStatus() {
			return sStatus;
		}

		public void setsStatus(String sStatus) {
			this.sStatus = sStatus;
		}

		public String getsExpected() {
			return sExpected;
		}

		public void setsExpected(String sExpected) {
			this.sExpected = sExpected;
		}

		public String getsActual() {
			return sActual;
		}

		public void setsActual(String sActual) {
			this.sActual = sActual;
		}

		public String getsSnapshotPath() {
			return sSnapshotPath;
		}

		public void setsSnapshotPath(String sSnapshotPath) {
			this.sSnapshotPath = sSnapshotPath;
		}

		public String getsExecutionTimestamp() {
			return sExecutionTimestamp;
		}

		public void setsExecutionTimestamp(String sExecutionTimestamp) {
			this.sExecutionTimestamp = sExecutionTimestamp;
		}





		
	}