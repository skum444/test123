package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class CustomerSummaryPageObjects extends BasePage{
	
	
	
	
	public WebElement selectappfacil(String FacName) {
		
		//return driver.findElement(By.xpath("//div[contains(@class,'Table  CoachView BPMTable')]//div[@class='dojoxGridRow' or @class='dojoxGridRow dojoxGridRowOdd']//td[5]/div//span[contains(text(),'"+expTradingDesc+"')]/../../../../../../td[1]/div"));
	/*	WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-binding,'facilityTableHTML')]//input[@type='radio']"));
		return expRB;*/
		WebElement expRB = driver.findElement(By.xpath("//a[text()='"+FacName+"']/../preceding-sibling::td//input[@type='radio']"));
		return expRB;
		
	}

	
public WebElement prodconfirmMsg() {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'Product Confirmation')]/../..//div[contains(@class,'RBS_Button_Event_with_Boundary')]//button[text()='Yes']"));
		return expRB;
		
	}
	
// bb code - check
public WebElement prodconfirmMsgOverDraft() {
	
	
	WebElement expRB = driver.findElement(By.xpath("//div[contains(@class,'dijitDialog')]/div/span[contains(text(),'Product confirmation')]/../..//div[contains(@class,'RBS_Button_Event_with_Boundary')]//button[text()='Yes']"));
	return expRB;
	
}
	
}
