package com.rbs.bpm.automation.bbconnect.objects;

import java.io.IOException;

public class common 
{
	public static void main(String args[]) throws IOException{
		
		String s = "?Product Review for CPB:5558?";
		System.out.println(s.substring(s.indexOf(":")+1,s.length()-1) );
		
/*		System.out.println(Runtime.class.getPackage().getImplementationVersion());
		
		XWPFDocument docx = new XWPFDocument();  
		XWPFParagraph par = docx.createParagraph();  
		XWPFRun run = par.createRun();
		run.setText("Hello, World. This is my first java generated docx-file. Have fun.");
		run.setFontSize(13);

		InputStream pic = null;
		try {
			pic = new FileInputStream("c:\\temp\\screenshot42888.png");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			byte [] picbytes = IOUtils.toByteArray(pic);
			docx.addPictureData(picbytes, Document.PICTURE_TYPE_JPEG);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		 }
	
	public static void callingFun(){
		System.out.println(Thread.currentThread().getStackTrace()[2].getMethodName());
	}
		
//		DBUtils.initConnection(); 
//		ResultSet rs = DBUtils.getResultSetFromSQL("SELECT Top 1 UserID, Password FROM UserCredentials where UserRole = 'Product Management Professional'");
//		try {
//			while((rs!=null) && (rs.next()))
//			{
//			    System.out.println(rs.getString("UserID") + "||" + rs.getString("Password"));
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		DBUtils.closeConnection();
//	}
}
