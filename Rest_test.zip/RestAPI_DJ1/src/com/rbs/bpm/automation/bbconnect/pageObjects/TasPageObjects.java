package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class TasPageObjects extends BasePage{
	
	
	
	
	public WebElement metricInput(int facilitynumber) {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-bindingrt,'local.sempTASDetails.metricLevelFacility["+facilitynumber+"].metricParameters[0].parameterNameList[]')][contains(@class,'Select  CoachView CoachView_show')]//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
		return expRB;
		
	}
	
public WebElement metricValue(int facilitynumber, int metricparamternumber) {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-bindingrt,'local.sempTASDetails.metricLevelFacility["+facilitynumber+"].metricParameters["+metricparamternumber+"].parameterValue')][contains(@class,'Decimal_TAS_CV pad CoachView BPMHSectionChild CoachView_show')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
		return expRB;
		
	}

	
}
