package com.rbs.bpm.automation.bbconnect.pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class MainApplicantDetailsObj extends BasePage{
	
	
	//By.xpath("//div[contains(text(),'‪Account Opening Process Id')]']")
	
	private By profitExpected = By.xpath("//div[contains(@class,'textLabel')]/label[text()='Provide your actual or anticipated annual profit before tax for this financial year.']/..//following-sibling::div//input[contains(@value,'�')]");
	
	
	//div[contains(@class,'textLabel')]/label[text()='Provide your actual or anticipated annual profit before tax for this financial year.']/..//following-sibling::div//input[contains(@value,'£')]
	
	public WebElement getAnnualProfitWebElement(){
		return driver.findElement(profitExpected);
	}
}
