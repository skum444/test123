package com.rbs.bpm.automation.bbconnect.objects;


import java.net.URI;
import java.util.List;


public class Email {
	public static void main(String [] args) throws Exception {
	   /* ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
	    ExchangeCredentials credentials = new WebCredentials("m01europa\\kartvak","Password1");
	    service.setCredentials(credentials);
	    service.setUrl(new URI("http://11.152.57.57/exchange"));

	    ItemView view = new ItemView (10);
	    FindItemsResults<Item> findResults = service.findItems(WellKnownFolderName.Inbox, view);
	    
	    List<Item> arrItems = findResults.getItems();

	    for(Item item : arrItems){
	      item.load(new PropertySet(BasePropertySet.FirstClassProperties, ItemSchema.MimeContent));
	      System.out.println("id==========" + item.getId());
	      System.out.println("sub==========" + item.getSubject());
	      System.out.println("sub==========" + item.getMimeContent());
	      break;
	      }*/
	    }
}
