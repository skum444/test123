package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class LendingTrackerPageObjects extends BasePage{
	
	
	
	
	
	
public WebElement microIdValue(int microId) {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[contains(@data-bindingrt,'local.microRatesFacilityList["+microId+"].all_in_rate')]//div[contains(@class,'dijitInputField dijitInputContainer')]//input[not(@type='hidden')]"));
		return expRB;
		
	}

	
}
