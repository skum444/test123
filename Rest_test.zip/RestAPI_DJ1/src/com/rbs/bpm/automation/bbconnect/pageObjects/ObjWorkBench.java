package com.rbs.bpm.automation.bbconnect.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.automation.commonutils.Logger;
import com.rbs.pages.BasePage;

public class ObjWorkBench extends BasePage {
	
	private String _sTaskName = null;
	private String _sTaskID = null;
	
	//private By workTabLocator = By.cssSelector("div.processPortalDashboardTabTextDiv:nth-of-type(1)");
	
	private By workTabLocator = By.xpath("div[@title='Work'][text()='Work']");
	private By newAppLocator = By.xpath("//a[text()='Commercial Banking Account Opening']");
	private By searchTaskLocator =  By.id("com_ibm_bpm_social_widgets_task_list_SearchBar_0_input");
	private By claimTaskLocator = By.xpath("//button[text()='Claim Task']");
	//private By taskLinkLocator = By.xpath("//a[contains(text(),'"+ _sTaskName + _sTaskID + "')]");
	private By frameGettingStarted = By.xpath("//iframe[@title='Capture Application Details']");
	private By noTaskFoundLocator = By.xpath("//div/text()='No tasks were found.'");
	
	private By frmCompleteAccountCreationLocator = By.xpath("//iframe[contains(@title,'Complete Account Application For')]");
	private By btnNextLocator= By.xpath("//button[text()='Next']");
	private By btnSaveLocator= By.xpath("//button[text()='Save and Exit']");
	private By btnCancelLocator= By.xpath("//button[text()='Cancel Application']");
	private By btnProgressSummaryLocator= By.xpath("//button[text()='Progress Summary']");
	
	public ObjWorkBench() {

	}

	public WebElement getWorkTabWebElement() {
		return driver.findElement(workTabLocator);
	}

	public WebElement getNewAppWebElement() {
		return driver.findElement(newAppLocator);
	}

	public WebElement getSearchTaskWebElement() {
		return driver.findElement(searchTaskLocator);
	}

	public WebElement getClaimTaskWebElement() {
		return driver.findElement(claimTaskLocator);
	}
	
	public WebElement getFrameGettingStarted() {
		return driver.findElement(frameGettingStarted);
	}

	public By getWorkTabLocator() {
		return workTabLocator;
	}

	public By getNewAppLocator() {
		return newAppLocator;
	}

	public By getSearchTaskLocator() {
		return searchTaskLocator;
	}

	public By getClaimTaskLocator() {
		return claimTaskLocator;
	}

	public By getTaskLocatorByNameAndID(String sTaskName, String sTaskID) {
		this._sTaskName =  sTaskName;
		this._sTaskID = sTaskID;
		
		return By.xpath("//div/span[text()[contains(.,'" + this._sTaskID + "')]]/../..//a[text()='" + this._sTaskName + "']");
	}
		

	public By getFrameGettingStartedLocator() {
		return frameGettingStarted;
	}

	public By getNoTaskFoundLocator() {
		return noTaskFoundLocator;
	}
	
	public WebElement getFrmCompleteAccountCreationWebElement() {
		return driver.findElement(frmCompleteAccountCreationLocator);
	}
	
	public WebElement getBtnNextWebElement() {
		return driver.findElement(btnNextLocator);
	}
	public WebElement getBtnSaveWebElement() {
		return driver.findElement(btnSaveLocator);
	}
	public WebElement getBtnCancelWebElement() {
		return driver.findElement(btnCancelLocator);
	}
	public WebElement getBtnProgressSummaryWebElement() {
		return driver.findElement(btnProgressSummaryLocator);
	} 
	
}
