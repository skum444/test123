package com.rbs.bpm.automation.bbconnect.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.rbs.pages.BasePage;

public class PropertyValuePageObjects extends BasePage{
	
	
	
	
	public WebElement noPostCodeAvailable() {
		
		
		WebElement expRB = driver.findElement(By.xpath("//div[@class='RBS_Vertical_Section  CoachView BPMSection CoachView_show']//h2[text()='Property address']/..//label[text()='No postcode available']/..//input[@type='checkbox']"));
		return expRB;
		
	}
	

	
}
