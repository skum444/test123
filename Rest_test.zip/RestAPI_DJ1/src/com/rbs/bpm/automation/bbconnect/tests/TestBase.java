package com.rbs.bpm.automation.bbconnect.tests;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;

import com.rbs.automation.commonutils.CSVDBUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.bpm.automation.bbconnect.objects.TestCase;
import com.rbs.pages.ScrProcessPortal;

public class TestBase {
	
	static String sheetName = null;
	
public String getSheetName(String scenum ){
		
		String scenarioNumber = scenum.replaceAll("[^0-9]+", "").trim();
		sheetName = "RegressionScenario"+scenarioNumber;
		System.out.println("Sheet Name Executing---"+sheetName);
		return sheetName;
	}

	/*protected ScrProcessPortal processPortal;
	static String sheetName = null;
	TestCase currentTest;
	String currentXml = null;

	*//**
	 * @author Vermavn This functions will be called once before execution of
	 *         test methods in this class. It will setup initalise the logger,
	 *         Reporter and DB connection
	 * @throws InterruptedException 
	 *//*
	@BeforeSuite(alwaysRun = true)
	protected void setupTestSuite() throws FileNotFoundException, IOException, InterruptedException {

		// StafLogger.LogMessage.initReporter();
		Logger.LogMessage("Entering setup suite");

		Logger.initLogger();
		Logger.LogMessage("Entering Before Suite");

		//ReporterA.initReporter();
		CSVDBUtils.initConnection();
		Logger.LogMessage("Exiting Before Suite");
		Logger.LogMessage("exiting setup suite");
		
		//processPortal = new ScrProcessPortal();
	}

	//@BeforeTest
	protected void setupTest(@Optional("chrome") String Browser, ITestContext context) throws Exception {

		//Logger.LogMessage("Entering BeforeMethod with Browser " + Browser);
		//System.setProperty("browser", Browser);

		if (null == currentTest) {
			currentTest = new TestCase();
		}

		currentTest.setE2eSetName(context.getName());
		//currentTest.setName(M.getName());
		//currentTest.setDescription(M.getAnnotation(Test.class).description());
		currentTest.setStartTime(GenericUtils.getDateTime());
		currentTest.setBrowser(Browser);

		ReporterA.initTest(currentTest);

		//processPortal = new ScrProcessPortal();
		Logger.LogMessage("Exiting BeforeMethod");
	}
	
	@Parameters("browser")
	@BeforeMethod(alwaysRun = true)
	protected void setupTest(Method M,@Optional("chrome") String Browser, ITestContext context) throws Exception {

		Logger.LogMessage("Entering BeforeMethod with Browser " + Browser);
		System.setProperty("browser", Browser);

		if (null == currentTest) {
			currentTest = new TestCase();
		}

		currentTest.setE2eSetName(context.getName());
		currentTest.setName(M.getName());
		currentTest.setDescription(M.getAnnotation(Test.class).description());
		currentTest.setStartTime(GenericUtils.getDateTime());
		currentTest.setBrowser(Browser);

		ReporterA.initTest(currentTest);

		processPortal = new ScrProcessPortal();
		Logger.LogMessage("Exiting BeforeMethod");
	}
	
	
	public String getSheetName(String scenum ){
		
		String scenarioNumber = scenum.replaceAll("[^0-9]+", "").trim();
		sheetName = "RegressionScenario"+scenarioNumber;
		System.out.println("Sheet Name Executing---"+sheetName);
		return sheetName;
	}
	
	@BeforeTest
	public void getCurrentScenario(ITestContext suite){
		//System.out.println(suite.getName());
		//System.out.println(suite.getCurrentXmlTest().getSuite().getName());
		System.out.println(suite.getCurrentXmlTest().getSuite().getFileName().length());
		int suiteFileLength = suite.getCurrentXmlTest().getSuite().getFileName().length();
		System.out.println(suite.getCurrentXmlTest().getSuite().getFileName().substring(suiteFileLength-17, suiteFileLength));
		currentXml = suite.getCurrentXmlTest().getSuite().getFileName().substring(suiteFileLength-17, suiteFileLength);
		String scenarioNumber = currentXml.replaceAll("[^0-9]+", "").trim();
		sheetName = "RegressionScenario"+scenarioNumber;
		System.out.println("Sheet Name Executing---"+sheetName);
		
	}
	@Parameters("browser")
	@BeforeTest
	protected void setupTest(@Optional String Browser, ITestContext context) throws Exception {

		Logger.LogMessage("Entering BeforeMethod with Browser " + Browser);
		System.setProperty("browser", Browser);

		if (null == currentTest) {
			currentTest = new TestCase();
		}

		currentTest.setE2eSetName(context.getName());
		//currentTest.setName(M.getName());
		//System.out.println("method name is---"+M.getName());
		//currentTest.setDescription(M.getAnnotation(Test.class).description());
		currentTest.setStartTime(GenericUtils.getDateTime());
		currentTest.setBrowser(Browser);

		ReporterA.initTest(currentTest);

		//processPortal = new ScrProcessPortal();
		Logger.LogMessage("Exiting BeforeMethod");
	}

	*//**
	 * @author Vermavn
	 * this function will run after execution of each test
	 *         method of this class and will populate the execution end time,
	 *         close the browser
	 * @throws Exception
	 *//*
	@AfterMethod(alwaysRun = true)
	protected void tearDownTest(ITestResult result) throws Exception {

		Logger.LogMessage("Entering tearDownTest");
		currentTest.setEndtime(GenericUtils.getDateTime());

		Logger.LogMessage("Status:" + currentTest.getStatus());
		Logger.LogMessage("ITestResult.SUCCESS:" + ITestResult.SUCCESS);

		if (result.getStatus() == ITestResult.SKIP) {
			ReporterA.reportFail("Validate pre-requisite test status", "Should be passed", "Either failed or skipped");
			currentTest.setStatus("Skipped");
		}

		//processPortal.finishTest();
		ReporterA.saveTestResultsToXML();
		CSVDBUtils.closeConnection();
		Logger.LogMessage("Exiting tearDownTest");

	}
	@AfterTest	
	protected void tearDownTest(ITestResult result) throws Exception {

		Logger.LogMessage("Entering tearDownTest");
		currentTest.setEndtime(GenericUtils.getDateTime());

		Logger.LogMessage("Status:" + currentTest.getStatus());
		Logger.LogMessage("ITestResult.SUCCESS:" + ITestResult.SUCCESS);

		if (result.getStatus() == ITestResult.SKIP) {
			ReporterA.reportFail("Validate pre-requisite test status", "Should be passed", "Either failed or skipped");
			currentTest.setStatus("Skipped");
		}

		//processPortal.finishTest();
		ReporterA.saveTestResultsToXML();
		CSVDBUtils.closeConnection();
		Logger.LogMessage("Exiting tearDownTest");

	}
	*//**
	 * @author Vermavn this test will run once after execution off all test
	 *         methods in this class it will generate & save the execution
	 *         report in xml and html formats
	 * @throws Exception
	 * 
	 *//*
	@AfterSuite(alwaysRun = true)
	protected void tearDownTestSuite() throws Exception {
		
		ReporterA.saveBatchResultsToXML();
	}*/

}
