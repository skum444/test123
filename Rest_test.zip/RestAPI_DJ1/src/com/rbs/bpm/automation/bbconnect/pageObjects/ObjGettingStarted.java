package com.rbs.bpm.automation.bbconnect.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;


/**
 * @author: Mercy - this is Object dEfinition File for Getting sTarted screen
 * @Date: 22/Dec/2015
 * @Revision: **/

public class ObjGettingStarted extends BasePage {

	public ObjGettingStarted() {

	}
	
	private String _sTypeOfEntity ;
	
	private By frmCaptureApplicationLocator = By.cssSelector("iframe[title='Capture Application Details']");
	
	private By txtTitleLocator = By.xpath("//h2[text()='Getting started']");
	
	private By lstBrandLocator = By.xpath("//label[text()='Please select a brand']/../following-sibling::div//input[@tabindex!='-1']");
	
	private By radgrpAccountBasedInScotlandLocator = By.xpath("//label[text()='Do you wish to open your account in a branch based in Scotland?']/../following-sibling::div//input[@type='radio']");
	private By radgrpExistingRbsAccountHolderLocator = By.xpath("//label[text()='Are you an existing RBS business account holder?']/../following-sibling::div//input[@type='radio']");
	private By radgrpExistingNatwestAccountHolderLocator = By.xpath("//label[text()='Are you an existing NatWest business account holder?']/../following-sibling::div//input[@type='radio']");
	
	private By lstEntityLocator = By.xpath("//label[text()='What type of legal entity is the customer?']/../following-sibling::div//input[@tabindex!='-1']");
	//private By lstSubEntityLocator = By.xpath("//label[text()='Please specify what type of "+ this._sTypeOfEntity + " it is']/../following-sibling::div//input[@tabindex!='-1']");
	
	private By lstMainAccLocator = By.xpath("//label[text()='What type of business account do you require?']/../following-sibling::div//input[@tabindex!='-1']");
	private By lstAccTypeLocator = By.xpath("//label[text()='Please choose from the following options']/../following-sibling::div//input[@tabindex!='-1']");
	
	private By radgrpLendingRelatedLocator = By.xpath("//label[text()='Does this application relate to a Lending Account?']/../following-sibling::div//input[@type='radio']");
	
	private By edtDepositRefNumLocator = By.xpath("//label[text()='Please enter the Deposit Finder Reference Number']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtLendingRefNumLocator = By.xpath("//label[text()='Please enter the Lending Finder Reference Number']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtOrgNameLocator = By.xpath("//label[text()='Business/ Organisation name']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtOrgTelNumLocator = By.xpath("//label[text()='Business/ Organisation telephone number']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtOrgEmailLocator = By.xpath("//label[text()='Business/ Organisation e-mail address']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtOrgMobileLocator = By.xpath("//label[text()='Mobile number']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtOrgAccTitleLocator = By.xpath("//label[text()='Please enter the Account title']/../following-sibling::div//input[@tabindex!='-1']");
	private By edtPortfolioLocator = By.xpath("//label[text()='Please enter your portfolio code']/../following-sibling::div//input[@tabindex!='-1']");
	
	
	private By btnNextLocator = By.xpath("//button[text()='Next']");
	private By btnCancelApplicationLocator = By.xpath("//button[text()='Cancel Application']");	
	private By btnOkLocator = By.xpath("//button[text()='OK']");
	private By btnYesLocator = By.xpath("//button[text()='Yes']");
	private By btnNoLocator = By.xpath("//button[text()='No']");
	
	
	
	public By getFrmCaptureApplicationWebElement() {
		return frmCaptureApplicationLocator;
	}
	
	public WebElement getLstBrandWebElement() {
		return driver.findElement(lstBrandLocator);
	}
	
	public List<WebElement> getradgrpAccountBasedInScotlandWebElement() {
		return driver.findElements(radgrpAccountBasedInScotlandLocator);
	}

	public WebElement getRadAccountBasedInScotlandYesWebElement() {
		return this.getradgrpAccountBasedInScotlandWebElement().get(0);
	}

	public WebElement getRadAccountBasedInScotlandNoWebElement() {
		return this.getradgrpAccountBasedInScotlandWebElement().get(1);
	}
	
	public List<WebElement> getRadgrpExistingRbsAccountHolderWebElement() {
		return driver.findElements(radgrpExistingRbsAccountHolderLocator);
	}

	public WebElement getRadExistingRbsAccountHolderYesWebElement() {
		return this.getRadgrpExistingRbsAccountHolderWebElement().get(0);
	}

	public WebElement getRadExistingRbsAccountHolderNoWebElement() {
		return this.getRadgrpExistingRbsAccountHolderWebElement().get(1);
	}
	
	public List<WebElement> getRadgrpExistingNatwestAccountHolderWebElement() {
		return driver.findElements(radgrpExistingNatwestAccountHolderLocator);
	}

	public WebElement getRadExistingNatwestAccountHolderYesWebElement() {
		return this.getRadgrpExistingNatwestAccountHolderWebElement().get(0);
	}

	public WebElement getRadExistingNatwestAccountHolderNoWebElement() {
		return this.getRadgrpExistingNatwestAccountHolderWebElement().get(1);
	}
	
	public WebElement getEdtDepositRefNumWebElement() {
		return driver.findElement(edtDepositRefNumLocator);
	}

	public WebElement getEdtLendingRefNumWebElement() {
		return driver.findElement(edtLendingRefNumLocator);
	}

	public WebElement getLstEntityWebElement() {
		return driver.findElement(lstEntityLocator);
	}

	public By getLstSubEntityLocator(String sType) {
		this._sTypeOfEntity = sType;
		System.out.println(this._sTypeOfEntity);
		return By.xpath("//label[text()='Please specify what type of "+this._sTypeOfEntity+" it is']/../following-sibling::div//input[@tabindex!='-1']");
	}
	
	public void setLstSubEntityType(String sType) {
		this._sTypeOfEntity = sType;
	}

	public WebElement getLstMainAccWebElement() {
		return driver.findElement(lstMainAccLocator);
	}

	public WebElement getLstAccTypeWebElement() {
		return driver.findElement(lstAccTypeLocator);
	}
	
	public List<WebElement> getRadgrpLendingRelatedWebElement() {
		return driver.findElements(radgrpLendingRelatedLocator);
	}

	public WebElement getRadgrpLendingRelatedYesWebElement() {
		return this.getRadgrpLendingRelatedWebElement().get(0);
	}

	public WebElement getRadgrpLendingRelatedNoWebElement() {
		return this.getRadgrpLendingRelatedWebElement().get(1);
	}
	
	public WebElement getOrgNameWebElement() {
		return driver.findElement(edtOrgNameLocator);
	}
	
	public WebElement getOrgTelNumWebElement() {
		return driver.findElement(edtOrgTelNumLocator);
	}
	
	public WebElement getOrgEmailWebElement() {
		return driver.findElement(edtOrgEmailLocator);
	}
	
	public WebElement getOrgMobileWebElement() {
		return driver.findElement(edtOrgMobileLocator);
	}
	
	public WebElement getOrgAccTitleWebElement() {
		return driver.findElement(edtOrgAccTitleLocator);
	}
	
	public WebElement getPortfolioWebElement() {
		return driver.findElement(edtPortfolioLocator);
	}
	
	public WebElement getTitleWebElement() {		
		return WaitUtils.waitForElement(driver, txtTitleLocator, 15);
	}
		
	public WebElement getBtnNextWebElement() {
		return driver.findElement(btnNextLocator);
	}
	
	public WebElement getBtnCancelApplicationWebElement() {
		return driver.findElement(btnCancelApplicationLocator);
	}
	
	public WebElement getBtnOkWebElement() {
		return driver.findElement(btnOkLocator);
	}
	
	public WebElement getBtnYesWebElement() {
		return driver.findElement(btnYesLocator);
	}
	
	public WebElement getBtnNoWebElement() {
		return driver.findElement(btnNoLocator);
	}
	
	public By getTitleLocator() {
		return txtTitleLocator;
	}
			
}
