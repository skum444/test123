package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.util.SystemOutLogger;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class Form1 extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	String path;
	String pathForPeriod;
	public String respString = null;
	 String json;
	Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void FormMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
		
		
	document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
	
	path = "$.data.";
	Map<String, String> resp1  = JsonPath.read(document,"$.data");
	String ApplicationID = ServiceValueForStringRet(path,"applId");
	String LastUpdBy = ServiceValueForStringRet(path,"lastUpdBy");
	String lastUpdTs = ServiceValueForStringRet(path,"lastUpdTs");
			//ServiceValueRet(path,"lastUpdTs");
	String DigitalSeqContext = ServiceValueRet(path,"digitalContextSeq");
	String a = "\"store\"";
	String b = "\"productSliderValue\"";
	String c = "\"AmountSlider\"";
	
	String value = JsonPath.read(document,"$.data.appDataJson");
	System.out.println(value);
	
	String[] appData = value.split("\\{");
	//String[] dataa = appData.split(",");
 int i =0;
 
	for(i=0;i<appData.length;i++)
	{
		System.out.println(appData[i]);
		if(appData[i].contains("\":"))
		{
			System.out.println(appData[i]);
		}
	}
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Product Info";
    
    CommonUtils.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	
	
	CommonUtils.setTestDataRow_BB_Write(SheetName,"Application ID",rowcount,0);
	CommonUtils.setTestDataRow_BB_Write(SheetName,ApplicationID,rowcount,1);
	rowcount++;
	
	CommonUtils.setTestDataRow_BB_Write(SheetName,"Last Upd By",rowcount,0);
	CommonUtils.setTestDataRow_BB_Write(SheetName,LastUpdBy,rowcount,1);
	rowcount++;
	
	CommonUtils.setTestDataRow_BB_Write(SheetName,"last Upd Ts",rowcount,0);
	CommonUtils.setTestDataRow_BB_Write(SheetName,lastUpdTs,rowcount,1);
	rowcount++;
	
	CommonUtils.setTestDataRow_BB_Write(SheetName,"DigitalSeqContext",rowcount,0);
	CommonUtils.setTestDataRow_BB_Write(SheetName,DigitalSeqContext,rowcount,1);
	rowcount++;
	

}
	
	

	String FinalPath;
	Double MicroServicedoubleValue;
	String MicroServiceStrValue;
	int MicroServiceIntValue;
	String ServiceValueForStringRet(String JsonPathForPurpose1, String InputData)
	{
		
		FinalPath = JsonPathForPurpose1+InputData;
		try
		{
			MicroServiceStrValue = JsonPath.read(document,FinalPath);
	   
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueRet(String InitialPath, String InputData)
	{
		
		FinalPath = InitialPath+InputData;
		try
		{
		MicroServiceIntValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Integer.toString(MicroServiceIntValue);
	    System.out.println(MicroServiceIntValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value returned";
		}
	
		
		return MicroServiceStrValue;
	}
	

	}

	
	
	


