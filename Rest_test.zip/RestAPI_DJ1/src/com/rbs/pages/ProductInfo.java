package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class ProductInfo extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	String path;
	String pathForPeriod;
	public String respString = null;
	 String json;
	Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void ProductInfoMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
		
		
	document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
	path = "$.data.";
	
	String LowerBound = ServiceValueForStringRet(path,"borrowable.lowerBound");
	String UpperBound = ServiceValueForStringRet(path,"borrowable.upperBound");
	String Tick	 = ServiceValueRet(path,"borrowable.tick");
	
	String LowerBoundPeriod = ServiceValueForStringRet(path,"period.lowerBound");
	String UpperBoundPeriod = ServiceValueForStringRet(path,"period.upperBound");
	String TickPeriod	 = ServiceValueRet(path,"period.tick");
	
	String BaseRate = ServiceValueForStringRet(path,"boeBaseRate.baseRate");
	
	
 
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Product Info";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"Lower Bound",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,LowerBound,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Upper Bound",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UpperBound,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Tick",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Tick,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Lower Bound Period",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,LowerBoundPeriod,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Upper Bound Period",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UpperBoundPeriod,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Tick Period",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,TickPeriod,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"BaseRate",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BaseRate,rowcount,1);
	rowcount++;
	



   
	}
	
	

	String FinalPath;
	Double MicroServicedoubleValue;
	String MicroServiceStrValue;
	int MicroServiceIntValue;
	String ServiceValueForStringRet(String JsonPathForPurpose1, String InputData)
	{
		
		FinalPath = JsonPathForPurpose1+InputData;
		try
		{
		MicroServicedoubleValue = JsonPath.read(document,FinalPath);
	    System.out.println(MicroServicedoubleValue);
	    MicroServiceStrValue = Double.toString(MicroServicedoubleValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueRet(String InitialPath, String InputData)
	{
		
		FinalPath = InitialPath+InputData;
		try
		{
		MicroServiceIntValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Integer.toString(MicroServiceIntValue);
	    System.out.println(MicroServiceIntValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value returned";
		}
	
		
		return MicroServiceStrValue;
	}
	

	}

	
	
	


