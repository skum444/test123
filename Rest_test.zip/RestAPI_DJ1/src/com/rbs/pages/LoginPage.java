package com.rbs.pages;

import java.net.URI;
import java.util.Map;

import com.rbs.utils.ExcelUtils;

public class LoginPage extends BasePage{

	
	
	public String getLoginAPI(String sTestName) {
		
	String serviceURL = URL; 
	
       return serviceURL;
    }

	
}
