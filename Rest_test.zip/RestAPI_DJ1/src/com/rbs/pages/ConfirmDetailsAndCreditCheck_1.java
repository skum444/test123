package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.OracleDBUtils;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.bpm.automation.bbconnect.pages.BasePage;
import com.rbs.bpm.automation.bbconnect.pages.AsstJourneyPage;

//import org.apache.commons.io.FileUtils;

public class ConfirmDetailsAndCreditCheck_1 extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	KeySignatories ks = new KeySignatories();
	private String sTestDataSheetName = "ConfirmDetails";
	private String qTestDataSheetName = "PersonaliseYourQuote";
	private String ksTestDataSheetName = "KeySignatory";
	AsstJourneyPage ajp = new AsstJourneyPage();
	//MoreAboutYourBusiness mayb = new MoreAboutYourBusiness();
	ConfirmCreditCheckDBValidation ccdb = new ConfirmCreditCheckDBValidation();
	//Goodnews g1 = new Goodnews();
	OracleDBUtils o1= new OracleDBUtils();
	KeySignatories ksg = new KeySignatories();
	//BusinessBankingLoginPage1 bizobj = null;
	SetPageName s1= null;
	public String Status;
	public String value;
	public String CreditDiffacct;
	public static String fininfo;
	public static String LombardCardURL; 
	//Welcome w1 = new Welcome ();
	public ConfirmDetailsAndCreditCheck_1() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void inputValuesInConfirmDetails(String sTestName, int rownum)
			throws Exception {
		try
		{
			//s1.setupTestName(sTestDataSheetName +"_"+sTestName,"chrome",sTestDataSheetName+"_"+sTestName);
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
					sTestDataSheetName, sTestName);
			Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
					qTestDataSheetName, sTestName);
			Map<String, String> tdksRow = ExcelUtils.getTestDataRow_BB(
					ksTestDataSheetName, sTestName);
			//String shadowlimit = w1.orgShadowlimit;
			String shadrep= shadowlimit.replace(",", "");
			long slimit = Long.parseLong(shadrep);
			
			//int slimit = Integer.parseInt(shadrep);
			
			commoncomps.waitForLoading();
			
		//	commoncomps.waitForPageHeaderToAppear("Your application is in progress");
			
			commoncomps.waitForPageHeaderToAppear("Confirm details and run a credit check");
			commoncomps.sleepTime(3);
			
			String asstappid = commoncomps.getappIdAsstJourneyCD();
			String appid[] = asstappid.split(":");
			String applidCD = appid[1].trim();
			//System.out.println(applidCD );
			if(tdRow.get("LegalEntity").equalsIgnoreCase("Limited Company"))
			{
				String data = commoncomps.gettextcredit("Registered Company",value);
				
				
				// need to write text in data.txt or to write in excel   
			}
			if (tdRow.get("TheseDetailsAren'tRightBusInfo").equalsIgnoreCase("Yes"))
			{
				int le = 0;
				commoncomps.clickAnylinkInZambesiCreditTheseDetails(driver,"These details are", le);
				
				commoncomps.inputInTextBoxZambesiCredit(driver, "businessName", tdRow.get("Bus_name"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "buildingName", tdRow.get("Build_name"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine1", tdRow.get("AddLine1"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine2", tdRow.get("AddLine2"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine3", tdRow.get("Town/City"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine4", tdRow.get("Country/Region"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "postcode", tdRow.get("Postcode"));
				commoncomps.inputInTextBoxZambesiCredit(driver, "companyNumber", tdRow.get("RegCompany_No"));
				if (tdRow.get("SavechangesBusInfo").equalsIgnoreCase("Yes"))
				{
					
				commoncomps.clickAnybuttonInZambesi("Save changes");
				}
				else{
					commoncomps.clickAnylinkInZambesiCredit("Cancel changes");
				}
			}
			
			if((tdRow.get("AccountToBeChoosen").equalsIgnoreCase("Choose from your NatWest accounts"))||(tdRow.get("AccountToBeChoosen").equalsIgnoreCase("Choose from your RBS accounts")))
			{
				CreditDiffacct = "No";
				//commoncomps.ZambesiRadioButtonCredit(driver,"radiosameAccount",tdRow.get("AccountToBeChoosen"));
			}
			else
			{
				CreditDiffacct = "Yes";
				commoncomps.ZambesiRadioButtonCredit(driver,"radionewAccount",tdRow.get("AccountToBeChoosen"));
			}
			
			/*if(tdRow.get("LegalEntity").equalsIgnoreCase("Limited Company"))
			{*/
			String borrowamt = tdqRow.get("AmountSliderValue");
			Long bamt = Long.parseLong(borrowamt);
			
			if (bamt > slimit)
			{
				
			fininfo ="Yes";
				// financial information section
				commoncomps.inputInTextBoxZambesi(driver, "projectedTurnover", tdRow.get("projected turnover"));
				commoncomps.clickAnylinkInZambesiCreditTheseDetails(driver,"What does this mean", 0);
				commoncomps.inputInTextBoxZambesi(driver, "netProfit", tdRow.get("net profit"));
				commoncomps.clickAnylinkInZambesiCreditTheseDetails(driver,"What does this mean", 1);
				//commoncomps.clickAnylinkInZambesiCredit("personal guarantee");
			}
			else
			{
				fininfo = "No";
			}
				// need to verify the display of page/ section, not sure of the change
			//}
			
			
			ks.inputValuesInKeySignatories(sTestName);
			ccdb.inputValuesInConfirmDetailsUI(applidCD, sTestName, rownum);
			
			commoncomps.clickAnybuttonInZambesi("Confirm & run a credit check");
			//commoncomps.waitForPageHeaderToAppear("Missing Key Information");
			commoncomps.sleepTime(80);
			String longtermad = KeySignatories.longtermaddress;
			String KPageval = KeySignatories.KPage;
			//System.out.println(applidCD);
		// changes for handling more about your business
			o1.dbvalidationCreditAI(applidCD,tdRow.get("CreditDecision"));
			String AI = OracleDBUtils.affortabilityInd;
			try{
				if ((bamt > slimit)	&& (AI.equalsIgnoreCase("N")))
			{
				//mayb.inputValuesInMoreaboutyourbusiness(sTestName);
				
			}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			 if( (longtermad.equalsIgnoreCase("No"))||(KPageval.equalsIgnoreCase("KP Age is high"))||(tdRow.get("CreditDecision").equalsIgnoreCase("Decline"))||(tdRow.get("SavechangesBusInfo").equalsIgnoreCase("Yes")) || (tdksRow.get("SavechangesKeySig1").equalsIgnoreCase("Yes"))||(CreditDiffacct.equalsIgnoreCase("Yes")))
			{
				//System.out.println("Assisted Journey after credit");
				 o1.dbvalidationCredit(applidCD, sTestName, rownum);
			ajp.inputValuesInAJPage(sTestName,rownum,"Aft_Credit");
			String ajpstatus = ajp.Status;
			if(ajpstatus.equalsIgnoreCase("Pass"))
			{
				Status = "Pass";	
			}
			}
			 else if(tdRow.get("CreditDecision").equalsIgnoreCase("Accept"))
				{
					System.out.println("Good, Your loan isp processe to Post credit");
					//g1.inputValuesIngoodNewsPage(sTestName,rownum,"Good News");
					ccdb.inputValuesInConfirmDetailsDB(applidCD, sTestName, rownum);
					o1.dbvalidationCredit(applidCD, sTestName, rownum);
					g1.inputValuesIngoodNewsPage(sTestName,rownum,"Good News");
					String gnstatus = g1.Status;
					if(gnstatus.equalsIgnoreCase("Pass"))
					{
						Status = "Pass";	
					}
					
				}
			 else
			 {
					//ccdb.inputValuesInConfirmDetailsDB(applidCD, sTestName, rownum);
					o1.dbvalidationCredit(applidCD, sTestName, rownum);
					ajp.inputValuesInAJPage(sTestName,rownum,"Aft_Credit");
					String ajpstatus = ajp.Status;
					if(ajpstatus.equalsIgnoreCase("Pass"))
					{
						Status = "Pass";	
					}
			 }
		//	commoncomps.clickAnybuttonInZambesi("View documents");
			 
			
			
		}
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
			Status = "Fail";
		}
		
	}
}