package com.rbs.pages;

import static com.jayway.restassured.RestAssured.given;

import java.util.List;
import java.util.Map;

import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;





public class GetServicePage extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "ConnectionDetails";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	
	
	public void RavenURLUsingConnectionDetails(String sTestName)
	{
		 Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
				sTestDataSheetName, sTestName); 
		
		// String request= LP.getLoginAPI(sTestName);
		        String request= LP.getLoginAPI(sTestName);
		        System.out.println(request);
		        
		        RequestSpecification reqspec = given().
		                config(RestAssuredConfig.config().sslConfig(new SSLConfig().allowAllHostnames())).
		             //   body(lcDefaultData).
		                header("X-Raven-domain", tdRow.get("Domain")).
		                header("X-Raven-username",  tdRow.get("Username")).
		                header("Content-Type", "application/json").
		                        when().
		                        contentType("application/json");

		                       // post();
		                     // Response resp=  reqspec.post(request);
		        Response resp=  reqspec.get(request);

		            //    post("https://devzebra.fm.rbsgrp.net/api/security/login");
		        //post("https://api.nwb-test.openaccount.managedtest.com/api/security/login");
		        System.out.println(resp);
		      //  System.out.println(resp);
		        System.out.println("value of response code is " + resp.getStatusCode());
		        System.out.println("value of response as string is " + resp.asString());
		        //System.out.println("value of response as string is " + resp.getCookies());
		        System.out.println("value of response as string is " + resp.getCookie("RBSGSESSION"));
		      //  DataHelper.setRBSSessionCookie("RBSGSESSION="+resp.getCookie("RBSGSESSION"));

		    }

	public void TestingMicroservicesURL(String sTestName, int scenum)
	{
		 Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
				sTestDataSheetName, sTestName); 
		
		 int rownum = 2;
			zTestDataSheetName = wTestDataSheetName+scenum;
		        String request= LP.getLoginAPI(sTestName);
		        System.out.println(request);
		        
		        RequestSpecification reqspec = given().
		                config(RestAssuredConfig.config().sslConfig(new SSLConfig().allowAllHostnames())).
		                //body(lcDefaultData).
		               header("Cache-Control", "no-cache").
		                header("Cookie", "BBCONNECT_TOKEN=06b144cd-0224-420f-9c24-db60580e5645").
		                header("iam_r4p_bin",tdRow.get("BIN")).
		                header("iam_r4p_dbid",tdRow.get("DBID")).
		                header("iam_r4p_linked-cin", tdRow.get("CIN")).
		                header("iam_subject", "1151869260").
		                header("postman-token", "1aae1ea2-a9b2-2f7b-4c46-4e615a10469b").
		                header("x-forwarded-for", "1.2.3.4").
		              header("Content-Type", "application/json").
                        when().
                        contentType("application/json");
                
              //get() method 
		        Response resp=  reqspec.get(request);
		        System.out.println(resp);
		        
		        
		        try
		        {
		      List <Integer> resp1 = reqspec.get(request).then().extract().path("keyPrincipalsResponse.principals.userInfo.userId");  
		  //    List <Integer> resp2 = reqspec.get(request).then().extract().path("facilityDetails.facilityId");
		  //    List <Integer> resp3 = reqspec.get(request).then().extract().path("facilityDetails.cin");
		      
		     
		      try
		      {
		    	  for (int j=0;j<resp1.size();j++)
		    	  {
		    		  
		    		  System.out.println("Using index for loop cin = "+ resp1.get(j));
		    	int value = resp1.get(j);
		    	//String value = resp1.get(j);
		    	String repval = Integer.toString(value);
		    		  ExcelUtils.writeTestDataRow_BB(
		    				  zTestDataSheetName, repval ,rownum,j*3+2);
		    	  }
		      }
		      catch(Exception e)
				 {
					 System.out.println(e);
				 }
		   /*   try
		      {
		    	  for (int j=0;j<resp2.size();j++)
		    	  {
		    		  System.out.println("Using index for loop 2"+ resp2.get(j));
		    		  int value = resp2.get(j);
				    	String repval = Integer.toString(value);
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  zTestDataSheetName, repval ,rownum+1,j*3+2);
		    	  }
		      }
		      catch(Exception e)
				 {
					 System.out.println(e);
				 }
		      try
		      {
		    	  for (int j=0;j<resp3.size();j++)
		    	  {
		    		  System.out.println("Using index for loop 3"+ resp3.get(j));
		    		  int value = resp3.get(j);
				    	String repval = Integer.toString(value);
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  zTestDataSheetName, repval ,rownum+2,j*3+2);
		    	  }
		      }
		      catch(Exception e)
				 {
					 System.out.println(e);
				 }
		*/
		        }
		        catch(Exception e)
		        {
		        	System.out.println(e);
		        }
		        
		      /*  // To split the output
		        respString = resp.asString();
		        String[] outerfields = respString.split(",");
		        int slength = outerfields.length;
		        
		        for ( int i=0; i<slength; i++)
		        {
		        
		        	String[] innerfield = outerfields[i].split(":");
		        	
		        	System.out.println(innerfield[1]);
		        	ExcelUtils.writeTestDataRow_BB(
			        		wTestDataSheetName, innerfield[1],i+1,rownum);
		        }*/
		        
		       
		      
		        System.out.println("value of response code is " + resp.getStatusCode());
		        System.out.println("value of response as string is " + resp.asString());
		        //System.out.println("value of response as string is " + resp.getCookies());
		        System.out.println("value of response as string is " + resp.getCookie("RBSGSESSION"));
		      //  DataHelper.setRBSSessionCookie("RBSGSESSION="+resp.getCookie("RBSGSESSION"));

		    }
	}
	


