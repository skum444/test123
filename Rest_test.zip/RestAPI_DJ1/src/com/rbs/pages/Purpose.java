package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class Purpose extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	 String json;
	 String JsonPathForPurpose1;
	 String JsonPathForPurpose2;
	 String JsonPathForPurpose3;
	 String JsonPathForPurpose4;
	 String JsonPathForPurpose5;
	 String JsonPathForPurpose6;
	 String PathforAddress;
	 String PathForBusiness;
	 String PathForBusiWithAccounts;
	 String InitialJsonPath;
	 String PathForBusiWithMainAccounts;
	 String PathForBusiAddress;
	 String PathWithElig;
	 Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void PurposeMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
	
	 document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
     
      JsonPathForPurpose1 = "$.data.purposeInfoList[0].";
      JsonPathForPurpose2 = "$.data.purposeInfoList[1].";
      JsonPathForPurpose3 = "$.data.purposeInfoList[2].";
      JsonPathForPurpose4 = "$.data.purposeInfoList[3].";
      JsonPathForPurpose5 = "$.data.purposeInfoList[4].";
      JsonPathForPurpose6 = "$.data.purposeInfoList[5].";
      
      
    String Pur1ID = ServiceValueForStringRet(JsonPathForPurpose1,"id");
    
    String Pur1Title = ServiceValueForStringRet(JsonPathForPurpose1,"title");
   	
    String Pur1Description = ServiceValueForStringRet(JsonPathForPurpose1,"description");

    String Pur1ImageURL = ServiceValueForStringRet(JsonPathForPurpose1,"imageUrl");
    
    String Pur1Name = ServiceValueForStringRet(JsonPathForPurpose1,"name");
    
    String Pur1MinTerm = ServiceValueForStringRet(JsonPathForPurpose1,"minTerm");
    
    String Pur1MaxTerm = ServiceValueForStringRet(JsonPathForPurpose1,"maxTerm");
    
    String Pur1odmKey = ServiceValueForStringRet(JsonPathForPurpose1,"odmKey");
    
    String Pur2ID = ServiceValueForStringRet(JsonPathForPurpose2,"id");
    
    String Pur2Title = ServiceValueForStringRet(JsonPathForPurpose2,"title");
   	
    String Pur2Description = ServiceValueForStringRet(JsonPathForPurpose2,"description");

    String Pur2ImageURL = ServiceValueForStringRet(JsonPathForPurpose2,"imageUrl");
    
    String Pur2Name = ServiceValueForStringRet(JsonPathForPurpose2,"name");
    
    String Pur2MinTerm = ServiceValueForStringRet(JsonPathForPurpose2,"minTerm");
    
    String Pur2MaxTerm = ServiceValueForStringRet(JsonPathForPurpose2,"maxTerm");
    
    String Pur2odmKey = ServiceValueForStringRet(JsonPathForPurpose2,"odmKey");
    
    String Pur3ID = ServiceValueForStringRet(JsonPathForPurpose3,"id");
    
    String Pur3Title = ServiceValueForStringRet(JsonPathForPurpose3,"title");
   	
    String Pur3Description = ServiceValueForStringRet(JsonPathForPurpose3,"description");

    String Pur3ImageURL = ServiceValueForStringRet(JsonPathForPurpose3,"imageUrl");
    
    String Pur3Name = ServiceValueForStringRet(JsonPathForPurpose3,"name");
    
    String Pur3MinTerm = ServiceValueForStringRet(JsonPathForPurpose3,"minTerm");
    
    String Pur3MaxTerm = ServiceValueForStringRet(JsonPathForPurpose3,"maxTerm");
    
    String Pur3odmKey = ServiceValueForStringRet(JsonPathForPurpose3,"odmKey");
    
	String Pur4ID = ServiceValueForStringRet(JsonPathForPurpose4,"id");
    
    String Pur4Title = ServiceValueForStringRet(JsonPathForPurpose4,"title");
   	
    String Pur4Description = ServiceValueForStringRet(JsonPathForPurpose4,"description");

    String Pur4ImageURL = ServiceValueForStringRet(JsonPathForPurpose4,"imageUrl");
    
    String Pur4Name = ServiceValueForStringRet(JsonPathForPurpose4,"name");
    
    String Pur4MinTerm = ServiceValueForStringRet(JsonPathForPurpose4,"minTerm");
    
    String Pur4MaxTerm = ServiceValueForStringRet(JsonPathForPurpose4,"maxTerm");
    
    String Pur4odmKey = ServiceValueForStringRet(JsonPathForPurpose4,"odmKey");
    
    String Pur5ID = ServiceValueForStringRet(JsonPathForPurpose5,"id");
    
    String Pur5Title = ServiceValueForStringRet(JsonPathForPurpose5,"title");
   	
    String Pur5Description = ServiceValueForStringRet(JsonPathForPurpose5,"description");

    String Pur5ImageURL = ServiceValueForStringRet(JsonPathForPurpose5,"imageUrl");
    
    String Pur5Name = ServiceValueForStringRet(JsonPathForPurpose5,"name");
    
    String Pur5MinTerm = ServiceValueForStringRet(JsonPathForPurpose5,"minTerm");
    
    String Pur5MaxTerm = ServiceValueForStringRet(JsonPathForPurpose5,"maxTerm");
    
    String Pur5odmKey = ServiceValueForStringRet(JsonPathForPurpose5,"odmKey");
    
    String Pur6ID = ServiceValueForStringRet(JsonPathForPurpose6,"id");
    
    String Pur6Title = ServiceValueForStringRet(JsonPathForPurpose6,"title");
   	
    String Pur6Description = ServiceValueForStringRet(JsonPathForPurpose6,"description");

    String Pur6ImageURL = ServiceValueForStringRet(JsonPathForPurpose6,"imageUrl");
    
    String Pur6Name = ServiceValueForStringRet(JsonPathForPurpose6,"name");
    
    String Pur6MinTerm = ServiceValueForStringRet(JsonPathForPurpose6,"minTerm");
    
    String Pur6MaxTerm = ServiceValueForStringRet(JsonPathForPurpose6,"maxTerm");
    
    String Pur6odmKey = ServiceValueForStringRet(JsonPathForPurpose6,"odmKey");
    

    
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Purpose";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur1odmKey,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur2odmKey,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur3odmKey,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur4odmKey,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur5odmKey,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ID of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6ID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6Title ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Description of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6Description,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Image of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6ImageURL,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6Name,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Min Term of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6MinTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Max Term of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6MaxTerm,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ODM Key of purpose6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Pur6odmKey,rowcount,1);
	rowcount++;
	

   
	}
	
	String FinalPath;
	String MicroServiceStrValue;
	

	String ServiceValueForStringRet(String JsonPathForPurpose1, String InputData)
	{
		
		FinalPath = JsonPathForPurpose1+InputData;
		try
		{
		MicroServiceStrValue = JsonPath.read(document,FinalPath);
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	
	
	
	
	
	}

	
	
	


