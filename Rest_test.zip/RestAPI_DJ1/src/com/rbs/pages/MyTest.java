package com.rbs.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.*;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONObject;
import org.omg.CORBA.RepositoryIdHelper;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import java.util.Date;
public class MyTest {

	public static void main(String[] args) throws FileNotFoundException, java.text.ParseException {
		
				/*FileInputStream keyStr = new FileInputStream(
						"C:\\Users\\ravindi\\sudhaWS\\RestAPI_DJ1\\certs\\keytool_lbcore-bbc-nwb-qa-1.apps.rbsgrp.mde.jks");

				// FileInputStream keyStr = new
				// FileInputStream("C:\\Users\\VADISLK\\Desktop\\keytool_lbcore-bbc-nwb-qa-1.apps.rbsgrp.mde.p12");
				String trustStorePath = "C:/Program Files/Java/jre1.8.0_131/lib/security/cacerts";
				String trustPwd = "changeit";
				String password="q@1bc0reBbc";
				try {

					// keyStore = KeyStore.getInstance("PKCS12");
					KeyStore keyStore = KeyStore.getInstance("JKS");
					keyStore.load(keyStr, password.toCharArray());
					KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
					kmf.init(keyStore, password.toCharArray());
					KeyManager[] kms = kmf.getKeyManagers();
					KeyStore trustStore = KeyStore.getInstance("JKS");
					trustStore.load(new FileInputStream(trustStorePath), trustPwd.toCharArray());
					TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
					tmf.init(trustStore);
					TrustManager[] tms = tmf.getTrustManagers();
					SSLContext sslContext = SSLContext.getInstance("TLS");
					sslContext.init(kms, tms, new SecureRandom());
			

				if (keyStore != null) {
					org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
							keyStore, password, trustStore);
					// set the config in rest assured
					SSLConfig configur = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

					RestAssured.config = RestAssured.config().sslConfig(configur);

					RequestSpecification ok = RestAssured.given().when().contentType("application/json");

					JSONObject reqJson = new JSONObject();
					reqJson.put("brand", "NWB");
					reqJson.put("applicationId", "BC01");

					JSONArray actions = new JSONArray();
					//actions.add("TCE");
					//actions.add("BUSINESS_RELATIONS");
					//actions.add("BUSINESS_CORE_FACILITIES");
					//actions.add("BUSINESS_KYC");
					//actions.add("RELATIONS_PERSONAL_DETAILS");
					actions.add("CONNECTION_RMP_FACILITIES");
					//actions.add("ALL");
					
					
					
					JSONArray personalInformation = new JSONArray();
					JSONObject cin=new JSONObject();
					cin.put("cin", "122324564");
					JSONArray cinActions = new JSONArray();
					cinActions.add("PERSONAL_KYC");
					cin.put("actions", cinActions);
					personalInformation.add(cin);
					
					
					
					JSONObject businessInformation = new JSONObject();
					businessInformation.put("bin", "1381815829");
					businessInformation.put("actions", actions);
					//businessInformation.put("personalInformation", personalInformation);
					reqJson.put("businessInformation", businessInformation);
					org.json.JSONObject obj=new org.json.JSONObject(reqJson.toString());
					System.out.println("---------------Input JSON------" + obj.toString(4));
					response.body(reqJson.toJSONString());
					Response resp = response
							.post("https://lbcore-bbc-nwb-qa-1.apps.rbsgrp.mde:59305/lending/api/businessdetails/v1");
					System.out.println("value of response as string is\n " + resp.getBody().prettyPrint());

				}	}

				catch (Exception ex) {
					System.out.println("Error while loading keystore >>>>>>>>>");
					ex.printStackTrace();
				}*/
		
		// set the config in rest assured
	/*	SSLConfig configur = new SSLConfig().relaxedHTTPSValidation();
		RestAssured.config = RestAssured.config().sslConfig(configur);
		RequestSpecification request = RestAssured.given().when().header("X-Raven-domain", "m01europa").header("X-Raven-username","lyallg");
		//Response response=request.get("https://raven-customers-stable.apps.dev-pcf.lb1.rbsgrp.net/risk/raven/customers/summary/1100193335");
		request.header("Content-Type","application/json");
		//String str="{\"connectionId\": 200913000,\"purpose\": {\"code\":\"INC\"},\"dealDescription\": \"overdraft request\",\"restructureReasonList\": null}";
		String str="{\"connectionId\": 200913000,\"customer\": { \"cin\" : 1133319442},\"description\" : \"Test facility description\",\"type\" : {\"code\" : \"50\"},\"owner\":{\"domain\" : \"rmp\",\"username\" : \"Evans, Ceri\"},\"currency\" : {\"code\": \"GBP\"},\"sourceBank\" : {\"code\" : \"N\"},\"targetSystem\" : \"RMP\",\"fullyAmortisedLoan\" : true,\"repaymentProfile\" : {\"repaymentType\" : null,\"duration\" : null,\"interestApplied\" : null,\"installmentFrequency\" :null,\"capitalRepaymentHoliday\" : null,\"interestBasis\" : null},\"proposal\" : {\"proposed\" : {\"reviewDate\" : \"2018-12-12\",\"expiryDate\" : \"2019-12-12\",\"term\" : 36,\"limitList\" : [{\"reviewType\" : {\"code\" : \"INC\"},\"limitType\" : {\"code\" : \"CREDITLMT\"},\"limit\" : 75000.0}]}}}";
		
		//JSONObject reqJson=new JSONObject(str);
		request.body(str);
		//Response response1=request.post("https://raven-proposals-stable.apps.dev-pcf.lb1.rbsgrp.net/risk/raven/proposals/proposal");
		Response response2=request.post("https://raven-facilities-stable.apps.dev-pcf.lb1.rbsgrp.net/risk/raven/facilities/facility/proposal/1924510");
		System.out.println(response2.prettyPrint());*/
		//String value = ("45646.00%").replaceAll("[^0-9]", "");
		Double PI = (0.3415)*100;
		String expGrossProfitMargin=String.format("%1.1f", PI) +"%";
		System.out.println(expGrossProfitMargin);
		
		
	}
		

	}


