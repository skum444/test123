package com.rbs.pages;

import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.bpm.automation.bbconnect.pageObjects.ObjGettingStarted;
import com.rbs.bpm.automation.bbconnect.pageObjects.ObjWorkBench;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ScrWorkBench extends BasePage {

	private ObjWorkBench workBench = null ;

	public ScrWorkBench() {
		super();
		//PageFactory.initElements(getDriver(), this);
		workBench = new ObjWorkBench();
	}

	public void clickWorkTab() throws Exception {
		Logger.LogMessage("Entering clickWorkTab");
	//	super.validateAndClick("Work tab", workBench.getWorkTabWebElement());
		Logger.LogMessage("Exiting clickWorkTab");
	}

	/*public ScrGettingStarted clickNewApplication() throws Exception {
		Logger.LogMessage("Entering clickNewApplication");
		super.validateAndClick("New Application",workBench.getNewAppWebElement());
		Logger.LogMessage("Exiting clickNewApplication");

		//<AV>if on getting started page then only return this otherwise return null and stop the test
		return new ScrGettingStarted();
	}*/

	public void searchTaskInWorkBench(String sTaskID, String sTaskName) throws Exception {
		Logger.LogMessage("Entering searchTaskInWorkBench");

		if ( super.validateElementPresent("Search task",workBench.getSearchTaskWebElement())){
			super.sendKeys("Search task",workBench.getSearchTaskWebElement() , sTaskID);
			workBench.getSearchTaskWebElement().sendKeys(Keys.ENTER);
			
			super.waitForLoading();
			
			
			By lnkTaskLocator = workBench.getTaskLocatorByNameAndID (sTaskName  , sTaskID);

			try {
				WebElement lnkTask = WaitUtils.waitForElement(driver, lnkTaskLocator, 10);
				ReporterA.reportPassWithSnapshot("Search for Task " + sTaskID, sTaskID + " should apprear",
						sTaskID + " has appeared", getDriver());
				Logger.LogMessage("Task exists");
			} catch (Exception e) {
				ReporterA.reportFailWithSnapshot("Search for Task " + sTaskID, sTaskID + " should apprear",
						sTaskID + " does not appear", getDriver());
			}
		}
		Logger.LogMessage("Exiting searchTaskInWorkBench");
		
	}
	
	public void searchTaskNotInWorkBench(String sTaskID) throws Exception {
		Logger.LogMessage("Entering searchTaskNotInWorkBench");

		if ( super.validateElementPresent("Search task",workBench.getSearchTaskWebElement())){
			super.sendKeys("Search task",workBench.getSearchTaskWebElement() , sTaskID);
			workBench.getSearchTaskWebElement().sendKeys(Keys.ENTER);
			
			super.waitForLoading();
			
			By lnkNoTaskLocator = workBench.getNoTaskFoundLocator();

			try {
				WebElement lnkTask = WaitUtils.waitForElement(driver, lnkNoTaskLocator, 10);
				ReporterA.reportPassWithSnapshot("No Task Found" + sTaskID, sTaskID + " should not apprear",
						sTaskID + " has not appeared", getDriver());
				Logger.LogMessage("Task exists");
			} catch (Exception e) {
				ReporterA.reportFailWithSnapshot("No Task Found " + sTaskID, sTaskID + " should not apprear",
						sTaskID + " does appear", getDriver());
			}
		}
		Logger.LogMessage("Exiting searchTaskNotInWorkBench");
		
	}
	
	public void openTask(String sTaskID, String sTaskName) throws Exception {
		Logger.LogMessage("Entering openTask");		
		
		By lnkTaskLocator = workBench.getTaskLocatorByNameAndID (sTaskName  , sTaskID);

		//try {
			WebElement lnkTask = WaitUtils.waitForElement(driver, lnkTaskLocator, 10);
			super.click("Open Task Link ", lnkTask);
			Logger.LogMessage("Task Opened");			
			claimTask();
			ReporterA.reportPassWithSnapshot("Open Task " + sTaskID, sTaskID + " should be opened",
					sTaskID + " has been opened", getDriver());
		/*} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Open Task " + sTaskID, sTaskID + " should apprear",
					sTaskID + " does not appear", getDriver());
		}*/
		Logger.LogMessage("Exiting openTask");
	}
	
	
	private void claimTask() throws Exception {
		Logger.LogMessage("Entering claimTask");
		
		try {
		//if (super.validateElementPresent("Claim Task pop-up", workBench.getClaimTaskWebElement())) {
			validateAndClick("Claim Task pop-up", workBench.getClaimTaskWebElement());
			ReporterA.reportPass("Claiming Task", "Task should be claimed", "Task is claimed");
		} catch (Exception e) {
			ReporterA.reportInfo("Claiming Task", "Claim Task should not be available", "Task is not claimable");
		}
			
		
		Logger.LogMessage("Exiting claimTask");
	}

	public void switchToGettingStartedFrame() {

		Logger.LogMessage("Entering switchToGettingStartedFrame");
		driver.switchTo().frame(workBench.getFrameGettingStarted());
		
		WaitUtils.waitForElement(driver, new ObjGettingStarted().getTitleLocator() , 15);
		
		Logger.LogMessage("Exiting switchToGettingStartedFrame");
		
	}
	
	public void switchToDefault() {

		Logger.LogMessage("Entering switchToDefault");
		driver.switchTo().defaultContent();
		Logger.LogMessage("Exiting switchToDefault");
		
	}
}