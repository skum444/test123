package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class GetService extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	public String json;
	public Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void EligibilityMicroService(String sTestName, String URL) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
		
		FileInputStream keyStr = new FileInputStream("C:/Users/VADISLK/Desktop/keytool_vstmybt05f.server.rbsgrp.mde.jks");
	
		try {
			
			keyStore   = KeyStore.getInstance("jks");
			keyStore.load(keyStr,password.toCharArray()); 
			
	    } 
		
		catch (Exception ex) {
	        System.out.println("Error while loading keystore >>>>>>>>>");
	        ex.printStackTrace();
	    }

	    if (keyStore != null) {
			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
	        // set the config in rest assured
	        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
 
	RestAssured.config = RestAssured.config().sslConfig(config);
	
	Map<String, String> tdqRow = ExcelUtils.getTestDataRow_MicroService(
			sTestDataSheetName, sTestName);
	
	RequestSpecification response = RestAssured.given()
			//given().proxy("11.152.106.34",80)
			//.header(ServiceURL.Key, ServiceURL.Value)
			.header("Cookie", "BBCONNECT_TOKEN=/h6G8iZHNmntXGkkOrM1F7/ha4/EMw6L2ixPZK+NW07jJBJA4ZAocXF/RHaK3D6HMStMTJUwTZN4zcS0dsCXVl9S0kU4vKTQhCY/7OXQdSwh57tgfNwyNCUHSw7fC4MU40Kj44b3/Ui3Yt1zjHb4ntvDMJncxMOQM8hQIuI1j0Y3B2S9ryzFy8lFvd8AL4rdiNzkEo+ElC+JygQmIxPWRjECNMtNHZnTYe9yByPdJqOM9aTO+cIs/LqQoVV5rXKiAHb582QoaUj0ZttWh6z0K7rWTUQhXcSLAieRUfRLaVXNAUSvZcLKEZ0pKYIR6mCcmxmcsmglACuTx35vwU5sb6K9fZFLJ7SwoqF1jA3CC4KDSGhNmn9Huv07qaWIOe9EO4Gcx6qt1GZzwJIUQa0N4ZiizjtxUn85z4FF7xFquTmAbeBWYr5sPMGwTLaOwBTafB2JZX/mnWE=; RBSGSESSION=AAAAAgABAEiOUXRjhZWa1nkG3ObVEc38MKnAXjpa%2FPUYfz6s1mHBvQTO3USrorMkYF17s7JePnCkwaSLgTythvsC81uwzFytnFat2nsy0WA%3D")
			
			.header("Content-Type", "application/json").when().contentType("application/json");
	
		Response resp=  response.get("https://api.bbc.staff-qa-2.mybank.managedtest.com/bbconnect/api/eligibility/v1/?bin=1552539786&brand=NWB&cin=1152296252&blcin=0&dbid=0");
		//Response resp=  response.get(URL);
    System.out.println(resp);
	System.out.println(response);
	System.out.println("value of response code is " + resp.getStatusCode());
    System.out.println("value of response as string is " + resp.asString());
    
     json = resp.asString();
     document = Configuration.defaultConfiguration().jsonProvider().parse(json);
     
    int UserID = JsonPath.read(document,"$.data.eligibility.userInformation.userId");
    System.out.println(UserID);
    String BusinessID = JsonPath.read(document,"$.data.eligibility.businesses[0].businessId");
    System.out.println(BusinessID);
    String businessName = JsonPath.read(document,"$.data.eligibility.businesses[0].businessName");
    System.out.println(businessName);
    String businessType = JsonPath.read(document,"$.data.eligibility.businesses[0].businessType");
    System.out.println(businessType);
    String AccountName = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].accountName");
    System.out.println(AccountName);
    String SortCOde = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].sortCode");
    System.out.println(SortCOde);
    String AccountNum = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].accountNumber");
    System.out.println(AccountNum);
    String AcntTypeCode = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].accountTypeCode.typeCode");
    System.out.println(AcntTypeCode);
    //bool
    Boolean hasOd = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].hasOverdraft");
    System.out.println(hasOd);
    Double ODBal = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].overdraftBalance");
    System.out.println(ODBal);
    Boolean EligForOD = JsonPath.read(document,"$.data.eligibility.businesses[0].accounts[0].eligibleForOverdraft");
    System.out.println(EligForOD);
    
    
    Map<String, Integer> resp1  = JsonPath.read(document,"$.data.eligibility.userInformation");
   
    
    
    
    System.out.println(resp1);
    String refernum = "ABCD";
    SheetName = "Eligibility";
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    int rowcount=1;
    
  
	
    for (Map.Entry<String, Integer> entry : resp1.entrySet()) {
    	
        System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
    }

    if(URL.contains("customerlookup"))
    {
   String Outputresponse = resp.asString();
    String[] output = Outputresponse.split(":");
    System.out.println(output[0]);
    System.out.println(output[1]);
    System.out.println(output[2]);
    System.out.println(output[3]);
    System.out.println(output[4]);
    System.out.println(output[5]);
    System.out.println(output[6]);
    System.out.println(output[7]);
    
    String[] BusinessSplit = output[1].split("\"");
   	String BusinessValue = BusinessSplit[1];

   	String[] BrandSplit = output[2].split("\"");
   	String Brand = BrandSplit[1];
   	
   
  	String[] InProgressApplnSplit = output[3].split(",");
   	String InProgressApplnValue;
   	
   	if(InProgressApplnSplit[0].equalsIgnoreCase("[  ]"))
   	{
   		InProgressApplnValue = "No";
   	}
   	else 
   	{
   		InProgressApplnValue = "Yes";
   	}
   	
   	String[] UnKnownBusinessSplit = output[4].split(",");
   	String UnKnownBusiness = UnKnownBusinessSplit[0];
   	
	String[] CINSplit = output[6].split("\"");
   	String CIN = CINSplit[1];
   	
	String[] CustomerNameSplit = output[7].split("\"");
   	String CustomerName = CustomerNameSplit[1];
   	
    
   // String refernum = "ABCD";
   
    if(URL.contains("customerlookup"))
    {
    	SheetName = "CustomerLookUp";
    }
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Identification Number",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusinessValue,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Brand",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Brand,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"InProgressApplication",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,InProgressApplnValue,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"UnknownBusiness",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UnKnownBusiness,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CIN",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CIN,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Customer Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CustomerName,rowcount,1);
	rowcount++;
	

	
    }
	    }
	}
	
	}
	


