package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class CustomerLookUp extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	 String json;
	 String Path;
	 String PathforAddress;
	 String PathForBusiness;
	 String PathForBusiWithAccounts;
	 String InitialJsonPath;
	 String PathForBusiWithMainAccounts;
	 String PathForBusiAddress;
	 String PathWithElig;
	 Object document;
	KeyStore keyStore = null;
	private String SheetName;
	
	//Service serv = new Service();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void CustomerLookUpMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
	
    document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
    		
    String Business = ServiceValueForStringRet("$.business");
    
    String Brand = ServiceValueForStringRet("$.brand");
    
    String InProgressApplication = ServiceValueForStringRet("$.inProgressApplication[]");
    
    String UnKnownBusiness = ServiceValueForBoolRet("$.unknownBusiness");
    
    String CIN1 = ServiceValueForStringRet("$.customers[0].cin");
    
    String CustomerName1 = ServiceValueForStringRet("$.customers[0].customerName");
    
    String CIN2 = ServiceValueForStringRet("$.customers[1].cin");
    
    String CustomerName2 = ServiceValueForStringRet("$.customers[1].customerName");
    
    String refernum = "ABCD";
    
    int rowcount=1;
    
    SheetName = "CustomerLookUp";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    

	commoncomps.setTestDataRow_BB_Write(SheetName,"Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Business,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Brand",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Brand,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"In Progress Application",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,InProgressApplication,rowcount,1);
	rowcount++;
	
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"UnKnownBusiness",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UnKnownBusiness,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Customer1 CIN",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CIN1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Customer1 Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CustomerName1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Customer2 CIN",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CIN2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Customer2 Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CustomerName2,rowcount,1);
	rowcount++;
	

	
	    }
	String MicroServiceStrValue;
	Boolean MicroServiceBooleanValue;
	String ServiceValueForStringRet(String InputData)
	{
		
		try
		{
		MicroServiceStrValue = JsonPath.read(document,InputData);
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	String ServiceValueForBoolRet(String InitialPath)
	{
		
		try
		{
			
		MicroServiceBooleanValue = JsonPath.read(document,InitialPath);
		MicroServiceStrValue = Boolean.toString(MicroServiceBooleanValue);
	    System.out.println(MicroServiceBooleanValue);
		}
		catch(Exception e)
		{
			
			MicroServiceStrValue = "No Value found";
			
		}
		
		
		
	    return MicroServiceStrValue;
		
	}
	
	
	}
    
    

