package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.TimeUnit;



import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;

//import org.apache.commons.io.FileUtils;

public class BasePage {

	private static final String JQUERY_LOAD_SCRIPT = "resources\\queryify.js";

	public static WebDriver driver;
	protected static WebDriver firefoxBacked = null;
	protected static WebDriver chromeBacked = null;

	static String URL = GenericUtils.getProperty("appURL");

	@FindBy(how = How.ID_OR_NAME, using = "Topbarname")
	private WebElement postLoginValidationLink;

	@FindBy(how = How.LINK_TEXT, using = "Logout")
	private WebElement lnkLogout;

	@FindBy(how = How.ID_OR_NAME, using = "processPortalUserName")
	private WebElement lblUserName;
	private JavascriptExecutor jQryExecutor;

	private String strActualValue;
	public static boolean completeAppFrame = false;

	// processPortalUserName

	protected BasePage() {
		PageFactory.initElements(driver, this);
	}
	protected void getURLLink(String URLtype)
	{
		if (URLtype.equalsIgnoreCase("QA_NWB"))
		{
			URL = GenericUtils.getProperty("QA_NWB_URL");
		}
		else if (URLtype.equalsIgnoreCase("QA_RBS"))
		{
			URL = GenericUtils.getProperty("QA_RBS_URL");
		}
		else if (URLtype.equalsIgnoreCase("NFT_NWB"))
		{
			URL = GenericUtils.getProperty("NFT_NWB_URL");
		}
		else if (URLtype.equalsIgnoreCase("NFT_RBS"))
		{
			URL = GenericUtils.getProperty("NFT_RBS_URL");
		}
		else if (URLtype.equalsIgnoreCase("PSE_NWB"))
		{
			URL = GenericUtils.getProperty("PSE_NWB_URL");
		}
		else if (URLtype.equalsIgnoreCase("PSE_RBS"))
		{
			URL = GenericUtils.getProperty("PSE_RBS_URL");
		}
		else if (URLtype.equalsIgnoreCase("QA2_NWB"))
		{
			URL = GenericUtils.getProperty("QA2_NWB_URL");
		}
		else if (URLtype.equalsIgnoreCase("QA2_RBS"))
		{
			URL = GenericUtils.getProperty("QA2_RBS_URL");
		}
	}
	protected void initiateBrowser() throws IOException, InterruptedException {

		// String sBrowser = System.getProperty("browser");
		String sBrowser = "chrome";
		System.out.println("Initaiating Browser " + sBrowser);
		//System.out.println(sBrowser);8

		if (driver == null) {
			if (sBrowser.equalsIgnoreCase("ie")) {
				driver = BrowserUtils.getIE8NoProxy();
			}
			if (sBrowser.equalsIgnoreCase("firefox")) {
				FirefoxProfile profile = new FirefoxProfile();
				File firbugPath = new File("C:\\TEMP\\Softwares\\firepath-0.9.7.1-fx.xpi");
				File firbugBug = new File("C:\\TEMP\\Softwares\\firebug-2.0.14-fx.xpi");
				profile.addExtension(firbugBug);
				profile.addExtension(firbugPath);
				driver = new FirefoxDriver(profile);
				firefoxBacked = driver;
			}
			if (sBrowser.equalsIgnoreCase("chrome")) {

				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				Thread.sleep(2000);

				
				
				//driver = BrowserUtils.getChromeDriverNoProxy();
				driver=BrowserUtils.getChrome();
				
				chromeBacked = driver;
				// modified
				/*
				 * String
				 * strChromeBinPath=GenericUtils.getProperty("ChromeDriver");
				 * System
				 * .setProperty("webdriver.chrome.driver",strChromeBinPath);
				 * driver = new ChromeDriver();
				 */
			}
			
			
			
		} else {
			driver = chromeBacked;
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}

	}

	private void injectJquery() {
		String jQueryLoader = readFile(JQUERY_LOAD_SCRIPT);
		// System.out.println(jQueryLoader);
		driver.manage().timeouts().setScriptTimeout(15, TimeUnit.SECONDS);
		jQryExecutor = (JavascriptExecutor) driver;
		jQryExecutor.executeAsyncScript(jQueryLoader);
	}

	protected void openURL() throws Exception {

//		Logger.LogMessage("Opening URL - " + URL.substring(50));
		
		driver.get(URL);
		
		// add reporter
		/*if (driver.getTitle().contains("Process")) {
			ReporterA.reportPassWithSnapshot("Opening URL" + URL,
					"URL be opened", "As Expected", driver);
		} else {
			ReporterA.reportFailWithSnapshot("Opening URL" + URL,
					"URL be opened", "Could not be opened", driver);
		}

		Logger.LogMessage(getDriver().getTitle() + " displayed");*/

		// injectJquery();
	}
	
	protected void openURL(String URLtype) throws Exception {

//		Logger.LogMessage("Opening URL - " + URL.substring(50));
		getURLLink(URLtype);
		driver.get(URL);

		// add reporter
		/*if (driver.getTitle().contains("Process")) {
			ReporterA.reportPassWithSnapshot("Opening URL" + URL,
					"URL be opened", "As Expected", driver);
		} else {
			ReporterA.reportFailWithSnapshot("Opening URL" + URL,
					"URL be opened", "Could not be opened", driver);
		}

		Logger.LogMessage(getDriver().getTitle() + " displayed");*/

		// injectJquery();
	}

	public Boolean validateLogin() throws Exception {
		WebElement element = null;
		
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		element = wait.until(ExpectedConditions.visibilityOf(driver
				.findElement(By.id("processPortalUserName"))));

		if (null != element) {
			ReporterA.reportPassWithSnapshot("Validate Login for User "
					+ ScrProcessPortal.getUserID(), "Should be successfull",
					"As expected", driver);
			return true;
		} else {
			ReporterA.reportFailWithSnapshot("Validate Login for User "
					+ ScrProcessPortal.getUserID(), "Should be successfull",
					"Not successfull. Refer Snapshot for err", driver);
			return false;
		}

	}

	// // public void logout() {
	//
	// lnkLogout.click();
	// }

	public void finishTest() throws Exception {
		driver.manage().deleteAllCookies();
		driver.close();
		Thread.sleep(3000);

		try {
			driver.quit();
		} catch (Exception e) {
		}

		String sBrowser = System.getProperty("browser");

		try {

			if (sBrowser.equalsIgnoreCase("chrome")) {
				/*
				 * Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				 * Runtime.getRuntime().exec(
				 * "taskkill /F /IM plugin-container.exe");
				 * Runtime.getRuntime().exec("taskkill /F /IM WerFault.exe");
				 */
				;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  void CloseBrowser() {
		BrowserUtils.CloseBrowser();
	}
	
	public void waitForElementToAppear(String elementName, WebElement element) {

		Logger.LogMessage("Entering waitForElementToAppear");

		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

			Wait<WebDriver> wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(element));
			//wait.until(ExpectedConditions.elementToBeClickable(element));
			ReporterA.reportPassWithSnapshot(
					"Wait for element: " + elementName, elementName
							+ " should appear", elementName + " has appeared",
					driver);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception in waitforelementtoAppear in Base Page--");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			e.printStackTrace();
		}

		Logger.LogMessage("Exiting waitForElementToAppear");
	}

	/*
	 * 
	 * public void waitForElementToAppear(String elementName, List<WebElement>
	 * listElements ) {
	 * 
	 * driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	 * 
	 * Wait<WebDriver> wait = new WebDriverWait(driver, 30);
	 * wait.until(ExpectedConditions.visibilityOf((WebElement) listElements));
	 * wait.until(ExpectedConditions.elementToBeClickable((By) listElements));
	 * ReporterA.reportPassWithSnapshot("Wait for element: "+elementName,
	 * elementName+ " should appear", elementName+" has appeared", driver);
	 * 
	 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 * 
	 * }
	 */
	public Boolean click(String elementName, WebElement element)
			throws Exception {

		Boolean ret = false;
		if ((null != element)) {

			try {
				//waitForElementToAppear(elementName, element);
				element.click();

				ReporterA.reportPass("Click on " + elementName,
						"Should be clicked", "As Expected");
				ret = true;
			} catch (ElementNotFoundException e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked",
						"Element Not Found" + e.getMessage());

			} catch (ElementNotVisibleException e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked",
						"Element Not Visible" + e.getMessage());

			} catch (Exception e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked", "Element Not clickable "
								+ e.getMessage());
			}

		}
		return ret;
	}

	public Boolean click(String elementName, By eleLocator) throws Exception {

		WebElement element = driver.findElement(eleLocator);

		Boolean ret = false;
		if ((null != element)) {

			try {
				waitForElementToAppear(elementName, element);
				element.click();

				ReporterA.reportPass("Click on " + elementName,
						"Should be clicked", "As Expected");
				ret = true;
			} catch (ElementNotFoundException e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked",
						"Element Not Found" + e.getMessage());

			} catch (ElementNotVisibleException e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked",
						"Element Not Visible" + e.getMessage());

			} catch (Exception e) {
				ReporterA.reportFail("Click on " + elementName,
						"Element Should be clicked", "Element Not clickable "
								+ e.getMessage());
			}

		}
		return ret;
	}

	public Boolean enterText(WebElement e, String text) {
		return null;
	}

	public String getDisplayText(WebElement e) {
		return null;
	}

	public void clearText() {

	}

	public String takeSnapshot(String snapshotFilePath) {

		snapshotFilePath = GenericUtils.getProperty("snapshotPath") + "\\\\"
				+ snapshotFilePath;
		File scrFile = ((TakesScreenshot) getDriver())
				.getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File(snapshotFilePath));
		} catch (IOException e) {

			e.printStackTrace();
		}

		return snapshotFilePath;// GenericUtils.getProperty("snapshotPath");
	}

	public static String getTitle() {
		// TODO Auto-generated method stub
		return driver.getTitle();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public static void setDriver(WebDriver driver) {
		BasePage.driver = driver;
	}

	public static void validatePageTitle(String sExpectedTitle) {
		try {
			if (getTitle().equalsIgnoreCase(sExpectedTitle)) {

				ReporterA.reportPass("Validate if " + sExpectedTitle
						+ " page is appearing", sExpectedTitle
						+ " page should appear", getTitle()
						+ " page is appearing");
			} else {
				ReporterA.reportFail("Validate if " + sExpectedTitle
						+ " page is appearing", sExpectedTitle
						+ " page should appear", getTitle()
						+ " page is appearing");

				throw new Exception(sExpectedTitle + " page is not appearing");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean validateElementPresent(String strElement, WebElement element) {
		try {
			Logger.LogMessage("Inside validateElementPresent for " + strElement);
			if (null != element) {
				driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
				Wait<WebDriver> wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.visibilityOf(element));
				//wait.until(ExpectedConditions.elementToBeClickable(element));

				scrollElementToView(driver, element);

				highLightElement(driver, element);
				ReporterA.reportPassWithSnapshot("Validate if " + strElement
						+ " is present on screen", strElement
						+ "  should appear", strElement + "  is appearing",
						driver);
				revertElementHighlight(driver, element);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				return true;
			} else {
				ReporterA.reportFail("Validate if " + strElement
						+ " is present on screen", strElement
						+ "  should appear", strElement + "  is  notappearing");
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				return false;

			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();

			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			return false;
		}

	}

	public boolean validateElementPresentByLocator(String strElement, By locator)
			throws Exception {

		WaitUtils.waitForElement(driver, locator, 30);
		List<WebElement> elements = driver.findElements(locator);
		if (elements.size() > 0) {

			highLightElement(driver, elements.get(0));
			ReporterA.reportPassWithSnapshot("Validate if " + strElement
					+ " is present on screen", strElement + " should appear",
					strElement + " is appearing", driver, locator);

			revertElementHighlight(driver, elements.get(0));
			return true;
		} else {

			ReporterA.reportFailWithSnapshot("Validate if " + strElement
					+ " is present on screen", strElement + " should appear",
					strElement + " is not appearing", driver);
			return false;
		}
	}

	public WebElement getElementByLocator(String strElement, By locator)
			throws Exception {

		WaitUtils.waitForElement(driver, locator, 30);
		List<WebElement> elements = driver.findElements(locator);
		if (elements.size() > 0) {

			highLightElement(driver, elements.get(0));
			ReporterA.reportPassWithSnapshot("Validate if " + strElement
					+ " is present on screen", strElement + " should appear",
					strElement + " is appearing", driver, locator);

			revertElementHighlight(driver, elements.get(0));
			return elements.get(0);
		} else {

			ReporterA.reportFailWithSnapshot("Validate if " + strElement
					+ " is present on screen", strElement + " should appear",
					strElement + " is not appearing", driver);
			return null;
		}
	}

	private void revertElementHighlight(WebDriver driver, WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		jsExecutor.executeScript(
				"arguments[0].setAttribute('style', arguments[1]);", element,
				"");
	}

	public void highLightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

		scrollElementToView(driver, element);

		String strJS = "arguments[0].setAttribute('style', arguments[1]);";
		String styleA = "color: red; border: 3px solid green;";
		jsExecutor.executeScript(strJS, element, styleA);
	}

	private void scrollElementToView(WebDriver driver, WebElement element) {

		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		try {
			// jsExecutor.executeScript("arguments[0].scrollIntoView(false);",
			// element);
			jsExecutor.executeScript("window.scrollTo("
					+ element.getLocation().x + ","
					+ (element.getLocation().y - 20) + ");");
		} catch (Exception e) {
			e.printStackTrace();
		}

		//
		// int x = 0;
		//
		// while((Double) jsExecutor.executeScript("return
		// arguments[0].getBoundingClientRect().top", element) > 0);
		//
		// {
		//
		// x = x + 2;
		//
		// jsExecutor.executeScript("window.scrollByLines(2)");
		//
		// System.out.println("Client top is = " + (Double)
		// jsExecutor.executeScript("return
		// arguments[0].getBoundingClientRect().top"));
		//
		// }
		//
		// System.out.println("Element is visible after " + x + " scrolls");
	}

	public void doubleClick(String strProductType, WebElement element) {

		if (validateElementPresent(strProductType, element)) {
			Actions action = new Actions(driver);
			// WebElement element=driver.findElement(element);
			action.moveToElement(element).doubleClick().perform();
		}

	}

	public void doubleClick(String strProductType, By eleLocator)
			throws Exception {

		if (validateElementPresentByLocator(strProductType, eleLocator)) {
			Actions action = new Actions(driver);
			WebElement element = driver.findElement(eleLocator);
			action.moveToElement(element).doubleClick().perform();
		}

	}

	public void sendKeys(String strElement, WebElement element, String strValue)
			throws Exception {

		try {
			element.click();
			// Thread.sleep(100);
			element.clear();
			// Thread.sleep(100);
			element.sendKeys(strValue);
			Thread.sleep(500);
			element.sendKeys(Keys.TAB);
			ReporterA.reportPassWithSnapshot(
					"Enter " + strValue + " in " + strElement + " text box",
					"Value should be entered",
					"Value Entered. Current Text ="
							+ element.getAttribute("value"), driver);
		} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Enter " + strValue + " in "
					+ strElement + " text box", "Value should be entered",
					"Value Entered. Current Text =" + element.getText()
							+ " Error " + e.getMessage(), driver);
		}

	}

	public void sendKeys(String strElement, WebElement element, Keys strValue)
			throws Exception {

		try {
			element.click();
			element.clear();
			Thread.sleep(20);
			element.sendKeys(strValue);
			element.sendKeys(Keys.TAB);
			ReporterA.reportPassWithSnapshot(
					"Enter " + strValue + " in " + strElement + " text box",
					"Value should be entered",
					"Value Entered. Current Text ="
							+ element.getAttribute("value"), driver);
		} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Enter " + strValue + " in "
					+ strElement + " text box", "Value should be entered",
					"Value Entered. Current Text =" + element.getText()
							+ " Error " + e.getMessage(), driver);
		}

	}
	
	

	public void sendKeys(String strElement, By locator, String strValue)
			throws Exception {

		WebElement element = WaitUtils.waitForElement(driver, locator, 10);

		try {
			element.click();
			Thread.sleep(500);
			element.clear();
			element.sendKeys(strValue);
			element.sendKeys(Keys.TAB);
			ReporterA.reportPassWithSnapshot(
					"Enter " + strValue + " in " + strElement + " text box",
					"Value should be entered",
					"Value Entered. Current Text ="
							+ element.getAttribute("value"), driver);
		} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Enter " + strValue + " in "
					+ strElement + " text box", "Value should be entered",
					"Value Entered. Current Text =" + element.getText()
							+ " Error " + e.getMessage(), driver);
		}

	}

	public void jsSendKeys(String strElement, WebElement element,
			String strValue) throws Exception {

		if (validateElementPresent(strElement, element)) {

			if (!element.isEnabled()) {

				JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

				try {
					// jsExecutor.executeScript("arguments[0].scrollIntoView(false);",
					// element);
					jsExecutor.executeScript("arguments[0].value=arguments[1]",
							element, strValue);
				} catch (Exception e) {
					e.printStackTrace();
					ReporterA.reportFailWithSnapshot("Enter " + strValue
							+ " in " + strElement + " text box",
							"Value should be entered",
							"Value Entered. Current Text =" + element.getText()
									+ " Error " + e.getMessage(), driver);
				}

			}
		}

	}

	public WebElement findElementByJquerySelector(String jQuerySelector) {

		Boolean injectJQry = (Boolean) jQryExecutor
				.executeScript("return this.$===undefined; ");
		System.out.println("injection required " + injectJQry);
		if (injectJQry) {
			System.out.println("Injecting jQuery");
			injectJquery();
		}

		System.out.println("return jQuery('" + jQuerySelector + "')[0];");

		// js.executeScript("return jQuery('input.gsfi[name=\"q\"]')[0];" );

		WebElement element = (WebElement) jQryExecutor
				.executeScript("return jQuery('" + jQuerySelector + "')[0]; ");

		return element;
	}

	private static String readFile(String file) {
		Charset cs = Charset.forName("UTF-8");
		FileInputStream stream = null;
		String strJQry = "";
		try {
			stream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Reader reader = new BufferedReader(
					new InputStreamReader(stream, cs));
			StringBuilder builder = new StringBuilder();
			char[] buffer = new char[8192];
			int read;
			while ((read = reader.read(buffer, 0, buffer.length)) > 0) {
				builder.append(buffer, 0, read);
			}
			strJQry = builder.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				stream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return strJQry;
	}

	public void wait(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void validateAndClick(String sElementIdentifier, WebElement element)
			throws Exception {
			if (validateElementPresent(sElementIdentifier, element)) {
		/*ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ "should be displayed", sElementIdentifier
					+ "is displayed", driver);*/
		 Thread.sleep(2);
					this.click(sElementIdentifier, element);

		} else {
			ReporterA.reportFailWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ " should be displayed", sElementIdentifier
					+ " is not displayed", driver);

		}
	}

	public void clickElementWoutValidation(String sElementIdentifier,
			WebElement element) {
		try {
			ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ "should be displayed", sElementIdentifier
					+ "is displayed", driver);
			element.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Unable to click the element "
					+ sElementIdentifier);
			e.printStackTrace();
		}
	}

	public void validateAndSendKeys(String sElementIdentifier,
			WebElement element, String strValue) throws Exception {

		/*if (validateElementPresent(sElementIdentifier, element)) {
			ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ " should be displayed", sElementIdentifier
					+ " is displayed", driver);*/
			this.sendKeys(sElementIdentifier, element, strValue);

		/*} else {
			ReporterA.reportFailWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ "  should be displayed", sElementIdentifier
					+ "is not displayed", driver);

		}*/
	}

	public void waitForLoading() {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

		try {
			new WebDriverWait(driver, 20).until(ExpectedConditions
					.invisibilityOfElementLocated(By
							.xpath("//img[@alt='Loading']")));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//Logger.LogMessage("Waited for loading----Done");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Waited for loading----NOt Successfull---Reinstated Implicit wait");
			e.printStackTrace();
		}

		// add a checkpoint here. if the wait still existing

	}
	

	

	public void validatePrepopulatedText(String sElementIdentifier,
			WebElement element, String strExpectedValue, String sElementType)
			throws Exception {

		if ("Input".equalsIgnoreCase(sElementType)) {
			strActualValue = element.getAttribute("value");
		} else if ("ReadOnly".equalsIgnoreCase(sElementType)) {
			strActualValue = element.getText();
		}

		if (strActualValue.equals(strExpectedValue)) {
			ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate pre-populated value ", strExpectedValue
					+ " should be displayed", strActualValue + " is displayed",
					driver);

		} else {
			ReporterA.reportFailWithSnapshot(sElementIdentifier
					+ " validate pre-populated value ", strExpectedValue
					+ " should be displayed", strActualValue
					+ " is not displayed", driver);
		}
	}

	public void validateAndSendKeys(String sElementIdentifier,
			WebElement element, String strValue, String strObjectType)
			throws Exception {

		if (validateElementPresent(sElementIdentifier, element)) {
			/*ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ " should be displayed", sElementIdentifier
					+ " is displayed", driver);*/
			this.sendKeys(sElementIdentifier, element, strValue, strObjectType);

		} else {
			ReporterA.reportFailWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ "  should be displayed", sElementIdentifier
					+ "is not displayed", driver);

		}
	}

	public void sendKeys(String strElement, WebElement element,
			String strValue, String strObjectType) throws Exception {

		try {
			element.click();
			Thread.sleep(100);
			element.clear();
			Thread.sleep(200);
			element.sendKeys(strValue);
			Thread.sleep(200);
			element.sendKeys(Keys.TAB);
			ReporterA.reportPassWithSnapshot(
					"Enter " + strValue + " in " + strElement + " text box",
					"Value should be entered",
					"Value Entered. Current Text ="
							+ element.getAttribute("value"), driver);
		} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Enter " + strValue + " in "
					+ strElement + " text box", "Value should be entered",
					"Value Entered. Current Text =" + element.getText()
							+ " Error " + e.getMessage(), driver);
		}

	}

	public void enterDate(String strElement, String strDate,
			List<WebElement> dateElements) throws Exception {
		String[] arrDate = strDate.split(" ");
		validateAndSendKeys(strElement + " -Date", dateElements.get(0),
				arrDate[0]);
		validateAndSendKeys(strElement + " -Month", dateElements.get(1),
				arrDate[1]);
		validateAndSendKeys(strElement + " -Year", dateElements.get(2),
				arrDate[2]);
	}

	// --------------RBS Components--------------------#############

	public void getAnythingFromTableInRBS(int tableNumber, int rowNum,
			int fieldNumber, String operation, String value) throws Exception {
		System.out.println("Value" + value);

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@type='radio']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@value='Please
		// select...']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[contains(@id,'ComboBox')]

		// table always with one row

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//div[last()][@class='BPMBorder']

		// table xpath to get all rows
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][3]/following-sibling::div[1]//div[last()][@class='BPMBorder']/div

		// find table from RBS
		List<WebElement> expTables = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
								+ tableNumber
								+ "]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTables != null) {
			// get the expected row from table
			// WebElement expRow =
			// expTable.findElement(By.xpath("div[last()][contains(@class,'BPMBorder')]/div["+rowNum+"]"));
			// if(expRow!=null){

			if (expTables.size() == 1) {
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
										+ tableNumber
										+ "]/following-sibling::div[1]"));

				if (operation.equalsIgnoreCase("radio")) {
					WebElement radioToClick = expTable
							.findElement(By
									.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[@type='radio']"));
					if (radioToClick != null) {
						validateAndClick("Radio Button", radioToClick);
					}
				} else if (operation.equalsIgnoreCase("input")) {
					List<WebElement> allInputs = null;
					try {
						allInputs = expTable
								.findElements(By
										.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[@value='Please select...']"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if (allInputs.size() > 1) {
						validateAndSendKeys("Input",
								allInputs.get(fieldNumber - 1), value);

					} else {
						/*
						 * WebElement input = expTable.findElement(By.xpath(
						 * "div[contains(@class,'BPMBorder')]")); WebElement
						 * checknext = input.findElement(By.xpath("div["+rowNum+
						 * "]//input[@value='Please select...']"));
						 */
						validateAndSendKeys("Input", allInputs.get(0), value);
					}
				} else if (operation.equalsIgnoreCase("textbox")) {
					List<WebElement> allInputs = expTable
							.findElements(By
									.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[contains(@id,'ComboBox')]"));
					if (allInputs.size() > 1) {
						validateAndSendKeys("Input",
								allInputs.get(fieldNumber - 1), value);

					} else {
						validateAndSendKeys("Input", allInputs.get(0), value);
					}
				} else if (operation.equalsIgnoreCase("checkbox")) {

					List<WebElement> allCheckBoxess = expTable
							.findElements(By
									.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[contains(@id,'CheckBox')]"));
					if (allCheckBoxess.size() > 1) {
						validateAndClick("Input",
								allCheckBoxess.get(fieldNumber - 1));

					} else {
						validateAndClick("Input", allCheckBoxess.get(0));
					}

				}
				// }
			} else if (expTables.size() > 1) {

				Logger.LogMessage("This page has more than one table at same position---Please check the table on the page");

			}

		} else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}

	// for dynamic tables
	public void validateMultipleTablesInRBSa(int dynamicTableNumber,
			int rowNum, int fieldNumber, String operation, String value)
			throws Exception {

		System.out.println("Value" + value);

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@type='radio']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@value='Please
		// select...']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[contains(@id,'ComboBox')]

		// table always with one row

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//div[last()][@class='BPMBorder']

		// table xpath to get all rows
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][3]/following-sibling::div[1]//div[last()][@class='BPMBorder']/div

		// find table from RBS
		List<WebElement> expTable = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTable != null) {
			// get the expected row from table
			// WebElement expRow =
			// expTable.findElement(By.xpath("div[last()][contains(@class,'BPMBorder')]/div["+rowNum+"]"));
			// if(expRow!=null){

			if (expTable.size() != 0) {
				// WebElement expTable
				// =driver.findElement(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1]"));

				if (operation.equalsIgnoreCase("radio")) {
					WebElement radioToClick = expTable
							.get(dynamicTableNumber - 1)
							.findElement(
									By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[@type='radio']"));
					if (radioToClick != null) {
						validateAndClick("Radio Button", radioToClick);
					}
				} else if (operation.equalsIgnoreCase("input")) {
					List<WebElement> allInputs = null;
					try {
						allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
										By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[@value='Please select...']"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if (allInputs.size() > 1) {
						validateAndSendKeys("Input",
								allInputs.get(fieldNumber - 1), value);

					} else {
						/*
						 * WebElement input = expTable.findElement(By.xpath(
						 * "div[contains(@class,'BPMBorder')]")); WebElement
						 * checknext = input.findElement(By.xpath("div["+rowNum+
						 * "]//input[@value='Please select...']"));
						 */
						validateAndSendKeys("Input", allInputs.get(0), value);
					}
				} else if (operation.equalsIgnoreCase("textbox")) {
					try {
						List<WebElement> allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
										By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[contains(@id,'ComboBox')]"));
						if (allInputs.size() > 1) {
							validateAndSendKeys("Input",
									allInputs.get(fieldNumber - 1), value);

						} else {
							validateAndSendKeys("Input", allInputs.get(0),
									value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				// }
			} else if (expTable.size() == 1) {

				Logger.LogMessage("Use the component---getAnythingfromtable Please...!!");

			}

		} else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}

	public void getAllRowsFromTableByColName(String expColname,
			String xpathKey, String matcherRow, String operation,
			String valuesToSelectOrSend) throws Exception {
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show']//span[text()='Full
		// Name']/../../../../following-sibling::div
		// WebElement mainTable =
		// driver.findElement(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']//span[text()='"+expColname+"']/../../../../following-sibling::div"));
		WebElement mainTable = findAnyWebElement(
				By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']//span[text()='"
						+ expColname + "']/../../../../following-sibling::div"),
				"Main Table");

		// iterate namewise from excel--main loop
		String vals[] = null;
		String valsToSelect[] = null;
		int counter = 1;

		if (matcherRow.contains(",")) {
			vals = matcherRow.split(",");
			counter = vals.length;
			// just for printing
			for (String j : vals) {
				System.out.println("Expected text from excel---" + j);
			}
		}

		if (valuesToSelectOrSend.contains(",")
				&& !valuesToSelectOrSend.equalsIgnoreCase("")) {
			valsToSelect = valuesToSelectOrSend.split(",");
			counter = valsToSelect.length;
			// just for printing
			for (String j : valsToSelect) {
				System.out.println("Expected text from excel---" + j);
			}
		}

		// Get expected row

		int expRow = 0;
		// boolean found = false;
		int valueCounter = 0;
		// total rows inside the table
		if (mainTable != null) {
			List<WebElement> allRows = mainTable.findElements(By
					.xpath("div/div"));
			Logger.LogMessage("Total Rows inside the main table---"
					+ (allRows.size() - 1));
			// return allRows;

			// new logic
			// find the row in which the element is located
			for (WebElement wEle2 : allRows) {

				List<WebElement> allSpans = wEle2.findElements(By
						.tagName("span"));
				for (WebElement wEle1 : allSpans) {
					System.out.println("Eleemnt text--" + wEle1.getText());

					for (int k = 0; k <= counter - 1; k++) {
						System.out.println("iterating the values from excel--"
								+ k);
						if (wEle1.getText().trim()
								.equalsIgnoreCase(vals[k].trim())) {

							// found=true;
							valueCounter++;
							expRow++;

							if (operation.equalsIgnoreCase("click")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);
								wEle.click();
							} else if (operation.equalsIgnoreCase("select")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								Select sel = new Select(wEle);
								sel.selectByValue(valsToSelect[k].trim());
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);

							} else if (operation.equalsIgnoreCase("sendkeys")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								validateAndSendKeys("Select Group", wEle,
										valsToSelect[k].trim());
								// wEle.sendKeys(valsToSelect[k].trim());
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);
							}
							// select logic

						}

					}
				}
				// i++;
				if (valueCounter == counter) {
					break;
				}
			}

			// click anything inside expected row

			// wEle.findElement(by).click();

		} else {
			System.out.println("null");
		}

	}

	public WebElement findAnyWebElement(By by, String eleName) {
		WebElement eLe = null;
		try {
			eLe = driver.findElement(by);
			Logger.LogMessage("Finding Element---Success---" + eleName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Finding Element---Not Success---try Again--Proceeding further"
					+ eleName);
			e.printStackTrace();
		}

		return eLe;
	}

	public boolean switchToCompleteAccntAppFrame(WebDriver driver) {
		waitForLoading();
		// By.xpath("//iframe[contains(@title,'Complete Account Application')]")
		try {
			WebElement iFrame = driver
					.findElement(By
							.xpath("//iframe[contains(@title,'Complete Account Application')]"));
			String iFrameTitle = iFrame.getAttribute("title");

			driver.switchTo().frame(iFrame);
			Logger.LogMessage("Switched to frame---Success---" + iFrameTitle);
			completeAppFrame = true;
			return true;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Switched to frame---Not Success");
			e.printStackTrace();
			completeAppFrame = false;
			return false;
		}

	}
	
	public void validateAndSendKeysWoutClick(String sElementIdentifier,
			WebElement element, String strValue) throws Exception {

		if (validateElementPresent(sElementIdentifier, element)) {
			/*ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ " should be displayed", sElementIdentifier
					+ " is displayed", driver);*/
			this.sendKeysWoutClick(sElementIdentifier, element, strValue);

		} else {
			ReporterA.reportFailWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ "  should be displayed", sElementIdentifier
					+ "is not displayed", driver);

		}
	}
	
	
	public void sendKeysWoutClick(String strElement, WebElement element, String strValue)
			throws Exception {

		try {
			
			element.clear();
			// Thread.sleep(100);
			element.sendKeys(strValue);
			Thread.sleep(500);
			element.sendKeys(Keys.TAB);
			ReporterA.reportPassWithSnapshot(
					"Enter " + strValue + " in " + strElement + " text box",
					"Value should be entered",
					"Value Entered. Current Text ="
							+ element.getAttribute("value"), driver);
		} catch (Exception e) {
			ReporterA.reportFailWithSnapshot("Enter " + strValue + " in "
					+ strElement + " text box", "Value should be entered",
					"Value Entered. Current Text =" + element.getText()
							+ " Error " + e.getMessage(), driver);
		}

	}
}
