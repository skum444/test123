package com.rbs.pages;

import java.util.Map;
import org.openqa.selenium.support.PageFactory;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.pages.BasePage;

//import org.apache.commons.io.FileUtils;

public class ConfirmCreditCheckDBValidation extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	
	private String aTestDataSheetName = "LoginPage1";
	private String bTestDataSheetName = "PersonaliseYourQuote";
	private String cTestDataSheetName = "ConfirmDetails";
	private String dTestDataSheetName = "AJConditionChecks";
	String sTestDataSheetName;

	//OracleDBUtils o1= new OracleDBUtils();
	//BusinessBankingLoginPage1 bizobj = null;
	SetPageName s1= null;

	public static String projectedturnover;
	public static String Netprofit;
	public static String EntityType;
	public static String TotAggBusDebt;
	public static String FraudMarkerBIN;
	public static String FraudMarkerCIN;
	public static String KYCBIN;
	public static String KYCCIN;
	public static String PEP;
	public static String DOB;
	public static String NoOfKP;
	public static String COR;
	public static String CINCreditGrade;
	public static String BINCreditGrade;
	public static String BINCRMMarker;
	public static String CINCRMMarker;
	public static String DBId;
	public static String Amount;
	public static String Term;
	public static String NameKP1;
	public static String NameKP2;
	public static String BICompanyName;
	public static String BIAddress;
	public static String BICompanyRegNumber;
	public static String AddressKP1;
	public static String AddressKP2;
	public static String DOBKP1;
	public static String DOBKP2;
	public static String EmailAddress;
	public static String TelNO;
	
	//Welcome w1 = new Welcome ();
	public ConfirmCreditCheckDBValidation() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void inputValuesInConfirmDetailsDB(String ApplicationID,String sTestName,int rowcount)
			throws Exception {
		try
		{
			sTestDataSheetName = sTestName+"_credit";
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
					aTestDataSheetName, sTestName);
			Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
					bTestDataSheetName, sTestName);
			Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
					cTestDataSheetName, sTestName);
			Map<String, String> tdrRow = ExcelUtils.getTestDataRow_BB(
					dTestDataSheetName, sTestName);
			
			
			
			DBId = tdRow.get("Customer Number");
			projectedturnover = tdqRow.get("projected turnover");
			Netprofit = tdqRow.get("net profit");
			EntityType = tdqRow.get("LegalEntity");
			TotAggBusDebt = tdrRow.get("TotAggrBusDebt");
			FraudMarkerBIN = tdrRow.get("FraudMarkerBIN");
			FraudMarkerCIN = tdrRow.get("FraudMarkerCIN");
			KYCBIN = tdrRow.get("KYCBIN");
			KYCCIN = tdrRow.get("KYCCIN");
		     PEP = tdrRow.get("PoliticallyExposed");
			DOB = tdrRow.get("DOB");
			COR = tdrRow.get("CountryOfResidence");
			CINCreditGrade = tdrRow.get("CINCreditGradeCode");
			BINCreditGrade = tdrRow.get("BINcreditGradecode");
			BINCRMMarker = tdrRow.get("BINCRMMarker");
			CINCRMMarker = tdrRow.get("CINCRMMarker");
			
			int rowcount1 = 61;
			Amount = tdpRow.get("AmountSliderValue");
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Amount",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,Amount,rowcount1,3);
			rowcount1++;
			Term = tdpRow.get("TermSliderValue");
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Term",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,Term,rowcount1,3);
			rowcount1++;
			NoOfKP = tdrRow.get("NoOfKP");
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"NoOfKP",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,NoOfKP,rowcount1,3);
			
			
		}	
			catch ( Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			
		}
			//Getting data from UI
			
			public void inputValuesInConfirmDetailsUI(String ApplicationID,String sTestName,int rowcount)
					throws Exception {
				try
				{
					
					sTestDataSheetName = sTestName+"_credit";
					
					Map<String, String> tdrRow = ExcelUtils.getTestDataRow_BB(
							dTestDataSheetName, sTestName);
					Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
							cTestDataSheetName, sTestName);
					
					
					ExcelUtils.createExcelSheetMethod(sTestDataSheetName, ApplicationID);
			if (tdrRow.get("NoOfKP").equalsIgnoreCase("2"))
					{
				int rowcount1 = 64;
		NameKP1 = commoncomps.ZambesiCreditgetText("Profile Icon", 0, NameKP1);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"NameKP1",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,NameKP1,rowcount1,1);
			rowcount1++;
		 NameKP2 = commoncomps.ZambesiCreditgetText("Profile Icon", 1, NameKP2);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"NameKP2",rowcount1,0);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,NameKP2,rowcount1,1);
		 rowcount1++;
		 BICompanyName = commoncomps.ZambesiCreditgetTextBI(0, BICompanyName);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BICompanyName",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BICompanyName,rowcount1,1);
			rowcount1++;
		BIAddress = commoncomps.ZambesiCreditgetTextBI(1, BIAddress);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIAddress",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BIAddress,rowcount1,1);
		rowcount1++;
		if((tdqRow.get("LegalEntity").equalsIgnoreCase("Limited")))
				{
		BICompanyRegNumber = commoncomps.ZambesiCreditgetTextBI(2, BICompanyRegNumber);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BICompanyRegNumber",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BICompanyRegNumber,rowcount1,1);
		rowcount1++;
				}
		 AddressKP1 = commoncomps.ZambesiCreditgetTextAdd(0, AddressKP1);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddressKP1",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AddressKP1,rowcount1,1);
			rowcount1++;
		 AddressKP2 = commoncomps.ZambesiCreditgetTextAdd(1, AddressKP2);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddressKP2",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AddressKP2,rowcount1,1);
			rowcount1++;
	     DOBKP1 = commoncomps.ZambesiCreditgetTextDOB(0, DOBKP1);
	     ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"DOBKP1",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,DOBKP1,rowcount1,1);
			rowcount1++;
		 DOBKP2 = commoncomps.ZambesiCreditgetTextDOB(1, DOBKP2);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"DOBKP2",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,DOBKP2,rowcount1,1);
			rowcount1++;
		EmailAddress = commoncomps.ZambesiCreditgetTextwithoutList("Email Icon", EmailAddress);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"EmailAddress",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,EmailAddress,rowcount1,1);
			rowcount1++;
		 TelNO = commoncomps.ZambesiCreditgetTextwithoutListTelNO("Telephone Icon", TelNO);
		 ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"TelNO",rowcount1,0);
			ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,TelNO,rowcount1,1);
					}
			else if(tdrRow.get("NoOfKP").equalsIgnoreCase("1"))
{
				int rowcount1 = 64;
				NameKP1 = commoncomps.ZambesiCreditgetTextwithoutList("Profile Icon", 0, NameKP1);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"NameKP1",rowcount1,0);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,NameKP1,rowcount1,1);
					rowcount1++;
	           DOBKP1 = commoncomps.ZambesiCreditgetTextDOBwithoutList(0, DOBKP1);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"DOBKP1",rowcount1,0);
				    ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,DOBKP1,rowcount1,1);
					rowcount1++;	
			  AddressKP1 = commoncomps.ZambesiCreditgetTextAddwithoutList(0, AddressKP1);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddressKP1",rowcount1,0);
				    ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AddressKP1,rowcount1,1);
					rowcount1++;
			BICompanyName = commoncomps.ZambesiCreditgetTextBI(0, BICompanyName);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BICompanyName",rowcount1,0);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BICompanyName,rowcount1,1);
					rowcount1++;
			BIAddress = commoncomps.ZambesiCreditgetTextBI(1, BIAddress);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIAddress",rowcount1,0);
					ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BIAddress,rowcount1,1);
					rowcount1++;
					if((tdqRow.get("LegalEntity").equalsIgnoreCase("Limited")))
					{
						BICompanyRegNumber = commoncomps.ZambesiCreditgetTextBI(2, BICompanyRegNumber);
						ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BICompanyRegNumber",rowcount1,0);
						ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BICompanyRegNumber,rowcount1,1);
						rowcount1++;
	}
					}
			
			
				}
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
}