package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;

//import org.apache.commons.io.FileUtils;

public class KeySignatories extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	private String sTestDataSheetName = "KeySignatory";
	private String pTestDataSheetName = "ConfirmDetails";
	//BusinessBankingLoginPage1 bizobj = null;
	SetPageName s1= null;
	public String totalKP1 = null;
	public int totalKP = 0;
	public String  fininformation;
	public static String KPage;
	
	public String Status;
	public static String longtermaddress; 
	public KeySignatories() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void inputValuesInKeySignatories(String sTestName)
			throws Exception {
		try
		{
			s1.setupTestName(sTestDataSheetName +"_"+sTestName,"chrome",sTestDataSheetName+"_"+sTestName);
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
					sTestDataSheetName, sTestName);
			Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
					pTestDataSheetName, sTestName);
			
			
			//commoncomps.waitForLoading();	
		//	commoncomps.waitForPageHeaderToAppear("Key signatories");
			commoncomps.sleepTime(3);
			 totalKP1 = tdRow.get("totalNoOfKP");
			 totalKP = Integer.parseInt(totalKP1);
			 
			 
			 for(int KP=1;KP<=totalKP;KP++)
			{
				//KP=1
				 if(KP==1)
				 {
					 
				 if((KP==1)&& (totalKP==1) || (KP==1)&& (totalKP==2))
				{
					commoncomps.ZambesiDropDown(driver,"moveMonth", tdRow.get("Month"));
					commoncomps.ZambesiDropDown(driver,"moveYear", tdRow.get("Year"));
				}
				
				else
					if((KP==1)&& (totalKP>2))
					{
						commoncomps.ZambesiDropDownCredit(driver,"moveMonth", tdRow.get("Month"), 1);
						commoncomps.ZambesiDropDownCredit(driver,"moveYear", tdRow.get("Year"), 1);
			    }
				
String KP1age = tdRow.get("Age");
int KP1age1 = Integer.parseInt(KP1age);
String KP2age = tdRow.get("AgeKS2");
int KP2age2 = Integer.parseInt(KP2age);

if(( KP1age1 > 65) || ( KP2age2 > 65))
{
	KPage = "KP Age is high";
}
else
{
	KPage = "KP Age is not high";
}

		
		

	
	commoncomps.clickAnylinkInZambesiCredit("Why do we ask this?");
	if (tdRow.get("TheseDetailsAren'tRightKeySig1").equalsIgnoreCase("Yes"))
	{
		
		commoncomps.clickAnylinkInZambesiCreditTheseDetails(driver,"These details are", 1);
		
		commoncomps.inputInTextBoxZambesiCredit(driver, "signPersonName", tdRow.get("Name"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "signPersonDob", tdRow.get("DOB"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "flatHouseOrBuildingName", tdRow.get("Flat_nameKS2"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine1", tdRow.get("AddLine1KS2"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine2", tdRow.get("AddLine2KS2"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine3", tdRow.get("Town/CityKS2"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine4", tdRow.get("Country/RegionKS2"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "postcode", tdRow.get("PostcodeKS2"));
		
		if (tdRow.get("SavechangesKeySig1").equalsIgnoreCase("Yes"))
		{
			
		commoncomps.clickAnybuttonInZambesi("Save changes");
		}
		else{
			commoncomps.clickAnylinkInZambesiCredit("Cancel changes");
		}
		
		
	}
	 fininformation= ConfirmDetailsAndCreditCheck_1.fininfo;
	if(fininformation.equalsIgnoreCase("Yes"))
	{
		commoncomps.ZambesiRadioButtonCredit(driver,"radiopiMain-propertyOwner",tdRow.get("propertyOwner"));
		commoncomps.ZambesiRadioButtonCredit(driver,"radiopiMain-incomeFromBusiness",tdRow.get("DoYouReceiveIncome"));
	}
	
// Steps to check if the address changed is less
	String y = tdRow.get("Year");
	int year = Integer.parseInt(y);
// to fetch current year
	Calendar now = Calendar.getInstance();
	int currentyear = now.get(Calendar.YEAR);
	
	int Diffyear = currentyear-3;
	
	if((year>Diffyear)||((year==Diffyear)))
	{
		longtermaddress = "No";
	
	commoncomps.inputInTextBoxZambesi(driver, "postcodeInput", tdRow.get("PostcodeKS"));
	if (tdRow.get("FindAddress").equalsIgnoreCase("Yes"))
	{
	commoncomps.clickAnybuttonInZambesi("Find address");
	//commoncomps.ZambesiDropDown(driver, tdRow.get("SelectFromList"));
	// need to confirm on the month and year field if they are same as above
	//commoncomps.ZambesiDropDown(driver, tdRow.get("Month1"));
	//commoncomps.ZambesiDropDown(driver, tdRow.get("Year1"));
	}
	if (tdRow.get("enterAddressManually").equalsIgnoreCase("Yes"))
	{
		commoncomps.clickAnylinkInZambesiCredit("address manually");
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine1", tdRow.get("Flat_name"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine2", tdRow.get("AddLine1KS"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine3", tdRow.get("AddLine2KS"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine4", tdRow.get("Town/CityKS"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine5", tdRow.get("Country/RegionKS"));
		commoncomps.inputInTextBoxZambesiCredit(driver, "postcode", tdRow.get("PostcodeKS2"));
	}
	}
	else
	{
		longtermaddress = "Yes";
	}

				}
//KP=2
else if (KP==2)
{
	//commoncomps.ZambesiDropDownCredit(driver,"moveMonth", tdRow.get("MonthKS2"), 1);
	//commoncomps.ZambesiDropDownCredit(driver,"moveYear", tdRow.get("YearKS2"), 1);
	
	if (tdRow.get("TheseDetailsAren'tRightKeySig2").equalsIgnoreCase("Yes"))
	{
		commoncomps.clickAnylinkInZambesiCreditTheseDetails(driver,"These details are", 2);
		
		/*commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-name", tdRow.get("NameKS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-dob", tdRow.get("DOBKS3"));*/
if(tdRow.get("Email_add").equalsIgnoreCase("Null"))
{
	commoncomps.ZambesiCheckbox(driver, "Signatory does not have an email address");
}
else
{
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-email", tdRow.get("Email_add"));
		//commoncomps.inputInTextBoxZambesi(driver, "Confirm email address", tdRow.get("ConfirmEmail_add"));
}
if(tdRow.get("Mob_PN").equalsIgnoreCase("Null"))
{
	commoncomps.ZambesiCheckbox(driver, "Signatory does not have an mobile phone number");
}
else
{
		commoncomps.inputInTextBoxZambesi(driver, "phoneNumber", tdRow.get("Mob_PN"));
}
		/*commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-flatHouseOrBuildingName", tdRow.get("Flat_nameKS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-addressLine1", tdRow.get("AddLine1KS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-addressLine2", tdRow.get("AddLine2KS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-addressLine3", tdRow.get("Town/CityKS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-addressLine4", tdRow.get("Country/RegionKS3"));
		commoncomps.inputInTextBoxZambesi(driver, "secondarySignatory-postcode", tdRow.get("PostcodeKS3"));*/
		
		if (tdRow.get("SavechangesKeySig2").equalsIgnoreCase("Yes"))
		{
			
		commoncomps.clickAnybuttonInZambesi("Save changes");
		}
		else{
			commoncomps.clickAnylinkInZambesiCredit("Cancel changes");
		}
	}
	commoncomps.ZambesiDropDownCredit(driver,"moveMonth", tdRow.get("MonthKS2"), 1);
	commoncomps.ZambesiDropDownCredit(driver,"moveYear", tdRow.get("YearKS2"), 1);
	// Steps to check if the address changed is less
		String y = tdRow.get("YearKS2");
		int year = Integer.parseInt(y);
	// to fetch current year
		Calendar now = Calendar.getInstance();
		int currentyear = now.get(Calendar.YEAR);
		
		int Diffyear = currentyear-3;
		
		if((year>Diffyear)||((year==Diffyear)))
		{
		
		commoncomps.inputInTextBoxZambesi(driver, "postcodeInput", tdRow.get("PostcodeKS"));
		if (tdRow.get("FindAddress").equalsIgnoreCase("Yes"))
		{
		commoncomps.clickAnybuttonInZambesi("Find address");
		//commoncomps.ZambesiDropDown(driver, tdRow.get("SelectFromList"));
		// need to confirm on the month and year field if they are same as above
		//commoncomps.ZambesiDropDown(driver, tdRow.get("Month1"));
		//commoncomps.ZambesiDropDown(driver, tdRow.get("Year1"));
		}
		if (tdRow.get("enterAddressManually").equalsIgnoreCase("Yes"))
		{
			commoncomps.clickAnylinkInZambesiCredit("address manually");
			commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine1", tdRow.get("Flat_name"));
			commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine2", tdRow.get("AddLine1KS"));
			commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine3", tdRow.get("AddLine2KS"));
			commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine4", tdRow.get("Town/CityKS"));
			commoncomps.inputInTextBoxZambesiCredit(driver, "addressLine5", tdRow.get("Country/RegionKS"));
			commoncomps.inputInTextBoxZambesiCredit(driver, "postcode", tdRow.get("PostcodeKS2"));
		}
		}
	
		if(fininformation.equalsIgnoreCase("Yes"))
		{
		commoncomps.ZambesiRadioButtonCredit(driver,"radiopiSecondary-propertyOwner",tdRow.get("propertyOwner"));
		commoncomps.ZambesiRadioButtonCredit(driver,"radiopiSecondary-incomeFromBusiness",tdRow.get("DoYouReceiveIncome"));
	}
}
				}
				
	

					}
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
}