package com.rbs.pages;

import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.bpm.automation.bbconnect.objects.TestCase;

public class SetPageName {
	
	TestCase currentTest;
	
	public void setupTestName(String M, String Browser, String context) throws Exception {

		
		/*currentTest.setName(Pagename);
		ReporterA.initTest(currentTest);*/
		
		

		if (null == currentTest) {
			currentTest = new TestCase();
		}

		currentTest.setE2eSetName(context);
		currentTest.setName(M);
		currentTest.setDescription(M);
		currentTest.setStartTime(GenericUtils.getDateTime());
		currentTest.setBrowser(Browser);

		ReporterA.initTest(currentTest);
		//ReporterA.initTestss(currentTest);

		
	}
	
	public String getTestName()
	{
		return currentTest.getName();
	}
	
}
