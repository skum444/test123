package com.rbs.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;


//import org.apache.commons.io.FileUtils;

public class BusinessBankingLoginPage2 extends BasePage{

	
		BBConnectUtils commoncomps = new BBConnectUtils();
		BBUtils bbComps = new BBUtils();
		private String sTestDataSheetName = "LoginPage2";
		BusinessBankingLoginPage2 bb2obj = null;
		SetPageName s1= null;
		public String Status;
		String AuthenticationToken;
		String cookie;
		private Scanner txtscan;
		private Writer writerab;
		public BusinessBankingLoginPage2() {
			super();
			PageFactory.initElements(getDriver(), this);
			//bb2obj = new BusinessBankingLoginPage2();
			s1= new SetPageName();
			
		}
	
		public void inputValuesInBBlogin2Page(String sTestName, String rownum, String sheetName)
				throws Exception {
			try
			{
				s1.setupTestName(sTestDataSheetName +"_"+sTestName,"chrome",sTestDataSheetName+"_"+sTestName);
				/*Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
						sTestDataSheetName, sTestName);*/
				commoncomps.waitForPageHeaderToAppear("Business banking login");
				String secid = "1212";
				// get security pin number and update the fields
				int i=1;
				for (  i=1;i<=3; i++)
				{
				
				String secpin = commoncomps.getlabeltext("pin"+i,"pin-pass-label" );
				String pinpos = secpin.replaceAll("[^0-9]+", "").trim();
				int pinposnum = Integer.parseInt(pinpos);
				//System.out.println(" The value of label"+i+ "is" +pinposnum);
				char secvalue = secid.charAt(pinposnum-1);
				//System.out.println(" The value of secid"+" at pinposition "+ pinposnum+ "is" +secvalue);
				commoncomps.updateSecPin("pin"+i,"pin-pass-input",secvalue);
				
				}
				String secpwd = "S1XDIG";
				int j=1;
				for ( j=1;j<=3;j++)
				{
				//String secpwd1 = commoncomps.getlabeltext("pin-pass-label", "pwd"+j);
					String secpwd1 = commoncomps.getlabeltext("pwd"+j,"pin-pass-label" );
				String pinpos = secpwd1.replaceAll("[^0-9]+", "").trim();
				int pinposnum = Integer.parseInt(pinpos);
				char secvalue = secpwd.charAt(pinposnum-1);
				//System.out.println(" The value of secpwd"+" at pwdposition "+ pinposnum+ " is " +secvalue);
				commoncomps.updateSecPin("pwd"+j,"pin-pass-input",secvalue);
				
				} 
				ReporterA.reportPassWithSnapshot("login step 2"
						+ " validate if present ", "login step 2"
						+ "should be displayed", "login step 2"
						+ "is displayed", driver);
				commoncomps.sleepTime(3);
				commoncomps.clickContButton("Login");
				commoncomps.sleepTime(10);
				File file = new File("PerformanceLog.txt");
				File Tokenfile = new File("Token.txt");
				try (Writer writer = new BufferedWriter(new FileWriter(file))) {
				for (LogEntry entry : driver.manage().logs().get(LogType.PERFORMANCE)) {
                  //  System.out.println(entry.toString());
                    	writer.write(entry.toString());
                       ((BufferedWriter) writer).newLine();   
                }
				}
				
				System.out.println("Performance logs have been captured"+file.getAbsolutePath());
				txtscan = new Scanner(file);
				while(txtscan.hasNextLine()){
				    String str = txtscan.nextLine();
				if (str.indexOf("Bearer") != -1) {
					/*
					 * System.out.println("EXISTS");
					 * 
					 * System.out.println(str);
					 */

					String result[] = str.split("Bearer");
					// System.out.println(result[1]);

					String token = result[1].substring(0, 29);
					// System.out.println(token);

					if (!((token.contains("headersText")) || (token.contains("expires")))) {
						AuthenticationToken = token;
						// System.out.println(AuthenticationToken);
					}
				} 
				if (str.contains("BBCONNECT_TOKEN=")) {
					String result1[] = str.split("BBCONNECT_TOKEN=");
					String bbConnect=new String(result1[1].substring(0, result1[1].indexOf(";")));
					
					//System.out.println("---UnEscaped-----"+bbConnect);
					//cookie =StringEscapeUtils.unescapeHtml4(bbConnect);
					cookie="BBCONNECT_TOKEN="+bbConnect.replaceAll("\\\\\"", "\"");
//					/System.out.println("Cookie--------------------------"+cookie);
				}
				        
				}
				try (PrintStream out = new PrintStream(new FileOutputStream(Tokenfile))) {
				    out.print(AuthenticationToken);
				}
				// To write the auth token to Excel sheet
				String sname = System.getProperty("user.dir") + "\\testdata\\DJ1 Result.xls";
				FileInputStream fis1 = new FileInputStream(sname);
				HSSFWorkbook wb1 = new HSSFWorkbook(fis1);
				int rowNumber = Integer.parseInt(rownum);
				
		        HSSFSheet sheet = wb1.getSheet(sheetName);
		        
		        Row row = sheet.getRow(rowNumber);
				
				Cell cell = row.getCell(5);
				cell.setCellType(Cell.CELL_TYPE_STRING);
				cell.setCellValue(AuthenticationToken);
				Cell cell1 = row.getCell(4);
				cell1.setCellType(Cell.CELL_TYPE_STRING);
				cell1.setCellValue(cookie);
				
				FileOutputStream fos1 = new FileOutputStream(System.getProperty("user.dir") + "\\testdata\\DJ1 Result.xls");
				wb1.write(fos1);
				fos1.close();
				Status = "Pass";
				
			
			}
			catch ( Exception e)
			{
				Status = "Fail";
				System.out.println(e);
				e.printStackTrace();
			}
			
		}

}
