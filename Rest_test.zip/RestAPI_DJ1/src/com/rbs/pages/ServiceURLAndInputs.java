package com.rbs.pages;

import java.util.Map;

import com.rbs.utils.ExcelUtils;
import com.rbs.utils.GenericUtils;

public class ServiceURLAndInputs extends BasePage {
	
	/**
	 * Fetches the Sceario details like URL and test data 
	 * @param serviceName
	 * @param sceNum
	 * @return Map containing all service input data
	 */
	public Map<String, String> getScenarioDetails(String serviceName, String sceNum)	{
		Map<String, String> scenarioData=ExcelUtils.getScenarioTestData(serviceName, sceNum);
		if(serviceName.equals("Purpose")||serviceName.equals("SubPurpose")||serviceName.equals("BorrowingNeeds")){
			serviceName+="_"+scenarioData.get("Brand").toUpperCase();
		}
		System.out.println(serviceName);
		scenarioData.put("URL", GenericUtils.getProperty(serviceName));
		return scenarioData;
	 }
	

}
		    

	
	


