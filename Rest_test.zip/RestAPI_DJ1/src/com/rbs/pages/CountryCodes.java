package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class CountryCodes extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	 String json;
	Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void CountryCodesMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
	
	document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
    
    String CountryName1 = ServiceValueForStringRet(0);
    
    String CountryCode1 = ServiceValueForStringRetCountryCode(0);
    
    String CountryName2 = ServiceValueForStringRet(1);
    
    String CountryCode2 = ServiceValueForStringRetCountryCode(1);
    
    String CountryName3 = ServiceValueForStringRet(2);
    
    String CountryCode3 = ServiceValueForStringRetCountryCode(2);
    
    String CountryName4 = ServiceValueForStringRet(3);
    
    String CountryCode4 = ServiceValueForStringRetCountryCode(3);
    
    String CountryName5 = ServiceValueForStringRet(4);
    
    String CountryCode5 = ServiceValueForStringRetCountryCode(4);
    
    String CountryName6 = ServiceValueForStringRet(5);
    
    String CountryCode6 = ServiceValueForStringRetCountryCode(5);
    
    String CountryName7 = ServiceValueForStringRet(6);
    
    String CountryCode7 = ServiceValueForStringRetCountryCode(6);
    
    String CountryName8 = ServiceValueForStringRet(7);
    
    String CountryCode8 = ServiceValueForStringRetCountryCode(7);
    
    String CountryName9 = ServiceValueForStringRet(8);
    
    String CountryCode9 = ServiceValueForStringRetCountryCode(8);
    
    String CountryName10 = ServiceValueForStringRet(9);
    
    String CountryCode10 = ServiceValueForStringRetCountryCode(9);
    
    String CountryName11 = ServiceValueForStringRet(10);
    
    String CountryCode11 = ServiceValueForStringRetCountryCode(10);
    
    String CountryName12 = ServiceValueForStringRet(11);
    
    String CountryCode12 = ServiceValueForStringRetCountryCode(11);
    
    String CountryName13 = ServiceValueForStringRet(12);
    
    String CountryCode13 = ServiceValueForStringRetCountryCode(12);
    
    String CountryName14 = ServiceValueForStringRet(13);
    
    String CountryCode14 = ServiceValueForStringRetCountryCode(13);
    
    String CountryName15 = ServiceValueForStringRet(14);
    
    String CountryCode15 = ServiceValueForStringRetCountryCode(14);
    
    String CountryName16 = ServiceValueForStringRet(15);
    
    String CountryCode16 = ServiceValueForStringRetCountryCode(15);
    
    String CountryName17 = ServiceValueForStringRet(16);
    
    String CountryCode17 = ServiceValueForStringRetCountryCode(16);
    
    String CountryName18 = ServiceValueForStringRet(17);
    
    String CountryCode18 = ServiceValueForStringRetCountryCode(17);
    
    String CountryName19 = ServiceValueForStringRet(18);
    
    String CountryCode19 = ServiceValueForStringRetCountryCode(18);
    
    String CountryName20 = ServiceValueForStringRet(19);
    
    String CountryCode20 = ServiceValueForStringRetCountryCode(19);
   
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Country Code";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName5,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode5",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode5,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName6,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode6",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode6,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName7",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName7,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode7",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode7,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName8",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName8,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode8",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode8,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName9",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName9,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode9",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode9,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName10",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName10,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode10",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode11,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName11",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName11,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode11",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode11,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName12",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName12,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode12",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode12,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName13",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName13,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode13",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode13,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName14",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName14,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode14",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode14,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName15",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName15,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode15",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode15,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName16",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName16,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode16",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode16,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName17",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName17,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode17",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode17,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName18",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName18,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode18",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode18,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName19",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName19,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode19",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode19,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryName20",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryName20,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CountryCode20",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryCode20,rowcount,1);
	rowcount++;
	
	

   
	}
	
	
	String MicroServiceStrValue;
	

	String ServiceValueForStringRet(int indexValue)
	{
		System.out.println(indexValue);
		try
		{
		MicroServiceStrValue = JsonPath.read(document,"$.countryCodes["+indexValue+"].country");
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueForStringRetCountryCode(int indexValue)
	{
		
		try
		{
		MicroServiceStrValue = JsonPath.read(document,"$.countryCodes["+indexValue+"].countryCode");
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	

	}

	
	
	


