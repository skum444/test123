package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;
import com.sun.jna.platform.win32.Advapi32Util.Account;

//import org.apache.commons.io.FileUtils;

public class Accountdetails extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	
	private String pTestDataSheetName = "PersonaliseYourQuote";
	private String tTestDataSheetName = "Account details";
	public static String sortcode;
	public static String Accountnumber;
	public static String repayaccnumber;
	public static String repayscode;
	public String Sameact;
	public String accountholder;
	public String code;
	public String account;
	public String ODLimit1;
	public String ODLimit2;
	public String ODLimit3;
	public static String application_id;
	public static String appl_ID;
	public static String preContractInformationText;
	//BusinessBankingLoginPage1 bizobj = null;
	SetPageName s1= null;
	public String Status;
	
	
	public Accountdetails() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void paymentDetails(String sTestName)
			throws Exception {
		try
		{
			
			s1.setupTestName(tTestDataSheetName +"_"+sTestName,"chrome",tTestDataSheetName+"_"+sTestName);
			Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
					pTestDataSheetName, sTestName);
			Map<String, String> tdtRow = ExcelUtils.getTestDataRow_BB(
					tTestDataSheetName, sTestName);
			//scroll up code
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,-250)","");
			account = tdpRow.get("Account");
			if((tdpRow.get("LombardApplicable").equalsIgnoreCase("No"))&&(tdpRow.get("CardsApplicable").equalsIgnoreCase("No"))&&(!(tdpRow.get("Account").equalsIgnoreCase("OAJ"))))
			{
				//s1.setupTestName(tTestDataSheetName+"_"+sTestName,"chrome",tTestDataSheetName+"_"+sTestName);
			// get security pin number and update the fields
			//Customer Number
				
			String loanApplicable = tdpRow.get("loanApplicable");
			String Feederacct = tdpRow.get("Feederacct");
			String Sameact=tdtRow.get("Sameact");
			//String OverdraftApplicable=tdpRow.get("OverdraftApplicable");
			
			
			if((loanApplicable.equalsIgnoreCase("Yes"))&&(Feederacct.equalsIgnoreCase("No")))
			{
			commoncomps.waitForLoading();	
			commoncomps.pageheader("Tell us what to do with your loan");
			
			jse.executeScript("window.scrollBy(0,-250)","");
			ReporterA.reportPassWithSnapshot("Account Details"
					+ " validate if present ", "Account Details"
					+ "should be displayed", "Account Details"
					+ "is displayed", driver);
			application_id= commoncomps.getapplid("PaymentDetails_referenceID_PM5T");
			String app_ID[]= application_id.split(":");
			appl_ID= app_ID[1].trim();
			sortcode = commoncomps.Togettextfromrecevaccdetails("Sort code:");
		
			//System.out.println(sortcode);
			Accountnumber = commoncomps.Togettextfromrecevaccdetails("Account number:");
			//System.out.println(Accountnumber);
			
			commoncomps.sleepTime(3);
			commoncomps.Togettext("Where you want to make repayments from");
			
			if(Sameact.equalsIgnoreCase("Y"))
			{
			//commoncomps.ZambesiRadioButton(driver, "radiosameAccount");
			commoncomps.waitForLoading();	
			//commoncomps.ZambesiDropDown(driver, "Business Current  - XXXX7624");
			commoncomps.sleepTime(5);
			//String repayaccnumber,repayscode;
			repayscode= commoncomps.Togettextfromrepayaccdetails("Sort code:");
			//System.out.println(repayscode);
			repayaccnumber = commoncomps.Togettextfromrepayaccdetails("Account number:");
			//System.out.println(repayaccnumber);
			}
			else if(Sameact.equalsIgnoreCase("N"))
			{
				commoncomps.ZambesidiffRadioButton(driver, "radionewAccount");
				commoncomps.waitForLoading();
				commoncomps.inputInTextBoxZambesi(driver, "nameOfAccountHolder", tdtRow.get("Account Holder"));
				//System.out.println(accountholder);
				commoncomps.inputInTextBoxZambesi(driver, "sortCode", tdtRow.get("sort code"));
				//System.out.println(code);
				commoncomps.inputInTextBoxZambesi(driver, "accountNumber", tdtRow.get("acctno"));
				//System.out.println(account);
				
			}
			
			commoncomps.date(driver, tdtRow.get("repaydate"));
			commoncomps.clickAnybuttonInZambesi("Confirm");
			String Accountdet=tdpRow.get("Account");
	if (Accountdet.equalsIgnoreCase("LAJ_Aft_Acctdet") )
				
			{
			 waitForLoading();
			Thread.sleep(10000);
				commoncomps.waitForPageHeaderToAppear("Your application is in progress");
				/*ReporterA.reportPassWithSnapshot("Your application is in progress"
						+ " validate if present ", "Assisted Journey"
						+ "should be displayed", "Assisted Journey"
						+ "is displayed", driver);*/
				commoncomps.javascriptexecutorcodeAJ("Exit");
				
				
			}
			}
		
			else if(Feederacct.equalsIgnoreCase("Yes"))
			{
				commoncomps.waitForLoading();	
				commoncomps.pageheader("Tell us what to do with your loan");
				application_id= commoncomps.getapplid("PaymentDetails_referenceID_PM5T");
				String app_ID[]= application_id.split(":");
				appl_ID= app_ID[1].trim();
				//commoncomps.waitForPageHeaderToAppear("Payment details");
				commoncomps.Togettext("Where you want to make repayments from");
				if(Sameact.equalsIgnoreCase("Y"))
				{
					commoncomps.ZambesiRadioAcctpage(driver, "radiosameAccount");
				}
				else if(Sameact.equalsIgnoreCase("N"))
				{
					commoncomps.ZambesiRadioButton(driver, "radionewAccount");
					commoncomps.waitForLoading();
					commoncomps.Acctholdernametextbox(driver, "nameOfAccountHolder", tdtRow.get("Account Holder"));
					//System.out.println(accountholder);
					commoncomps.inputInTextBoxZambesi(driver, "sortCode", tdtRow.get("sort code"));
					//System.out.println(code);
					commoncomps.inputInTextBoxZambesi(driver, "accountNumber", tdtRow.get("acctno"));
					//System.out.println(account);
					
					
				}
				
				commoncomps.date(driver, tdtRow.get("repaydate"));
				commoncomps.clickAnybuttonInZambesi("Confirm");
				}
			
			else
			{
				if(!(account.equalsIgnoreCase("One")))
				{
				
				application_id= commoncomps.getapplid("ProductOverview_referenceID_3T6r");
				String app_ID[]= application_id.split(":");
				appl_ID= app_ID[1].trim();	
			ODLimit1=tdtRow.get("ODLimit1");
			ODLimit2=tdtRow.get("ODLimit2");
			ODLimit3=tdtRow.get("ODLimit3");
			
			if(ODLimit1.equalsIgnoreCase("Zero")&&ODLimit2.equalsIgnoreCase("Zero")&&ODLimit3.equalsIgnoreCase("Zero")||(ODLimit1.equalsIgnoreCase("Zero")&&ODLimit2.equalsIgnoreCase("Zero"))||(ODLimit1.equalsIgnoreCase("Zero")&&ODLimit3.equalsIgnoreCase("Zero"))||(ODLimit2.equalsIgnoreCase("Zero")&&ODLimit3.equalsIgnoreCase("Zero"))||(ODLimit1.equalsIgnoreCase("Zero"))||(ODLimit2.equalsIgnoreCase("Zero"))||(ODLimit3.equalsIgnoreCase("Zero")))
			//commoncomps.pageheader("Tell us what to do with your Overdraft");
			ReporterA.reportPassWithSnapshot("Tell us what to do with your Overdraft "
					+ " validate if present ", "Tell us what to do with your Overdraft"
					+ "should be displayed", "Tell us what to do with your Overdraft"
					+ "is displayed", driver);
			{
			Select select=new Select(driver.findElement(By.id("receiving")));
			List<WebElement>list=select.getOptions();
			for(WebElement we:list)
			{
				System.out.println(we.getText());
			}commoncomps.Exit("Exit", tdtRow.get("Exit"));
			commoncomps.clickAnybuttonInZambesi("Confirm");
			}

			String Accountdet=tdpRow.get("Account");
			 if (Accountdet.equalsIgnoreCase("OAJ_Aft_Acctdet"))
				
			{
			 waitForLoading();
			Thread.sleep(10000);
				commoncomps.waitForPageHeaderToAppear("Your application is in progress");
				ReporterA.reportPassWithSnapshot("Your application is in progress"
						+ " validate if present ", "Assisted Journey"
						+ "should be displayed", "Assisted Journey"
						+ "is displayed", driver);
				commoncomps.javascriptexecutorcodeAJ("Exit");
				
				
			}
			}
				
				
			}
			}

				
				
				
			
		
				
				/* yet to check whether its applicable for bbconnect
				 * String EntityType = tdpRow.get("EntityType");
				 
				if(loanApplicable.equalsIgnoreCase("No"))
				{
				if((EntityType.equalsIgnoreCase("ST")) || (EntityType.equalsIgnoreCase("PTN")) )
				{
					String text = commoncomps.Togettext("Pre-contract information and next steps for your overdraft");
					if(text.equalsIgnoreCase("Pre-contract information and next steps for your overdraft"))
					{
						preContractInformationText = "Yes";
						
						System.out.println("The text Pre-contract information and next steps for your overdraft is displayed in Thank you page");
					}
					else 
					{
						preContractInformationText = "No";
					}
				}
				}
				else
				{
					preContractInformationText = "No";
				}
				
				//preContractInformationText = "No";
				System.out.println(preContractInformationText);
				ReporterA.reportPassWithSnapshot("Thank you"
						+ " validate if present ", "Thank you"
						+ "should be displayed", "Thank you"
						+ "is displayed", driver);
				commoncomps.sleepTime(3);
				
				commoncomps.clickAnybuttonInZambesi("Close");
				*/
			Status = "Pass";
		}
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
			Status = "Fail";
		}
		
	}


	
}