package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class Eligibility extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	 String json;
	 String Path;
	 String PathforAddress;
	 String PathForBusiness;
	 String PathForBusiWithAccounts;
	 String InitialJsonPath;
	 String PathForBusiWithMainAccounts;
	 String PathForBusiAddress;
	 String PathWithElig;
	 Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void EligibilityMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
	
	 document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
     
      InitialJsonPath = "$.data.eligibility.";
      Path = "userInformation.";
      PathforAddress = Path+"address.";
      PathForBusiness = "businesses[0].";
      PathForBusiWithAccounts = PathForBusiness+"accounts[0].";
      PathForBusiWithMainAccounts = PathForBusiness+"mainBusinessAccounts[0].";
      PathForBusiAddress = PathForBusiness+"address.";
      
    String UserID = ServiceValueRet(Path,"userId");
    System.out.println(UserID);		
    String Title = ServiceValueForStringRet(Path,"title");
     
    String FirstName = ServiceValueForStringRet(Path,"firstName");
     
    String MiddleName = ServiceValueForStringRet(Path,"middleName");
    
    String LastName = ServiceValueForStringRet(Path,"lastName");
    
    String DOB = ServiceValueForStringRet(Path,"dateOfBirth");
    
    String AddressLine1 = ServiceValueForStringRet(PathforAddress,"addressLine1");
    
    String AddressLine2 = ServiceValueForStringRet(PathforAddress,"addressLine2");
    
    String AddressLine3 = ServiceValueForStringRet(PathforAddress,"addressLine3");

    String AddressLine4 = ServiceValueForStringRet(PathforAddress,"addressLine4");
    
    String PostCode = ServiceValueForStringRet(PathforAddress,"postcode");
    
    String KYCStatus = ServiceValueForStringRet(Path,"kycStatus");
    
    String Eligible = ServiceValueForBoolRet(Path,"eligible");
    
    String FraudMarker = ServiceValueForStringRet(Path,"fraudMarker");
    
    String CRMMarker = ServiceValueForStringRet(Path,"crmMarker");
    
    String portfolioCode = ServiceValueRet(Path,"portfolioCode");
    
    String PoliticallyExposed = ServiceValueForBoolRet(Path,"politicallyExposedPerson");
    //revisit
    String PhoneNumber = ServiceValueForStringRet(Path,"phoneNumber");
   
    String eMailAd = ServiceValueForStringRet(Path,"emailAddress");
    
    String CountryOfResi = ServiceValueForStringRet(Path,"countryOfResidence");
    
    String UKNational = ServiceValueForBoolRet(Path,"ukNational");
    
    String CreditGrade = ServiceValueForStringRet(Path,"creditGrade");
    
    String SPLCreditGrade = ServiceValueForStringRet(Path,"specialCreditGrade");
    
    String ApplInd = ServiceValueForBoolRet(Path,"applicantIndicator");
    
    //revisit
   String PhoCountryCode = ServiceValueRet(Path,"phoneCountryCode") ;
		 
    String FullName = ServiceValueForStringRet(Path,"fullName");
    
    String Age = ServiceValueRet(Path,"age");
    
    String SicCode = ServiceValueRet(Path,"siccode");
    
    String BusinessID = ServiceValueForStringRet(PathForBusiness,"businessId");
    
    String businessName = ServiceValueForStringRet(PathForBusiness,"businessName");
    
    String businessType = ServiceValueForStringRet(PathForBusiness,"businessType");
      
    String AccountName = ServiceValueForStringRet(PathForBusiWithAccounts,"accountName");
    
    String SortCOde = ServiceValueForStringRet(PathForBusiWithAccounts,"sortCode");
    
    String AccountNum = ServiceValueForStringRet(PathForBusiWithAccounts,"accountNumber");
    
    String AcntTypeCode = ServiceValueForStringRet(PathForBusiWithAccounts,"accountTypeCode.typeCode");
   
    String hasOd = ServiceValueForBoolRet(PathForBusiWithAccounts,"hasOverdraft");
    		
    String ODBal = ServiceValueForDoubleRet(PathForBusiWithAccounts,"overdraftBalance");
    
    String EligForOD = ServiceValueForBoolRet(PathForBusiWithAccounts,"eligibleForOverdraft");
    
    String AccountNotCurrent = ServiceValueForStringRet(PathForBusiWithAccounts,"accountsNotCurrent");
   
    String MainBusiAcntName = ServiceValueForStringRet(PathForBusiWithMainAccounts,"accountName");
   
    String MainBusiSortCode = ServiceValueForStringRet(PathForBusiWithMainAccounts,"sortCode");
    
    String MainBusiAccntNum = ServiceValueForStringRet(PathForBusiWithMainAccounts,"accountNumber");
    
    String MainBusiAcntTypeCode = ServiceValueForStringRet(PathForBusiWithMainAccounts,"accountTypeCode.typeCode");
    
    String MainBusiEligOD = ServiceValueForBoolRet(PathForBusiWithMainAccounts,"eligibleForOverdraft");
    
    String MainBusiHasOD = ServiceValueForBoolRet(PathForBusiWithMainAccounts,"hasOverdraft");
    
    String MainBusiODBal = ServiceValueForDoubleRet(PathForBusiWithMainAccounts,"overdraftBalance");
    
    String existOD = ServiceValueForBoolRet(PathForBusiness,"existingOverdraft");
    
    String ExistCurrentAcnt = ServiceValueForBoolRet(PathForBusiness,"existingCurrentAccount");
    
    String KYCStatusInBus = ServiceValueForStringRet(PathForBusiness,"kycStatus");
    
    String TotalAggDebt = ServiceValueForDoubleRet(PathForBusiness,"totalAggregateDebt");
    
    String EligInBusi = ServiceValueForBoolRet(PathForBusiness,"eligible");
    
    String FraudMarkerInBusi = ServiceValueForStringRet(PathForBusiness,"fraudMarker");
    
    String CreditGradeInBus = ServiceValueForStringRet(PathForBusiness,"creditGrade");
    
    String BINSplCreditGradeInBus = ServiceValueForStringRet(PathForBusiness,"binSpecialCreditGrade");
    
   
    String BusiAddLine1 = ServiceValueForStringRet(PathForBusiAddress,"addressLine1");
    
    String BusiAddLine2 = ServiceValueForStringRet(PathForBusiAddress,"addressLine2");
    
    String BusiAddLine3 = ServiceValueForStringRet(PathForBusiAddress,"addressLine3");
    
    String BusiAddLine4 = ServiceValueForStringRet(PathForBusiAddress,"addressLine4");
    
    String Postcode = ServiceValueForStringRet(PathForBusiAddress,"postcode");
    
    String CRMMarkerInBusi = ServiceValueForStringRet(PathForBusiness,"crmmarker");
    
    String ShadowLimit = ServiceValueForDoubleRet("NA","shadowLimit");
    		
    String NetTurnOver = ServiceValueForDoubleRet("NA","nettTurnOver");
    
    String RiskBand = ServiceValueRet("NA","riskBand");
    		
    String Eligiblility = ServiceValueForBoolRet("NA","eligible");
    		
   //For status and account not current both are array but since there is no value in that error is thrown
    //revist
    String Status = ServiceValueForStringRet("NA",".status.reasons"); 
    
    String ApplicationID = ServiceValueForStringRet("NA","bpmApplicationId");
   
    String DigiContextID = ServiceValueForStringRet("NA","digitalContextId");
    
    String ApplnBrand = ServiceValueForStringRet("NA","brand"); 
    	
    String DigestKey = ServiceValueForStringRet("NA","segmentDigestKey"); 
    		
	
    
    /*Map<String, Integer> resp1  = JsonPath.read(document,"$.data.eligibility.userInformation")
    		for (Map.Entry<String, Integer> entry : resp1.entrySet()) {
    	    	
    	        System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
    	    }*/
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Eligibility";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"User ID",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UserID,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Title",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Title,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"First Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,FirstName ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Middle Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MiddleName,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Last Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,LastName,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Date Of Birth",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,DOB,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Address Line1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AddressLine1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Address Line2 ",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AddressLine2 ,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Address Line3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AddressLine3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Address Line4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AddressLine4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"PostCode",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,PostCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"KYC Status",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,KYCStatus,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligible,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Fraud Marker",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,FraudMarker,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CRM Marker",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CRMMarker,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"portfolio Code",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,portfolioCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"PoliticallyExposed",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,PoliticallyExposed,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"PhoneNumber",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,PhoneNumber,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"eMail Address",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,eMailAd,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Country Of Residence",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CountryOfResi,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"UK National",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,UKNational,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Credit Grade",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CreditGrade,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Special Credit Grade",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,SPLCreditGrade,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"Application Indicator",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ApplInd,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Phone Country Code",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,PhoCountryCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Full Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,FullName,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Age",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Age,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Sic Code",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,SicCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business ID",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusinessID,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,businessName,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Type",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,businessType,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Account Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AccountName,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Sort COde",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,SortCOde,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Account Number",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AccountNum,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Account Type Code",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AcntTypeCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Has Overdraft",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,hasOd,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"OD Balance",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ODBal,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible For OD",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,EligForOD,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Account Not Current",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AccountNotCurrent,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Account Name",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiAcntName,rowcount,1);
	rowcount++;
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Sort Code ",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiSortCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Account Number",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiAccntNum,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Account Type Code ",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiAcntTypeCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Eligible OD ",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiEligOD,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Main Business Has OD",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiHasOD,rowcount,1);
	rowcount++;
	
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"MainBusiODBal",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,MainBusiODBal,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"existOD",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,existOD,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Exist Current Acnt",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ExistCurrentAcnt,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"KYC Status In Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,KYCStatusInBus,rowcount,1);
	rowcount++;
    
	commoncomps.setTestDataRow_BB_Write(SheetName,"TotalAggDebt",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,PostCode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"EligInBusi",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,EligInBusi,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Fraud Marker In Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,FraudMarkerInBusi,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Credit Grade In Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CreditGradeInBus,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"BIN Special Credit Grade In Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BINSplCreditGradeInBus,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Address Line1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusiAddLine1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Address Line2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusiAddLine2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Address Line3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusiAddLine3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Business Address Line4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,BusiAddLine4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Post code",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Postcode,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"CRM Marker In Business",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,CRMMarkerInBusi,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ShadowLimit",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ShadowLimit,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"NetTurnOver",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,NetTurnOver,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"RiskBand",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,RiskBand,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligiblility",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligiblility,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Status",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Status,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Application ID",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ApplicationID,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Digital Context ID",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,DigiContextID,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Application Brand",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ApplnBrand,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Digest Key",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,DigestKey,rowcount,1);
	rowcount++;
	
  	
	    
	}
	int MicroServiceIntValue;
	String FinalPath;
	String MicroServiceStrValue;
	Boolean MicroServiceBooleanValue;
	Double MicroServiceDoubleValue;
	
	String ServiceValueRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
	
	{
		FinalPath = InitialJsonPath+InitialPath+InputData;
		try
		{
		MicroServiceIntValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Integer.toString(MicroServiceIntValue);
	    System.out.println(MicroServiceIntValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value returned";
		}
	}
		else
		{
			FinalPath = "$.data.eligibility."+InputData;
			try
			{
			MicroServiceIntValue = JsonPath.read(document,FinalPath);
			MicroServiceStrValue = Integer.toString(MicroServiceIntValue);
		    System.out.println(MicroServiceIntValue);
			}
		
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value returned";
		}
		
		}
		return MicroServiceStrValue;
	}
	
	String ServiceValueForStringRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
		{
		FinalPath = InitialJsonPath+InitialPath+InputData;
		try
		{
		MicroServiceStrValue = JsonPath.read(document,FinalPath);
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		}
		else
		{
			FinalPath = "$.data.eligibility."+InputData;
			try
			{
			MicroServiceStrValue = JsonPath.read(document,FinalPath);
		    System.out.println(MicroServiceStrValue);
			}
			catch(Exception e)
			{
				MicroServiceStrValue = "No Value found";
			}
		}
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueForBoolRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
		{
		FinalPath = InitialJsonPath+InitialPath+InputData;
		try
		{
			
		MicroServiceBooleanValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Boolean.toString(MicroServiceBooleanValue);
	    System.out.println(MicroServiceBooleanValue);
		}
		catch(Exception e)
		{
			
			MicroServiceStrValue = "No Value found";
			
		}
		}
		
		else
		{
			FinalPath = "$.data.eligibility."+InputData;
			try
			{
			MicroServiceBooleanValue = JsonPath.read(document,FinalPath);
			MicroServiceStrValue = Boolean.toString(MicroServiceBooleanValue);
		    System.out.println(MicroServiceBooleanValue);
			}
			catch(Exception e)
			{
				
				MicroServiceStrValue = "No Value found";
				
			}
		}
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueForDoubleRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
		{
		FinalPath = InitialJsonPath+InitialPath+InputData;
		try
		{
			MicroServiceDoubleValue = JsonPath.read(document,FinalPath);
			MicroServiceStrValue = String.valueOf(MicroServiceDoubleValue);
	    System.out.println(MicroServiceDoubleValue);
		}
		catch(Exception e)
		{
			
			MicroServiceStrValue = "No Value found";
			
		}
		}
		else
		{
			FinalPath = "$.data.eligibility."+InputData;
			try
			{
			MicroServiceDoubleValue = JsonPath.read(document,FinalPath);
			MicroServiceStrValue = String.valueOf(MicroServiceDoubleValue);
		    System.out.println(MicroServiceDoubleValue);
			}
			catch(Exception e)
			{
				
				MicroServiceStrValue = "No Value found";
				
			}
		}
		 return MicroServiceStrValue;
	}
	
	}

	
	
	


