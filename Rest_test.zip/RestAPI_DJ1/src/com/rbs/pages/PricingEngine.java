package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException; 

public class PricingEngine extends BasePage {

	LoginPage LP = new LoginPage();
	
	private String sTestDataSheetName = "CutomerLookUp";
	private String wTestDataSheetName = "Scenario";
	private String zTestDataSheetName = null;
	public String respString = null;
	 String ReqJsonPath;
	 String ReqJsonPathForFirstProduct;
	 String ReqJsonPathForSecondProduct;
	 String ReqJsonPathForThirdProduct;
	 String ReqJsonPathForFourthProduct;
	 Object document;
	KeyStore keyStore = null;
	private String SheetName;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	static SSLConfig config = null;
	static String password = "Rx2Huc7e4Mj73";
	CommonUtils commoncomps = new CommonUtils();
	
	public void PricingEngineMicroService(String sTestName, String URL, String JSON) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParseException
	{
	
	 document = Configuration.defaultConfiguration().jsonProvider().parse(JSON);
     
	 ReqJsonPath = "$.data.";
	 ReqJsonPathForFirstProduct = "products[0].";
	 ReqJsonPathForSecondProduct = "products[1].";
	 ReqJsonPathForThirdProduct = "products[2].";
	 ReqJsonPathForFourthProduct = "products[3].";

    String Term = ServiceValueRet("term");
   
    String amount = ServiceValueRet("amount");
    
    String displayStatus = ServiceValueForStringRet("NA","displayStatus");
  
    String ProductType1 = ServiceValueForStringRet(ReqJsonPathForFirstProduct,"productType");
    
    String Name1 = ServiceValueForStringRet(ReqJsonPathForFirstProduct,"name");
    
    String Category1 = ServiceValueForStringRet(ReqJsonPathForFirstProduct,"category");
    
    String Eligible1 = ServiceValueForBoolRet(ReqJsonPathForFirstProduct,"eligible");
    
    String Reason1 = ServiceValueForStringRet(ReqJsonPathForFirstProduct,"reason");
    
    String ProductType2 = ServiceValueForStringRet(ReqJsonPathForSecondProduct,"productType");
    
    String Name2 = ServiceValueForStringRet(ReqJsonPathForSecondProduct,"name");
    
    String Category2 = ServiceValueForStringRet(ReqJsonPathForSecondProduct,"category");
    
    String Eligible2 = ServiceValueForBoolRet(ReqJsonPathForSecondProduct,"eligible");
    
    String Reason2 = ServiceValueForStringRet(ReqJsonPathForSecondProduct,"reason");
    
    String ProductType3 = ServiceValueForStringRet(ReqJsonPathForThirdProduct,"productType");
    
    String Name3 = ServiceValueForStringRet(ReqJsonPathForThirdProduct,"name");
    
    String Category3 = ServiceValueForStringRet(ReqJsonPathForThirdProduct,"category");
    
    String Eligible3 = ServiceValueForBoolRet(ReqJsonPathForThirdProduct,"eligible");
    
    String Reason3 = ServiceValueForStringRet(ReqJsonPathForThirdProduct,"reason");
    
    String ProductType4 = ServiceValueForStringRet(ReqJsonPathForFourthProduct,"productType");
    
    String Name4 = ServiceValueForStringRet(ReqJsonPathForFourthProduct,"name");
    
    String Category4 = ServiceValueForStringRet(ReqJsonPathForFourthProduct,"category");
    
    String Eligible4 = ServiceValueForBoolRet(ReqJsonPathForFourthProduct,"eligible");
    
    String Reason4 = ServiceValueForStringRet(ReqJsonPathForFourthProduct,"reason");
    
    String AffordabilityCheck = ServiceValueForBoolRet("NA","affordabilityCheckRequired");
    
    String AssistedJourneyReqd = ServiceValueForBoolRet("NA","affordabilityCheckRequired");
    
    String errors = ServiceValueForStringRet("NA","errors");
    
    
  
    
    String refernum = "ABCD";
    
    int rowcount=1;
    
    	SheetName = "Pricing Engine";
    
    commoncomps.createExcelSheetMethod(SheetName,refernum);
    //int rowcount=1;
    
  
	commoncomps.setTestDataRow_BB_Write(SheetName,"Term",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Term,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Amount",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,amount,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Status",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,displayStatus,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ProductType1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ProductType1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Name1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Category1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Category1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligible1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Reason1",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Reason1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ProductType2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ProductType2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Name2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Category2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Category2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligible2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Reason2",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Reason2,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ProductType3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ProductType3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Name3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Category3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Category3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligible3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Reason3",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Reason3,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"ProductType4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,ProductType4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Name4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Name4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Category4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Category4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Eligible4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Eligible4,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"Reason4",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,Reason1,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"AffordabilityCheck",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AffordabilityCheck,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"AssistedJourneyReqd",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,AssistedJourneyReqd,rowcount,1);
	rowcount++;
	
	commoncomps.setTestDataRow_BB_Write(SheetName,"errors",rowcount,0);
	commoncomps.setTestDataRow_BB_Write(SheetName,errors,rowcount,1);
	rowcount++;
    

	}
	
	String FinalPath;
	String MicroServiceStrValue;
	int MicroServiceIntValue;
	Boolean MicroServiceBooleanValue;
	String ServiceValueForStringRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
			
		{
		FinalPath = ReqJsonPath+InitialPath+InputData;
		}
		else
		{
			FinalPath = ReqJsonPath+InputData;
		}
		try
		{
		MicroServiceStrValue = JsonPath.read(document,FinalPath);
	    System.out.println(MicroServiceStrValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value found";
		}
		
		
	    return MicroServiceStrValue;
		
	}
	
	String ServiceValueRet(String InputData)
	{
		
		FinalPath = ReqJsonPath+InputData;
		try
		{
		MicroServiceIntValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Integer.toString(MicroServiceIntValue);
	    System.out.println(MicroServiceIntValue);
		}
		catch(Exception e)
		{
			MicroServiceStrValue = "No Value returned";
		}
	
		
		return MicroServiceStrValue;
	}
	
	String ServiceValueForBoolRet(String InitialPath, String InputData)
	{
		if(!(InitialPath.equalsIgnoreCase("NA")))
			
		{
		FinalPath = ReqJsonPath+InitialPath+InputData;
		}
		else
		{
			FinalPath = ReqJsonPath+InputData;
		}
		
		try
		{
			
		MicroServiceBooleanValue = JsonPath.read(document,FinalPath);
		MicroServiceStrValue = Boolean.toString(MicroServiceBooleanValue);
	    System.out.println(MicroServiceBooleanValue);
		}
		catch(Exception e)
		{
			
			MicroServiceStrValue = "No Value found";
			
		}
		

	    return MicroServiceStrValue;
		
	}
	
	
	}

	
	
	


