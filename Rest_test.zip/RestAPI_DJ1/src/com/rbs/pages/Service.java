package com.rbs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.util.Map;

import javax.net.ssl.*;

import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;
import com.rbs.utils.GenericUtils;

import net.minidev.json.parser.ParseException;

public class Service extends BasePage {
	public String respString = null;
	public static String json;

	KeyStore keyStore = null;
	static KeyStore trustStore = null;
	ServiceURLAndInputs ServiceURL = new ServiceURLAndInputs();
	CustomerLookUp CustomerLookUp = new CustomerLookUp();
	Purpose pur = new Purpose();
	CountryCodes countryCode = new CountryCodes();
	Eligibility elig = new Eligibility();
	ProductInfo prodInfo = new ProductInfo();
	Form1 form = new Form1();
	PricingEngine pricingEngine = new PricingEngine();
	static SSLConfig configur = null;
	// static String password = "Rx2Huc7e4Mj73";
	static String password = "q@1bc0reBbc";
	// static String password = "LendingCPB";
	CommonUtils commoncomps = new CommonUtils();

	/**
	 * Pass the request to URL and fetch response
	 * 
	 * @param sTestName
	 *            is scenario name
	 * @param URL
	 *            is service URL
	 * @throws IOException
	 * @throws KeyManagementException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws ParseException
	 */
	public Response postURL(String msName, String sceNum, Map<String, String> dataMap) throws IOException,
			KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
		String serviceURL = dataMap.get("URL");
		String requestJSON = dataMap.get("INPUT JSON");
		Response response = null;
		String certName = msName + "_Cert";
		FileInputStream keyStr = new FileInputStream(GenericUtils.getProperty(certName));
		String trustStorePath = "C:/Program Files/Java/jre1.8.0_191/lib/security/cacerts";
		String trustPwd = "changeit";
		try {
			// keyStore = KeyStore.getInstance("PKCS12");
			keyStore = KeyStore.getInstance("JKS");
			keyStore.load(keyStr, password.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keyStore, password.toCharArray());
			KeyManager[] kms = kmf.getKeyManagers();
			trustStore = KeyStore.getInstance("JKS");
			trustStore.load(new FileInputStream(trustStorePath), trustPwd.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(trustStore);
			TrustManager[] tms = tmf.getTrustManagers();
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(kms, tms, new SecureRandom());
		}

		catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}

		if (keyStore != null) {
			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
					keyStore, password, trustStore);
			configur = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

			RestAssured.config = RestAssured.config().sslConfig(configur);
			RequestSpecification request = RestAssured.given().when().contentType("application/json");
			
			if (msName.equals("SubPurpose") || msName.equals("BorrowingNeeds")) {
				String authorization = "Bearer" + dataMap.get("Authorization");
				// System.out.println("------------------Authorization-----------------"+authorization);
				String cookie = dataMap.get("Cookie");
				// System.out.println("-----------------------Cookie-------------------"+cookie);
				request.given().proxy("11.155.149.100", 8080)
				.header("Authorization", authorization)
				.cookie(cookie);
			}
			JSONObject reqJson = null;
			try {
				reqJson = new JSONObject(requestJSON.replaceAll("<.*?>|\u00a0", ""));
				request.body(reqJson.toString());
				response = request.post(serviceURL);
			} catch (JSONException e) {
				// Incorrect Request JSON
				ExcelUtils.writeToExcel(msName, sceNum, "", "Invalid Request JSON", e.getMessage());
				return response;
			}
		}
		return response;
	}

	public Response getURL(String msName, String sceNum, Map<String, String> dataMap) throws IOException,
			KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
		String serviceURL = dataMap.get("URL");
		String authorization = "Bearer" + dataMap.get("Authorization");
		//System.out.println("------------------Authorization-----------------"+authorization);
		String cookie=dataMap.get("Cookie");
		//System.out.println("-----------------------Cookie-------------------"+cookie);
		Response response = null;
		String certName = msName+ "_Cert";
		System.out.println("-------------------"+certName);
		FileInputStream keyStr = new FileInputStream(GenericUtils.getProperty(certName));
		String trustStorePath = "C:/Program Files/Java/jre1.8.0_191/lib/security/cacerts";
		String trustPwd = "changeit";
		try {
			keyStore = KeyStore.getInstance("JKS");
			keyStore.load(keyStr, password.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keyStore, password.toCharArray());
			KeyManager[] kms = kmf.getKeyManagers();
			trustStore = KeyStore.getInstance("JKS");
			trustStore.load(new FileInputStream(trustStorePath), trustPwd.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(trustStore);
			TrustManager[] tms = tmf.getTrustManagers();
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(kms, tms, new SecureRandom());
		}

		catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}

		if (keyStore != null) {
			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
					keyStore, password, trustStore);
			configur = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
			
			RestAssured.config = RestAssured.config().sslConfig(configur);
			RequestSpecification request = RestAssured.given().proxy("11.155.149.100", 8080)
					.header("Authorization", authorization)
					.cookie(cookie)
					.when().contentType("application/json");
			response = request.get(serviceURL);
			//System.out.println("Response of String:\n" + response.prettyPrint());
		}
		return response;
	}

	public void valiateResponse(String sSheetName, String scNum, Response servResponse, Map<String, String> dataMap) {
		// ExcelUtils.writeToExcel(sSheetName, scNum,servResponse.prettyPrint(),"","");
		if (servResponse != null) {
			String actualResponse = servResponse.prettyPrint();
			JSONObject actualRespJson = new JSONObject(actualResponse);
			String expResponse = dataMap.get("EXPECTED JSON");
			try {
				
				JSONAssert.assertEquals(expResponse.replaceAll("<.*?>|\u00a0", ""), actualRespJson, false);
				// Assertion Passes
				ExcelUtils.writeToExcel(sSheetName, scNum, actualResponse, "PASSED", "");
			} catch (AssertionError ae) {
				// Assertion Failed
				ExcelUtils.writeToExcel(sSheetName, scNum, actualResponse, "FAILED", ae.getMessage());
			}
		}

	}
	
	public Response postSubPurpose(String msName, String sceNum, Map<String, String> dataMap) throws IOException,
			KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
		String serviceURL = dataMap.get("URL");
		String authorization = "Bearer" + dataMap.get("Authorization");
		//System.out.println("------------------Authorization-----------------"+authorization);
		String cookie=dataMap.get("Cookie");
		//System.out.println("-----------------------Cookie-------------------"+cookie);
		String requestJSON = dataMap.get("INPUT JSON");
		Response response = null;
		String certName = msName + "_Cert";
		FileInputStream keyStr = new FileInputStream(GenericUtils.getProperty(certName));
		String trustStorePath = "C:/Program Files/Java/jre1.8.0_131/lib/security/cacerts";

		String trustPwd = "changeit";
		try {
			// keyStore = KeyStore.getInstance("PKCS12");
			keyStore = KeyStore.getInstance("JKS");
			keyStore.load(keyStr, password.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keyStore, password.toCharArray());
			KeyManager[] kms = kmf.getKeyManagers();
			trustStore = KeyStore.getInstance("JKS");
			trustStore.load(new FileInputStream(trustStorePath), trustPwd.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(trustStore);
			TrustManager[] tms = tmf.getTrustManagers();
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(kms, tms, new SecureRandom());
		}

		catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}

		if (keyStore != null) {
			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
					keyStore, password, trustStore);
			configur = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

			RestAssured.config = RestAssured.config().sslConfig(configur);
			RequestSpecification request = RestAssured.given().proxy("11.155.149.100", 8080)
					.header("Authorization", authorization)
					.cookie(cookie)
					.when().contentType("application/json");
			JSONObject reqJson = null;
			try {
				reqJson = new JSONObject(requestJSON.replaceAll("<.*?>|\u00a0", ""));
			} catch (JSONException e) {
				// Incorrect Request JSON
				ExcelUtils.writeToExcel(msName, sceNum, "", "Invalid Request JSON", e.getMessage());
				return response;
			}
			request.body(reqJson.toString());

			response = request.post(serviceURL);

		}
		return response;
	}

}