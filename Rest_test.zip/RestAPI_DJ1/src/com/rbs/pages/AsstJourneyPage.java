package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.OracleDBUtils;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;

//import org.apache.commons.io.FileUtils;

public class AsstJourneyPage extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	KeySignatories ks = new KeySignatories();
	private String sTestDataSheetName = "AJConditionChecks";

	
	//BusinessBankingLoginPage1 bizobj = null;
	OracleDBUtils o1= new OracleDBUtils();
	SetPageName s1= null;
	public String Status;
	public String value;
	public String HardStopScenario;
	public String AJbeforecredit;
	public static String LombardCardURL; 
	public AsstJourneyPage() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void inputValuesInAJPage(String sTestName, int rownum, String position )
			throws Exception {
		try
		{
			s1.setupTestName(sTestDataSheetName +"_"+sTestName+"_"+position,"chrome",sTestDataSheetName +"_"+sTestName+"_"+position);
			
				commoncomps.waitForPageHeaderToAppear("Your application is in progress");
				System.out.println("Assisted Journey");
				
				//AJbeforecredit = "Yes";
				System.out.println("AJ");
			//commoncomps.clickAnylinkInZambesiCredit("Print a copy");
			//commoncomps.clickAnylinkInZambesiCredit("The lending code");
				String asstappid = commoncomps.getappIdAsstJourney();
				String appid[] = asstappid.split(":");
				String appliid = appid[1].trim();
				//JavascriptExecutor jse = (JavascriptExecutor) driver;
				//jse.executeScript("window.scrollBy(0,250)","");
				ReporterA.reportPassWithSnapshot("AJ  Page"
						+ " validate if present ", "AJ  Page"
						+ "should be displayed", "AJ  Page"
						+ "is displayed", driver);
				o1.appIdUpdate(appliid ,sTestName,rownum);
				o1.reasontextUpdate(appliid ,sTestName,rownum);
				//commoncomps.clickAnybuttonInZambesi("Exit");
				commoncomps.javascriptexecutorcodeAJ("Exit");
				Status = "Pass";
		
		}
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
}