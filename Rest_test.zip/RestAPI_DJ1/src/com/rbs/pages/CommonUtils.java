package com.rbs.pages;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.Validate;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.util.SystemOutLogger;

import com.jayway.jsonpath.Configuration;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.RestAssured.*;
import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;
import static org.hamcrest.Matchers.containsString; 

public class CommonUtils extends BasePage {

	public static void createExcelSheetMethod(String sSheetName, String refernum			) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\MicroServiceOutput.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		createExcelSheet(
				sMasterTDWorkbook, sSheetName,refernum);

		
	}
	
	private static void createExcelSheet(
			String sWorkBook, String sSheetName, String refernum) {
		
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		try {
			deleteExcelSheet( sWorkBook,  sSheetName);
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			
		
			sheet = workbook.createSheet(sSheetName);
			row = sheet.createRow(0);
			
		     HSSFCellStyle style = workbook.createCellStyle();
	    		style.setFillForegroundColor(HSSFColor.YELLOW.index);
	    		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

	    		HSSFFont font = workbook.createFont();
	    		font.setColor(HSSFColor.BLACK.index);
	    		style.setFont(font);
	    		

			
			Cell cell = row.createCell(0);
	        cell.setCellType(cell.CELL_TYPE_STRING);
            cell.setCellValue("Field Label");
            cell.setCellStyle(style);
            
            Cell cell1 = row.createCell(1);
            cell1.setCellType(cell.CELL_TYPE_STRING);
            cell1.setCellValue("Value");
            cell1.setCellStyle(style);
            
            
            
            FileOutputStream opfile1 = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile1);
            
            opfile1.close();
		}
		catch ( Exception e)
		{
			System.out.println(e);
		}
	}
	private static void deleteExcelSheet(String sWorkBook, String sSheetName)
	{
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;
		try
		{
		FileInputStream file = new FileInputStream(new File(sWorkBook));

		HSSFWorkbook workbook = new HSSFWorkbook(file);
		
		int index = 0;

		HSSFSheet sheetold = workbook.getSheet(sSheetName);
		if(sheetold != null)   {
		    index = workbook.getSheetIndex(sheetold);
		    workbook.removeSheetAt(index);
		    FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile);
            opfile.close();
		}
		}
		catch ( Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static void setTestDataRow_BB_Write_highilght(String sSheetName,
			String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\MicroServiceOutput.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcelhighlight(
				sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

		
	}
	
	private static void WriteToExcelhighlight(
            String sWorkBook, String sSheetName, String respval, int rownum, int colnum) {
     ArrayList<String> colNames = new ArrayList<String>();
     ArrayList<Map<String, String>> mapArray = null;
     
     int sheetRows = 0;
     int rowCols = 0;

     Map<String, String> rowMap = null;

     try {
            FileInputStream file = new FileInputStream(new File(sWorkBook));

            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheet(sSheetName);
            HSSFRow row;
            if(colnum==0)
            {
                  row  = sheet.createRow(rownum);
            }
            else
            {
            	 row = sheet.getRow(rownum);
            }
            
             Cell cell = row.createCell(colnum);
            
            cell.setCellType(cell.CELL_TYPE_STRING);
            //System.out.println(respval);
            cell.setCellValue(respval);
            HSSFCellStyle style = workbook.createCellStyle();
    		style.setFillForegroundColor(HSSFColor.YELLOW.index);
    		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

    		HSSFFont font = workbook.createFont();
    		font.setColor(HSSFColor.BROWN.index);
    		style.setFont(font);
    		cell.setCellStyle(style);
            
            FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile);
            
            opfile.close();
            
     }
catch (FileNotFoundException e) {
            
            e.printStackTrace();
     } catch (IOException e) {
     
            e.printStackTrace();
     }
     
}
	
	public static void setTestDataRow_BB_Write(String sSheetName,
			String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\MicroServiceOutput.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		 WriteToExcel(
				sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

		
	}
	
	public static void setTestDataRow_BB_WriteInt(String sSheetName,
			int value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\MicroServiceOutput.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		WriteToExcelInt(
				sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

		
	}
	
	private static void WriteToExcel(
            String sWorkBook, String sSheetName, String respval, int rownum, int colnum) {
     ArrayList<String> colNames = new ArrayList<String>();
     ArrayList<Map<String, String>> mapArray = null;
     
     int sheetRows = 0;
     int rowCols = 0;

     Map<String, String> rowMap = null;

     try {
            FileInputStream file = new FileInputStream(new File(sWorkBook));

            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheet(sSheetName);
            HSSFRow row;
            if(colnum==0)
            {
                  row  = sheet.createRow(rownum);
            }
            else
            {
            	 row = sheet.getRow(rownum);
            }
            
             Cell cell = row.createCell(colnum);
            
            cell.setCellType(cell.CELL_TYPE_STRING);
            //System.out.println(respval);
            cell.setCellValue(respval);
          
            
            FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile);
            
            opfile.close();
            
     }
catch (FileNotFoundException e) {
            
            e.printStackTrace();
     } catch (IOException e) {
     
            e.printStackTrace();
     }
     
}
	private static void WriteToExcelInt(
            String sWorkBook, String sSheetName, int respval, int rownum, int colnum) {
     ArrayList<String> colNames = new ArrayList<String>();
     ArrayList<Map<String, String>> mapArray = null;
     
     int sheetRows = 0;
     int rowCols = 0;

     Map<String, String> rowMap = null;

     try {
            FileInputStream file = new FileInputStream(new File(sWorkBook));

            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheet(sSheetName);
            HSSFRow row;
            if(colnum==0)
            {
                  row  = sheet.createRow(rownum);
            }
            else
            {
            	 row = sheet.getRow(rownum);
            }
            
             Cell cell = row.createCell(colnum);
            
            cell.setCellType(cell.CELL_TYPE_STRING);
            //System.out.println(respval);
            cell.setCellValue(respval);
          
            
            FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile);
            
            opfile.close();
            
     }
catch (FileNotFoundException e) {
            
            e.printStackTrace();
     } catch (IOException e) {
     
            e.printStackTrace();
     }
     
}
	
	
	

	}
	


