package com.rbs.pages;

import static com.jayway.restassured.RestAssured.given;

import java.util.Map;

import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.rbs.utils.ExcelUtils;





public class PostServicePage extends BasePage {

	LoginPage LP = new LoginPage();
	
	 private String sTestDataSheetName = "ConnectionDetails";
	
	public void TestingMicroservicesURL()
	{
		/* Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
				sTestDataSheetName, sTestName); */
		
		 
		        String request= LP.getLoginAPI(sTestDataSheetName);
		        System.out.println(request);
		        
		        RequestSpecification reqspec = given().
		                config(RestAssuredConfig.config().sslConfig(new SSLConfig().allowAllHostnames())).
		                //body(lcDefaultData).
		               header("Cache-Control", "no-cache").
		                header("Cookie", "BBCONNECT_TOKEN=06b144cd-0224-420f-9c24-db60580e5645").
		                header("iam_r4p_bin", "1430160772").
		                header("iam_r4p_dbid", "0905670667").
		                header("iam_r4p_linked-cin", "1151812071").
		                header("iam_subject", "1151869260").
		                header("postman-token", "1aae1ea2-a9b2-2f7b-4c46-4e615a10469b").
		                header("x-forwarded-for", "1.2.3.4").
		                
		             header("Content-Type", "application/json").
		                        when().
		                        contentType("application/json");

		                       // get();
		        Response resp=  reqspec.get(request);
		        

		            //    post("https://devzebra.fm.rbsgrp.net/api/security/login");
		        //post("https://api.nwb-test.openaccount.managedtest.com/api/security/login");
		        System.out.println(resp);
		      //  System.out.println(resp);
		        System.out.println("value of response code is " + resp.getStatusCode());
		        System.out.println("value of response as string is " + resp.asString());
		        //System.out.println("value of response as string is " + resp.getCookies());
		        System.out.println("value of response as string is " + resp.getCookie("RBSGSESSION"));
		      //  DataHelper.setRBSSessionCookie("RBSGSESSION="+resp.getCookie("RBSGSESSION"));

		    }
	}

