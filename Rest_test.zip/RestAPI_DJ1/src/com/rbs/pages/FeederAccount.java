
package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;


//import org.apache.commons.io.FileUtils;

public class FeederAccount extends BasePage{

	
		BBConnectUtils commoncomps = new BBConnectUtils();
		BBUtils bbComps = new BBUtils();
		private String sTestDataSheetName = "FeederAccount";
		private String pTestDataSheetName = "PhoneNumber";
		private String rTestDataSheetName = "PersonaliseYourQuote";
		public String CustomerName;
		public String shadowLimit;
		FeederAccount bb2obj = null;
		SetPageName s1= null;
		public String Status;
		public static String URL;
		public FeederAccount() {
			super();
			PageFactory.initElements(getDriver(), this);
			//bb2obj = new BusinessBankingLoginPage2();
			s1= new SetPageName();
			
		}
	
		public void feederAcctpage(String sTestName)
				throws Exception {
			try
			{
				
				//Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
						//sTestDataSheetName, sTestName);
				
				s1.setupTestName(sTestDataSheetName +"_"+sTestName,"chrome",sTestDataSheetName+"_"+sTestName);
				commoncomps.waitForPageHeaderToAppear("No current account");
				//commoncomps.waitForPageHeaderToAppear("Tell us what to with your loan");
				commoncomps.sleepTime(4);
				ReporterA.reportPassWithSnapshot("FeederAcctpage"
						+ " validate if present ", "FeederAcctpage"
						+ "should be displayed", "FeederAcctpage"
						+ "is displayed", driver);
				//commoncomps.sleepTime(4);
				URL = driver.getCurrentUrl();
				System.out.println(URL);
				commoncomps.clickAnybuttonInZambesi("Continue");
				

			
			}
			catch ( Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			
		}

}
