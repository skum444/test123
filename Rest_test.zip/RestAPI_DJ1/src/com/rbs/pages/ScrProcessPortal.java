package com.rbs.pages;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.rbs.automation.commonutils.CSVDBUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.ScrWorkBench;

public class ScrProcessPortal extends BasePage {

	@FindBy(how = How.NAME, using = "j_username")
	private WebElement txtUserName;

	@FindBy(how = How.NAME, using = "j_password")
	private WebElement txtPassword;

	@FindBy(how = How.NAME, using = "save")
	private WebElement txtSubmit;

	By btnSubmit = By.name("save");
	// By imgLogout =
	// By.xpath("//div[@class='processPortalUserArea']/a[@class='processPortalUserDropdownId']");

	By imgLogout = By.cssSelector("span#processPortalUserName");
	By lnkLogout = By.xpath("//td[text()='Logout']");

	private static String userID;

	public static String getUserID() {
		return userID;
	}

	public ScrProcessPortal() throws IOException, InterruptedException {
		super();

		initiateBrowser(); // function from super class

		PageFactory.initElements(getDriver(), this);
	}

	private void enterCredentials(String userRole) throws Exception {
		Map<String, String> mapCredentials = getUserCredentials(userRole);

//		ReporterA.reportPass("Login as " + userRole,
//				"User should be able to login", "--info only");

		// to be used by
		this.userID = mapCredentials.get("UserName");

		// adding this to check if previous session is retrieved
//		if (WaitUtils.waitForElement(driver, By.name("j_username"), 2500) == null) {
//			logout();
//		}

		//txtUserName = super
		//		.findElementByJquerySelector("input[name=j_username]"); // [name=\"j_username\"]

//		Logger.LogMessage("Entering User ID " + mapCredentials.get("UserName"));

		if (super.validateElementPresent("User ID", txtUserName)) {
			// super.sendKeys("User ID", txtUserName,
			// mapCredentials.get("UserName"));
			txtUserName.sendKeys(mapCredentials.get("UserName"));
		}

//		Logger.LogMessage("Entering Password " + mapCredentials.get("Password"));

		if (super.validateElementPresent("Password ", txtPassword)) {
			super.sendKeys("Password", txtPassword,
					mapCredentials.get("Password"));
		}
	}

	private Map<String, String> getUserCredentials(String UserRole) {
		CSVDBUtils.initConnection();
		Map<String, String> arrUserCredentials = new HashMap<String, String>();

		ResultSet rs = CSVDBUtils
				.getResultSetFromSQL("SELECT UserID, Password FROM UserCredentials where UserRole = '"
						+ UserRole + "'");

		try {
			while ((rs != null) && (rs.next())) {
				arrUserCredentials.put("UserName",
						new String(rs.getString("UserID")));
				arrUserCredentials.put("Password",
						new String(rs.getString("Password")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		CSVDBUtils.closeConnection();
		return arrUserCredentials;
	}
	
	public void closebrower() throws Exception {
		// TODO Auto-generated method stub
		super.CloseBrowser();

	}

	private void submitForm() throws Exception {
		Logger.LogMessage("Going to click on Submit");
		if (super.validateElementPresent("Submit Button", txtSubmit)) {
			super.click("Submit Button", txtSubmit);
			// txtSubmit.click();
		}
	}

	public ScrWorkBench LoginAs(String s) throws Exception {
		// if already logged in
		if (null != WaitUtils.waitForElement(driver, this.imgLogout, 3)) {
			logout();
		}

		enterCredentials(s);
		submitForm();
		return new ScrWorkBench();

	}

	public void logoutUser() throws Exception {
		

		logout();
		}
		
		
		public ScrWorkBench LoginAsPAPP(String s) throws Exception {
			

			enterCredentials(s);
			submitForm();
			return new ScrWorkBench();

		}
	
	public void OpenURL() throws Exception {
		// TODO Auto-generated method stub
		super.openURL();

	}
	
	public void OpenURL(String URL) throws Exception {
		// TODO Auto-generated method stub
		super.openURL(URL);

	}

	public void finishTest() throws Exception {
		logout();
		super.finishTest();
	}

	public void logout() throws Exception {
		Logger.LogMessage("Inside Logout");

		driver.switchTo().defaultContent();

		WebElement logoutDropdownImage = WaitUtils.waitForElement(driver,
				imgLogout, 30);

		if (super.validateElementPresent("Logout Down Arrow",
				logoutDropdownImage)) {
			super.click("Logout Down Arrow", logoutDropdownImage);
		}

		WebElement logout = WaitUtils
				.waitForElement(driver, this.lnkLogout, 10);

		if (super.validateElementPresent("Logout", logout)) {
			super.click("Logout", logout);
		}

		if (onLoginPage()) {
			ReporterA.reportPassWithSnapshot("Validate Logout Success",
					"Login Page should appear again", "is appearing", driver);
		} else {
			ReporterA.reportFailWithSnapshot("Validate Logout Success",
					"Login Page should appear again", "is not appearing",
					driver);
		}

		Thread.sleep(2000);

	}

	private Boolean onLoginPage() {
		if (WaitUtils.waitForElementPresent(driver, btnSubmit, 10) != null) {
			return true;
		} else {
			return false;
		}
	}

}