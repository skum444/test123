package com.rbs.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.rbs.automation.commonutils.BBConnectUtils;
import com.rbs.automation.commonutils.BBUtils;
import com.rbs.automation.commonutils.BrowserUtils;
import com.rbs.automation.commonutils.ExcelUtils;
import com.rbs.automation.commonutils.GenericUtils;
import com.rbs.automation.commonutils.Logger;
import com.rbs.automation.commonutils.ReporterA;
import com.rbs.automation.commonutils.WaitUtils;
import com.rbs.pages.BasePage;

//import org.apache.commons.io.FileUtils;

public class PersonaliseYourQuote extends BasePage{

	
	BBConnectUtils commoncomps = new BBConnectUtils();
	BBUtils bbComps = new BBUtils();
	private String sTestDataSheetName = "PersonaliseYourQuote";
	
	//BusinessBankingLoginPage1 bizobj = null;
	SetPageName s1= null;
	public String loanApplicable;
	public String LombardApplicable;
	public String cardsapplicable;
	public String Account;
	//public String OverdraftApplicable;
	public String Status;
	public static String LombardCardURL; 
    public static String APR;
	public String Interestrate;
	public String Totalrepayment;
	public static String expTotalrepayment;
	public static String expMonthlyrepayment;
	public String TotalinterestLN;
	public String TotalinterestOD;
	public String Monthlypayment;
	public String OverdraftLimit;
	public String AnnualFee;
	public String FixedTerm;
	public String TotalinterestLoaN;
	public String EntityType;
	public static String AmountSliderValue;
	public static String TermSliderValue;
	public static String RiskBand;
	public static String expinterestrate;
	public static double arrangementfee=0;
	
	public PersonaliseYourQuote() {
		super();
		PageFactory.initElements(getDriver(), this);
		//bizobj = new BusinessBankingLoginPage1();
		s1= new SetPageName();


	}
	

	public void inputValuesInPersonaliseQuotePage(String sTestName)
			throws Exception {
		try
		{
			s1.setupTestName(sTestDataSheetName +"_"+sTestName,"chrome",sTestDataSheetName+"_"+sTestName);
			Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
					sTestDataSheetName, sTestName);
			RiskBand = tdRow.get("Riskband");
			AmountSliderValue=tdRow.get("AmountSliderValue");
			
			TermSliderValue = tdRow.get("TermSliderValue");
			// get security pin number and update the fields
			//Customer Number
			//commoncomps.waitForLoading();	
			commoncomps.waitForPageHeaderToAppear("Personalise your quote");
			//commoncomps.sleepTime(3);
			commoncomps.inputInTextBoxZambesi(driver, "AmountSlider", tdRow.get("AmountSliderValue"));
			//commoncomps.sleepTime(4);
			commoncomps.inputInTextBoxZambesi(driver, "TermSlider", tdRow.get("TermSliderValue"));
			//commoncomps.sleepTime(5);
			int borrow=Integer.parseInt(AmountSliderValue);
			int month=Integer.parseInt(TermSliderValue);
			commoncomps.clickAnybuttonInZambesi("Get quote");
			commoncomps.javascriptexecutorcodeforbutton("Small business loan");
			commoncomps.javascriptexecutorcodeforbutton("Business overdraft");
			
			loanApplicable = tdRow.get("loanApplicable");
			LombardApplicable  = tdRow.get("LombardApplicable");
			cardsapplicable  = tdRow.get("CardsApplicable");
			 EntityType=tdRow.get("EntityType");
			 Account=tdRow.get("Account");
			 //int account=Integer.parseInt("Account");
			
			
			 if(loanApplicable.equalsIgnoreCase("Yes"))
			{

				//commoncomps.sleepTime(3);
				 EntityType = tdRow.get("EntityType");
				if((EntityType.equalsIgnoreCase("ST")) || (EntityType.equalsIgnoreCase("PTN"))&&(borrow<25000))
			{
					APR = commoncomps.Togettextfromyourquote("APR");
					//System.out.println(APR);
				}
				else
				{
					APR = "Not Applicable";
					//System.out.println(APR);
				}	
				
				//for both overdraft
				Interestrate= commoncomps.Togettextfromyourquote("Interest rate");
				//System.out.println(Interestrate);
			//loan applicable
			
			
			Monthlypayment= commoncomps.Togettextfromyourquote("Monthly repayments");
			//System.out.println(Monthlypayment);
		
		
			
			TotalinterestLoaN= commoncomps.Togettextfromyourquote("Total interest");
			//System.out.println(TotalinterestLoaN);
			
			TotalinterestLN= commoncomps.Togettextfromyourquote("Interest rate");
			//System.out.println(TotalinterestLN);
			
			Totalrepayment= commoncomps.Togettextfromyourquote("Total repayments");
			//System.out.println(Totalrepayment);
			
			String Interestrateloan = TotalinterestLoaN.replaceAll("[�]+", "").trim();
			double TinterestLoan=Double.parseDouble(Interestrateloan);
			double  Totalrepayment=	TinterestLoan+borrow;
			
			expTotalrepayment=new Double(Totalrepayment).toString();
			expTotalrepayment=commoncomps.Formatdouble(expTotalrepayment);
			//System.out.println(expTotalrepayment);
			
			double monthlyrepay=	Totalrepayment/month;
			expMonthlyrepayment=new Double(monthlyrepay).toString();
			expMonthlyrepayment=commoncomps.Formatdouble(expMonthlyrepayment);
			//System.out.println(expMonthlyrepayment);
			
			ExcelUtils.getTestDataRow_BBC("Loan");
			if(tdRow.get("MoredetailLoan").equalsIgnoreCase("Y"))
			{
				commoncomps.clickAnylinkInZambesi("#/details/loan");
				commoncomps.Exit("Exit", tdRow.get("Exit"));
				commoncomps.switch2WindowLn();
				commoncomps.clickAnybuttonInZambesi("Choose a loan");
				ReporterA.reportPassWithSnapshot("Choose a loan"
						+ " validate if present ", "Choose a loan"
						+ "should be displayed", "Choose a loan"
						+ "is displayed", driver);
			}
			else
			{
				//System.out.println("Not Applicable");
				commoncomps.Exit("Exit", tdRow.get("Exit"));
				Thread.sleep(3000);
				commoncomps.clickAnybuttonInZambesi("Choose a loan");
			}
			
			//commoncomps.clickAnybuttonInZambesi("Choose a loan");
			
			}
			 
			else if (LombardApplicable.equalsIgnoreCase("Yes"))
			{
				commoncomps.sleepTime(3);
			commoncomps.selectlombardcard("Lombard");
			commoncomps.sleepTime(20);
			/*ReporterA.reportPassWithSnapshot("Lombard"
					+ " validate if present ", "Lombard"
					+ "should be displayed", "Lombard"
					+ "is displayed", driver);*/
			 LombardCardURL = commoncomps.selectlombardcardURL();
			 //System.out.println("LombardCardURL: "+LombardCardURL);
			 commoncomps.Exit("Exit", tdRow.get("Exit"));
			}
			else if (cardsapplicable.equalsIgnoreCase("Yes"))
			{
				commoncomps.sleepTime(3);
			commoncomps.selectcreditcard("business credit cards");
			commoncomps.sleepTime(20);
			LombardCardURL = commoncomps.selectlombardcardURL();
			//System.out.println("LombardCardURL: "+LombardCardURL);
			}
			else
			{
				//commoncomps.sleepTime(10);
				commoncomps.waitForLoading();	
				//commoncomps.waitForPageHeaderToAppear("Your overdraft quote");
				//commoncomps.sleepTime(5);
				
				//for both overdraft
				Interestrate= commoncomps.Togettextfromyourquote("Interest rate");
				//System.out.println(Interestrate);
				
			TotalinterestOD= commoncomps.Togettextfromyourquote("Interest rate");
			//System.out.println(TotalinterestOD);
				
			OverdraftLimit= commoncomps.Togettextfromyourquote("Overdraft limit");
			//System.out.println(OverdraftLimit);
			
			AnnualFee= commoncomps.Togettextfromyourquote("Arrangement Fee");
			//System.out.println(AnnualFee);
			
			FixedTerm= commoncomps.Togettextfromyourquote("Term (fixed)");
			//System.out.println(FixedTerm);
			 
		expinterestrate=commoncomps.pricingOD(tdRow.get("Riskband"),tdRow.get("AmountSliderValue"));
		//System.out.println(expinterestrate);
			 
		
			
			 String bamount=tdRow.get("AmountSliderValue");
			 int amount=Integer.parseInt(bamount);
			 String term=tdRow.get("TermSliderValue");
			 int bterm=Integer.parseInt(term);
			
			 if(amount<=500)
			 {
				arrangementfee=50; 
			 }
			 else if((amount>=501)&&(amount<=1500))
			 {
				 arrangementfee=100;  
			 }
			 else if(((amount>=1501)&&(amount<=50000))&&(bterm==1))
			 {
				 arrangementfee=150;   
			 }
			 else if(((amount>=1501)&&(amount<=50000))&&(bterm==2))
			 {
				 arrangementfee=(amount*0.5)/100;	 
			 }
			 else if(((amount>=1501)&&(amount<=50000))&&(bterm==3))
			 {
				 arrangementfee=(amount*0.6)/100;
			 }
			 else if(((amount>=1501)&&(amount<=50000))&&((bterm>=4)&&(bterm<=6)))
			 {
				 arrangementfee=(amount*1)/100; 
			 } 
			 else if(((amount>=1501)&&(amount<=50000))&&((bterm>=7)&&(bterm<=12)))
			 {
				 arrangementfee=(amount*1.5)/100;
             }
			 if(arrangementfee<150)
			 {
				 arrangementfee=150;
			 }
			 else 
			 {
				 arrangementfee=arrangementfee;
			 }
			// System.out.println(arrangementfee);
			if(tdRow.get("MoredetailOD").equalsIgnoreCase("Y"))
			{
			commoncomps.clickAnylinkInZambesi("#/details/overdraft");
			commoncomps.Exit("Exit", tdRow.get("Exit"));
			commoncomps.switch2WindowOD();
			commoncomps.clickAnybuttonInZambesi("Choose an overdraft");
			ReporterA.reportPassWithSnapshot("Choose an overdraft"
					+ " validate if present ", "Choose an overdraft"
					+ "should be displayed", "Choose a loan"
					+ "is displayed", driver);
		
				if(Account.equalsIgnoreCase("One"))
					{
					//waitForLoading();
					commoncomps.waitForPageHeaderToAppear("Confirm details and run a credit check");
				}
				
				else
				{
					//commoncomps.waitForLoading();	
					commoncomps.waitForPageHeaderToAppear("Tell us what to do with your overdraft");
				}
				
			}
			else
			{
				//System.out.println("Not Applicable");
				commoncomps.Exit("Exit", tdRow.get("Exit"));
				Thread.sleep(3000);
				commoncomps.clickAnybuttonInZambesi("Choose an overdraft");
				ReporterA.reportPassWithSnapshot("Choose an overdraft"
						+ " validate if present ", "Choose an overdraft"
						+ "should be displayed", "Choose a loan"
						+ "is displayed", driver);
			
					if(Account.equalsIgnoreCase("One"))
						{
						//waitForLoading();
						commoncomps.sleepTime(30);
						commoncomps.waitForPageHeaderToAppear("Confirm details and run a credit check");
					}
					 else if (Account.equalsIgnoreCase("OAJ"))
							
						{
						 waitForLoading();
						Thread.sleep(10000);
							commoncomps.waitForPageHeaderToAppear("Your application is in progress");
							ReporterA.reportPassWithSnapshot("Your application is in progress"
									+ " validate if present ", "Assisted Journey"
									+ "should be displayed", "Assisted Journey"
									+ "is displayed", driver);
							
						}
					else
					{
						//commoncomps.waitForLoading();	
						commoncomps.waitForPageHeaderToAppear("Tell us what to do with your overdraft");
					}
			}
			}
			 Status = "Pass";
			}
			
			// get security pin number and update the fields
			//Customer Number
		catch ( Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
			Status = "Fail";
		}
		
	}
}			
			
				
			
			

			
		
	