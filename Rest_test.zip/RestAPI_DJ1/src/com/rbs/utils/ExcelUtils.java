package com.rbs.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;


public class ExcelUtils {

	static String workbookName="\\testdata\\DJ1 Result.xls";
	/**
	 * Fetches the test data for a particular scenario from Excel
	 * @param sheetName is the Service Name
	 * @param sceNum is the Scenario number
	 * @return  test data for a particular scenario
	 */
	public static Map<String, String> getScenarioTestData(String sheetName,String sceNum) {

		String sMasterTDWorkbook =System.getProperty("user.dir") + workbookName; 
		ArrayList<Map<String, String>> tdRows = getDataFromExcel(sMasterTDWorkbook, sheetName, sceNum);
		return tdRows.get(0);
	}
		
	/**
	 * Fetches Data row from excel and converts it into MAP
	 * @param sWorkBook
	 * @param sSheetName
	 * @param sTCName
	 * @return MAP containing test data for sTCName
	 */
	private static ArrayList<Map<String, String>> getDataFromExcel(String sWorkBook, String sSheetName,
			String sTCName) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;
		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);
			row = sheet.getRow(1);
			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}
			
			rowCols = colNames.size();
			for (int i = 2; i < sheetRows; i++) {
				row = sheet.getRow(i);
				if (row!=null && row.getCell(0)!=null && row.getCell(0).getStringCellValue().equalsIgnoreCase(sTCName)) {
					rowMap = new LinkedHashMap<String, String>(rowCols);
					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c).trim();
						String value = "" + getCellValue(row.getCell(c));
						rowMap.put(key, value);
					}
					mapArray.add(rowMap);
				}
			}
			workbook.close();
			file.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mapArray;
	}
	
	private static String getCellValue(HSSFCell cell) {

		String value = null;

		switch (cell.getCellType()) {

		case Cell.CELL_TYPE_BOOLEAN:

			value = "" + cell.getBooleanCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:

			double floating_value = cell.getNumericCellValue();
			double fractionalPart = floating_value % 1;
			long integralPart = (long) Math.floor(floating_value);

			if (fractionalPart >= 0.0001)
				value = "" + floating_value;
			else
				value = "" + integralPart;

			//
			break;
		case Cell.CELL_TYPE_STRING:

			value = cell.getStringCellValue();
			break;
		}

		return value;
	}

	/**
	 * 
	 * @param sWorkBook
	 * @param sSheetName
	 * @param respString
	 * @param rownum
	 * @param colnum
	 */
	public static void writeToExcel(String sSheetName,String scNum, String actualRespString, String status,String comments) {
		
		String sMasterTDWorkbook =System.getProperty("user.dir") + workbookName;
		ArrayList<Map<String, String>> mapArray = null;
		int sheetRows = 0;
				try {
			FileInputStream file = new FileInputStream(new File(sMasterTDWorkbook));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);
			HSSFRow row = null;
			for (int i = 2; i < sheetRows; i++) {
				row = sheet.getRow(i);
				if (row!=null && row.getCell(0)!=null && row.getCell(0).getStringCellValue().equalsIgnoreCase(scNum)) {
					Cell actualRespCell = row.getCell(11);
					actualRespCell.setCellType(actualRespCell.CELL_TYPE_STRING);
					actualRespCell.setCellValue(actualRespString);
					
					Cell statusCell = row.getCell(12);
					statusCell.setCellType(statusCell.CELL_TYPE_STRING);
					statusCell.setCellValue(status);
					
					Cell commentCell = row.getCell(14);
					commentCell.setCellType(statusCell.CELL_TYPE_STRING);
					commentCell.setCellValue(comments);

					FileOutputStream opfile = new FileOutputStream(new File(sMasterTDWorkbook));
					workbook.write(opfile);
					opfile.close();
				}
			}
			workbook.close();
			file.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	
	/**
	 * 
	 * @param sWorkBook
	 * @param sSheetName
	 * @param sTCName
	 * @return
	 */
	public static ArrayList<Map<String, String>> getExpectedData(String sWorkBook, String sSheetName,
			String bin) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;
		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);
			row = sheet.getRow(1);
			int cinCol=0;
			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
				if(row.getCell(i).getStringCellValue().equals("BIN"))
					cinCol=i;
			}
			rowCols = colNames.size();
			for (int i = 2; i < sheetRows; i++) {
				row = sheet.getRow(i);
				if (row.getCell(cinCol)!=null && row.getCell(cinCol).getStringCellValue().equals(bin)) {
					rowMap = new LinkedHashMap<String, String>(rowCols);
					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						
							String value = "" + getCellValue(row.getCell(c));
						
						rowMap.put(key, value);
					}
					mapArray.add(rowMap);
				}
			}
			workbook.close();
			file.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mapArray;
	}
	
}

	
