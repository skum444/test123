package com.rbs.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

public class GenericUtils {

public static String getProperty(String sProp){
		
		java.util.Properties prop = new Properties();
		
		try {
			prop.loadFromXML(new FileInputStream("./config/Properties.xml"));
			
		} catch (InvalidPropertiesFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return prop.getProperty(sProp);
		
	}
	
public static void  setProperty(String key,String value)
	{
    	
	
		OutputStream output = null;
		java.util.Properties prop = new Properties();
		
    	try {
    		  prop.loadFromXML(new FileInputStream("./config/Properties.xml"));
    		  prop.setProperty(key,value);
    		  prop.storeToXML(new FileOutputStream("./config/Properties.xml"),""); 
			  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}

public static ArrayList<String> getBrowsers(){
	
	ArrayList<String> browsers = new ArrayList<String> ();
	try {

	        String filePath = "./config/Browsers.xls";
			FileInputStream file = new FileInputStream(new File(filePath ));

	        // Get the workbook instance for XLS file
	        HSSFWorkbook workbook = new HSSFWorkbook(file);

	        // Get first sheet from the workbook
	        HSSFSheet sheet = workbook.getSheetAt(0);

	        // Iterate through each rows from first sheet
	        Iterator<Row> rowIterator = sheet.iterator();
	        while (rowIterator.hasNext()) {
	            Row row = rowIterator.next();
	          
	            if (row.getCell(1).getStringCellValue().equals("YES"))
	            {
	            	browsers.add(row.getCell(0).getStringCellValue());
	            }
	           
	        }
	        file.close();
	        workbook.close();

	    } catch (FileNotFoundException e1) {
	        e1.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	 
	return browsers;
}

}
