package com.rbs.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

import com.jayway.restassured.response.Response;

public class CreditUtils {
 


public void ListLoop (String pathval, String datatype, Response resp, int rownum, String Sheetname)
{
	String repval = null;
	if (datatype.equalsIgnoreCase("Integer"))
			{
		List <Integer> resp1 = resp.then().extract().path(pathval);
		 try
	      {
	    	  for (int j=0;j<resp1.size();j++)
	    	  {
	    		  
	    		  System.out.println("Using index  for loop J"+ resp1.get(j));
	    	int value = resp1.get(j);
	    	repval = Integer.toString(value);
	    	  ExcelUtils.writeTestDataRow_BB(
	    			  Sheetname, repval ,rownum,j*3+2);
	    	 
	    	  }
	      
	      }
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 if(pathval.equalsIgnoreCase("facilityDetails.cin"))
   	  {
   		  try
		      {
		    	  for (int j=0;j<resp1.size();j++)
		    	  {
		    		  System.out.println("Using index for loop J"+ resp1.get(j));
		    		  int value = resp1.get(j);
				      repval = Integer.toString(value);
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  Sheetname, repval ,rownum+1,j*3+2);
				    		  Map<String, String> tddRow= ExcelUtils.getTestDataRow_expected("Address", repval);
				    		  int expvalcol =1;
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  Sheetname, tddRow.get("CUSTOMER_NO") ,expvalcol+2,j*3+1);
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  Sheetname, tddRow.get("BUSINESS_ID") ,expvalcol+3,j*3+1);
				    		  ExcelUtils.writeTestDataRow_BB(
				    				  Sheetname, tddRow.get("CUSTOMER_TITLE") ,expvalcol+4,j*3+1);
		    	  }
		      }
		      catch(Exception e)
				 {
					 System.out.println(e);
				 }
		
		        }
		 
			}
	else
		 if (datatype.equalsIgnoreCase("String"))
			{
				List <String> respSt = resp.then().extract().path(pathval);
				 try
			      {
			    	  for (int j=0;j<respSt.size();j++)
			    	  {
			    		  
			    		  System.out.println("Using index  for loop J"+ respSt.get(j));
			    	String value = respSt.get(j);
			    	
			    	  ExcelUtils.writeTestDataRow_BB(
			    			  Sheetname, value ,rownum,j*3+2);
			    	 
			    	  }
			      }
			    	  catch(Exception e)
						 {
							 System.out.println(e);
						 }  
			}
		
		 
	    	
	    	  }
	      
	     
			}
	
	

	





