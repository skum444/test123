package com.rbs.automation.commonutils;
import java.sql.Connection;
import java.io.*;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.apache.poi.*;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.rbs.pages.Accountdetails;
import com.stepdef.prodFinder.ProdFinderSD;

public class OracleBBC 
{
	
	 public static String applid=null;
	 public static String CIN=null;
	 public static String BIN=null;
	 Accountdetails a1= new Accountdetails();
	 private String sTestDataSheetName = "Personaldetails";
	 private String pTestDataSheetName = "PersonaliseYourQuote";
	 private String qTestDataSheetName = "welcome";
	 private String lpTestDataSheetName = "LoginPage1";
	 public static Connection connection=null;
	 OracleDBUtils o1= new OracleDBUtils();
		public static ResultSet getStatement(final Connection  connection,final String sql) throws Exception
	{
	Statement stmt=null;
	ResultSet resultSet=null;
		try 
		{
		 stmt=connection.createStatement();
		 resultSet=stmt.executeQuery(sql);
		// ReporterA.reportPass("Executing qry " + sql, "Should be executed", "as expected");
		 
		} catch (SQLException e) 
		{
			e.printStackTrace();
		//	ReporterA.reportFail("Executing qry " + sql, "Should be executed", "as expected");
		}
		return resultSet;
	}
	
	public static void closeConnection(Statement  statement,Connection conn)
	{
		try 
		{
			statement.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 * @throws Exception
	 */
	
	public static Connection getConnection() throws Exception
	{ 
	   
	   Logger.LogMessage("Creating oracle connection");
      try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Logger.LogMessage("Oracle JDBC Driver Registered!");
			
			//connection string to go to property file
			String Reg = ProdFinderSD.Reg_Brand;
			//QA Connection String
			if(Reg.contains("QA"))
			{
           connection = DriverManager.getConnection(
            		"jdbc:oracle:thin:@vstcogb02d.server.rbsgrp.mde:1535:COGBLN2"
 					, "LND_APP_USER_RO",
			"L3nd09z3rR0#2346");
			}
			else if (Reg.contains("NFT"))
        // NFT Connection String
			{ connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@scan-st-n-285.server.rbsgrp.mde:1565/NOGBLEN1NFTE"
         					, "LND_APP_USER_RO",
					"L3nd09z3rR0#0001"); 
			}
			else if (Reg.contains("NFT"))
			{
			// pre-NFT conenction string
			connection = DriverManager.getConnection("jdbc:oracle:thin:@vstblod01n.server.rbsgrp.mde:1535/DOGBBPD1"
  					, "LND_APP_USER_RO",
				"L3nd09z3rR0#9881"); 
			}
            System.out.println("Connected....."); 
           
			//ReporterA.reportPass("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 ", "Should be successful",
					//"as expected");
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			ReporterA.reportFail("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 "
					, "Should be successful"
					, "Unable to connect (ClassNotFoundException)"
					+ e.getStackTrace() );
			
		} catch (Exception e) {
			e.printStackTrace();
			ReporterA.reportFail("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 "
					, "Should be successful"
					, "Unable to connect (Exception)"
					+ e.getStackTrace() );
			
		}  
	
    	return connection;
		
	}

	public void callBackDBFetch( String sTestName, String rownum) throws Exception
	{
		Map<String, String> tdlpRow = ExcelUtils.getTestDataRow_BB(
				lpTestDataSheetName, sTestName);
	String sql = "SELECT APPL_ID FROM (select APPL_ID from LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB where DBID='"+tdlpRow.get("Customer Number")+"'  order by LAST_UPD_TS desc) WHERE ROWNUM = 1 ";
	String appli_id = null;
	Connection connection=getConnection();
	ResultSet resultSet=getStatement(connection,sql);
	while(resultSet.next())
	{
		appli_id=resultSet.getString("appl_id");
	}
	String sql1 = "select APPL_ID,CALL_BACK_FLAG,PREFERRED_CONTACT_NO,CALL_BACK_REASON from LND_APP_OWNER.LND_Application_TB where APPL_ID = '"+appli_id+"'";
	ResultSet resultSet1=getStatement(connection,sql1);
	while(resultSet1.next())
	{
		appli_id=resultSet1.getString("appl_id");
		String CBFlag=resultSet1.getString("CALL_BACK_FLAG");
		String CBPrefContno=resultSet1.getString("PREFERRED_CONTACT_NO");
		String CBReason=resultSet1.getString("CALL_BACK_REASON");
		System.out.println("CBFlag: "+ CBFlag);
		System.out.println("CBPrefContno: "+ CBPrefContno);
		System.out.println("CBReason: "+ CBReason);
				
	}
	int rownum1 = Integer.parseInt(rownum);
	appIdUpdate(appli_id ,sTestName,rownum1);
	}
	
	
	public void appdetupdate( String sTestName, String rownum) throws Exception
	{
		 String tsTestDataSheetName = "PersonaliseYourQuote";
		Map<String, String> tdlpRow = ExcelUtils.getTestDataRow_BB(
				lpTestDataSheetName, sTestName);
		Map<String, String> tdtsRow = ExcelUtils.getTestDataRow_BB(
				tsTestDataSheetName, sTestName);
		String  Account=tdtsRow.get("Account");
	String sql = "SELECT APPL_ID FROM (select APPL_ID from LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB where DBID='"+tdlpRow.get("Customer Number")+"'  order by LAST_UPD_TS desc) WHERE ROWNUM = 1 ";
	String appli_id = null;
	Connection connection=getConnection();
	ResultSet resultSet=getStatement(connection,sql);
	while(resultSet.next())
	{
		appli_id=resultSet.getString("appl_id");
	}
	
	int rownum1 = Integer.parseInt(rownum);
	System.out.println("Application id:" + appli_id);
	appIdUpdate(appli_id ,sTestName,rownum1);
	if ((Account.equalsIgnoreCase("OAJ")) || (Account.equalsIgnoreCase("LAJ")))
	{
		o1.reasontextUpdate(appli_id ,sTestName,rownum1);
	}
	}
	
	public void appIdUpdate(String ApplicationID ,  String sTestName,int rowcount) throws Exception
	{
		System.out.println("Application id:" + ApplicationID);
		ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails",sTestName,rowcount,0);
		ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails",ApplicationID,rowcount,1);
		
		
		
		
	}
	public void DBFetch(String sTestName, String rownum) throws Exception
	{
		//Map<String, String> tdRow = ExcelUtils.getTestDataRow_BB(
			//	sTestDataSheetName, sTestName);
		Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
				pTestDataSheetName, sTestName);
		Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
				qTestDataSheetName, sTestName);
		
		if((tdpRow.get("LombardApplicable").equalsIgnoreCase("No"))&&(tdpRow.get("CardsApplicable").equalsIgnoreCase("No")))
		{
		String email=tdqRow.get("eMail");
		String sql="select appl_ID,CIN,BIN from lnd_app_owner.lnd_bb_eligibility_tb where appl_ID in (select distinct appl_ID from lnd_app_owner.LND_ENTITY_INDIV_TB where ELECT_ADDR_TEXT = '"+email+"')";
		String testnum =sTestName.replaceAll("[^0-9]+", "").trim();
		int tstnum = Integer.parseInt(testnum);
		Connection connection=getConnection();
		ResultSet resultSet=getStatement(connection,sql);
		System.out.println("SQL successfull");
		String Workbook = System.getProperty("user.dir") + "\\testdata\\ApplicationDetails.xls"; 
		 FileInputStream fis = new FileInputStream(Workbook);
			HSSFWorkbook wb = new HSSFWorkbook(fis);
			Sheet sh = wb.getSheet("ApplicationDetails");
			try{
				
			
		while(resultSet.next())
		{
		 applid = resultSet.getString("appl_id");
		 System.out.println("applid from db using email fetch"+applid);
		  CIN = resultSet.getString("CIN");
		 System.out.println(CIN);
		  BIN = resultSet.getString("BIN");
		 System.out.println(BIN);
		}
			}
			catch ( Exception e)
			{
				e.printStackTrace();
				System.out.println(e);
				
			}
			String applica_id = a1.appl_ID;
		int rowNumber = Integer.parseInt(rownum);
		Row row = sh.getRow(tstnum);
		//Row row = sh.getRow(1);
		Cell cell = row.createCell(2);
		cell.setCellValue("");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(applica_id);
		cell = row.createCell(3);
		cell.setCellValue("");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(CIN);
		cell = row.createCell(4);
		cell.setCellValue("");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(BIN);
		FileOutputStream fos = new FileOutputStream("C:\\BBconnect_E2E\\testdata\\ApplicationDetails.xls");
		wb.write(fos);
		fos.close();
		System.out.println("Excel file written the appid" + applica_id );
		wb.close();
		
			/*try {
				int colnum=1;
				while(resultSet.next())
				{
					int rownum=resultSet.getRow();
					if(rownum<=2)
					{
						
				applid = resultSet.getString("appl_id");
				appinitdate = resultSet.getDate("APPL_INIT_DATE");
				appstatus = resultSet.getString("appl_status");
				portfoliocode = resultSet.getInt("PORTFOLIO_CD");
				borrpulp = resultSet.getString("BORROWING_PURP");
				borramt = resultSet.getInt("BORROWING_AMT");
				borrterm = resultSet.getInt("BOROWWING_TERM");
				codetoreceivefunds = resultSet.getInt("SORT_CODE_TO_RECV_FUND");
				accnum = resultSet.getInt("ACC_NO_TO_RECV_FUNDS");
				codetorepayfunds = resultSet.getInt("SORT_CODE_TO_REPAY_FUNDS");
				accnumtorepayfunds = resultSet.getInt("ACC_NO_TO_REPAY_FUNDS");
				repayDate = resultSet.getInt("REPYMNT_DATE");
				fullName = resultSet.getString("INDIV_FULL_NAME");
				//entityID = resultSet.getInt("ENTITY_ID");
				//contactPri = resultSet.getString("contact_priority");
				DOB = resultSet.getDate("DOB");
				telno = resultSet.getLong("TEL_NO");
				email = resultSet.getString("ELECT_ADDR_TEXT");
				CINCreditGrade = resultSet.getString("CIN_CREDIT_GRADE");
				fraudMarkerCode = resultSet.getString("CIN_FRAUD_MARKER_CODE");
				CKYC = resultSet.getString("CIN_KYC");
				CSPLcredit = resultSet.getString("CIN_SPCL_CREDIT_GRADE");
				partyID = resultSet.getLong("PARTY_ID");
				entityTyp = resultSet.getString("ENTITY_TYP");
				BINshadow = resultSet.getInt("BIN_SHADOW_LIMIT");
				totalDebt = resultSet.getLong("TOT_AGG_BUSS_DEBT");
				BINcredit = resultSet.getString("BIN_CREDIT_GRADE");
				BINfraudMarker = resultSet.getString("BIN_FRAUD_MARKER_CODE");
				BINKYC = resultSet.getString("BIN_KYC");
				BINSPLcredit = resultSet.getString("BIN_SPCL_CREDIT_GRADE");
				//HistInd = resultSet.getString("ADDR_HIST_IND");
				Addln1 = resultSet.getString("ADDR_LINE_1_TXT");
				Addln2 = resultSet.getString("ADDR_LINE_2_TXT");
				Addln3 = resultSet.getString("ADDR_LINE_3_TXT");
				Addln4 = resultSet.getString("ADDR_LINE_4_TXT");
				Addln5 = resultSet.getString("ADDR_LINE_5_TXT");
				postCode = resultSet.getString("ADDR_POSTCODE");
				intRate = resultSet.getFloat("MB_INTEREST_RATE");
				prcApr = resultSet.getFloat("PRC_APR");
				monRepay = resultSet.getFloat("MB_MNTHLY_REPAYMENTS");
				totInterest = resultSet.getFloat("MB_TOTAL_INTERST");
				totRepayAmt = resultSet.getFloat("PRC_TOTAL_REPAY_AMOUNT");
				
				
				
				HSSFCreationHelper createHelper = wb.getCreationHelper();
				HSSFCellStyle cellStyleDec = wb.createCellStyle();
				HSSFCellStyle cellStyleDec1 = wb.createCellStyle();
				HSSFCellStyle cellStyleDec2 = wb.createCellStyle();
				HSSFCellStyle cellStyleDate = wb.createCellStyle();
				HSSFCellStyle cellStyleDec3 = wb.createCellStyle();
				cellStyleDec.setDataFormat(createHelper.createDataFormat().getFormat("##.###"));
				cellStyleDec1.setDataFormat(createHelper.createDataFormat().getFormat("#############.####"));
				cellStyleDec2.setDataFormat(createHelper.createDataFormat().getFormat("#############.##"));
				cellStyleDate.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
				
				cellStyleDec3.setAlignment(HSSFCellStyle.ALIGN_LEFT);
				System.out.println(appinitdate);
				
				
				for ( int i=1;i<=39;i++)
				{
					Row row;
					/*if(rownum==1)
					{
					row = sh.createRow(i);
					}*/
				/*	row = sh.getRow(i);
					Cell cell = row.createCell(colnum);	
					if(i==1)
					{
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cell.setCellValue(applid);
					}
					else if(i==2)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(appinitdate);	
						cell.setCellStyle(cellStyleDec3);
						cell.setCellStyle(cellStyleDate);
						
					}
					else if(i==3)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(appstatus);	
					}
					else if(i==4)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(portfoliocode);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==5)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(borrpulp);	
					}
					else if(i==6)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(borramt);
						cell.setCellStyle(cellStyleDec3);
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==7)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(borrterm);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==8)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(codetoreceivefunds);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==9)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(accnum);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==10)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(codetorepayfunds);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==11)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(accnumtorepayfunds);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==12)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(repayDate);
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==13)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(fullName);	
					}
					/*else if(i==14)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(entityID);	
					}
					else if(i==15)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(contactPri);	
					}*/
				 /*  else if(i==14)
				 	{
					   
					   // HSSFCreationHelper createHelper = wb.getCreationHelper();
						//HSSFCellStyle cellStyle = wb.createCellStyle();
						//cellStyleDate.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
						cell.setCellValue(DOB);
						cell.setCellStyle(cellStyleDec3);
						cell.setCellStyle(cellStyleDate);
						
						
					}
					
					else if(i==15)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(telno);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==16)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(email);
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==17)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(CINCreditGrade);	
					}
					else if(i==18)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(fraudMarkerCode);	
					}
					else if(i==19)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(CKYC);	
					}
					else if(i==20)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(CSPLcredit);	
					}
					else if(i==21)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(partyID);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==22)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(entityTyp);	
					}
					else if(i==23)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(BINshadow);
						cell.setCellStyle(cellStyleDec3);
					}
					
					else if(i==24)
					{
						cell.setCellType(Cell.CELL_TYPE_NUMERIC);
						cell.setCellValue(totalDebt);	
						cell.setCellStyle(cellStyleDec3);
					}
					else if(i==25)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(BINcredit);	
					}
					else if(i==26)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(BINfraudMarker);	
					}
					else if(i==27)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(BINKYC);	
					}
					
					else if(i==28)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(BINSPLcredit);	
					}
					/*else if(i==31)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(HistInd);	
					}*/
				/*	else if(i==29)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(Addln1);	
					}
					
					else if(i==30)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(Addln2);	
					}
					
					else if(i==31)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(Addln3);	
					}
					
					else if(i==32)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(Addln4);	
					}
					
					else if(i==33)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(Addln5);	
					}
					
					else if(i==34)
					{
						cell.setCellType(Cell.CELL_TYPE_STRING);
						cell.setCellValue(postCode);
						cell.setCellStyle(cellStyleDec3);
					}
					
					else if(i==35)
					{
						    //HSSFCreationHelper createHelper = wb.getCreationHelper();
							//HSSFCellStyle cellStyle = wb.createCellStyle();
							//cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#.#"));
							cell.setCellValue(intRate);
							cell.setCellStyle(cellStyleDec);
							cell.setCellStyle(cellStyleDec3);
					
					}
					else if(i==36)
					{
							cell.setCellValue(prcApr);
							cell.setCellStyle(cellStyleDec1);
							cell.setCellStyle(cellStyleDec3);
					
					}
					else if(i==37)
					{
							cell.setCellValue(monRepay);
							cell.setCellStyle(cellStyleDec);
							cell.setCellStyle(cellStyleDec3);
					
					}
					else if(i==38)
					{
							cell.setCellValue(totInterest);
							cell.setCellStyle(cellStyleDec);
							cell.setCellStyle(cellStyleDec3);
					
					}
					else if(i==39)
					{
						  	cell.setCellValue(totRepayAmt);
							cell.setCellStyle(cellStyleDec2);
							cell.setCellStyle(cellStyleDec3);
					
					}
					
			
				}
				colnum++;
				
							//System.out.println("Processid: " +processid);
					}
				}
				FileOutputStream fos = new FileOutputStream("C:\\BBConnect\\testdata\\DBData2.xls");
				wb.write(fos);
				fos.close();
				System.out.println("Excel file written"); */
				
			/*} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
	        
	      }
	}
	}

