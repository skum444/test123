package com.rbs.automation.commonutils;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class StafSelenium {

	public static void SafeClick(WebDriver driver, WebElement element) {

		try {
			element.click();
			System.out.println("Click on Element " + element.getText());
			//Reporter.reportFail("Click on Element " + element.getText(),
			//		"Element Should be clicked", "Element clicked");
		} catch (ElementNotFoundException e) {
			
		} catch (ElementNotVisibleException e) {
			
		}
	}
}
