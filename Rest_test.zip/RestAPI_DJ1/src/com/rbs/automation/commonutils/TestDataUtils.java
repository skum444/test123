package com.rbs.automation.commonutils;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestDataUtils {

	
	// Method to get test data for the Test Method in execution
	public static HashMap<String, HashMap<String,String>> getTestDatafromDB(Method M)
			throws Exception {
		HashMap<String, String> innerTable = null;
		HashMap<String, HashMap<String,String>> outerTable = new HashMap<String, HashMap<String,String>>();

		
		String excelQuery = "select * from " + M.getName();
		
		Logger.LogMessage("Executing Query " + excelQuery);
		ResultSet rsHeader = CSVDBUtils.getResultSetFromSQL(excelQuery);

		ResultSetMetaData md = rsHeader.getMetaData();
		int columns = md.getColumnCount();
		int startColumn = 1;

		List<String> lstHeader = new ArrayList<String>();

		for (int i = startColumn; i <= columns; i++) {
				String sHeader = md.getColumnName(i);
				//Log.LogMessage("adding to list " + sHeader);
				lstHeader.add(sHeader);
			}
		
		
		excelQuery = "select * from " + M.getName() + " Where RunMode='Y' and ENV='SIT'";
		Logger.LogMessage("Executing Query " + excelQuery);
		ResultSet rsValues = CSVDBUtils.getResultSetFromSQL(excelQuery);

		

		int iRow = 1;
		while (rsValues.next()) {
			innerTable = new HashMap<String, String>();

			for (int i = 0; i < lstHeader.size(); i++) {
				innerTable.put(lstHeader.get(i),
						rsValues.getString(i + startColumn));
			}
			outerTable.put("DataRow" + iRow, innerTable);
			iRow = iRow + 1;
		}

		rsHeader.close();
		rsValues.close();
		Logger.LogMessage("Existing Re");
		return outerTable;
		
	}

}
