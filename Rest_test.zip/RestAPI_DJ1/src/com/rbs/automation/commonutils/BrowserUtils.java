package com.rbs.automation.commonutils;

import java.net.URL;
import java.util.Arrays;
import java.util.logging.Level;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.rbs.pages.BasePage;

public class BrowserUtils {

                public static String CurrentBrowser = null;
                final static String PROXY = "wwwisa04.rbsgrp.net:80";
                static DesiredCapabilities cap;

                public BrowserUtils() {
                                
                }

                public static WebDriver getChromeDriverNoProxy() {

                                String strChromeBinPath=GenericUtils.getProperty("ChromeDriver");
                                String strChromeProfile=GenericUtils.getProperty("ChromeDefaultProfile");
                                
                                
                                System.setProperty("webdriver.chrome.driver",strChromeBinPath);

                                // set chrome options to disable blank data page while opening
                                ChromeOptions options = new ChromeOptions();
                                options.addArguments("test-type");
                                options.addArguments("--start-maximized");
                                options.addArguments("user-data-dir=" + strChromeProfile);
                                options.addArguments("chrome.switches","--disable-extensions");
                                options.addArguments("--enable-javascript");
//                            System.setProperty("webdriver.chrome.driver",(System.getProperty("user.dir") + "//src//test//resources//chromedriver_new.exe"));

                                
                                Proxy proxy= new Proxy();
                                proxy.setProxyType(ProxyType.DIRECT);
                                
                                // set chrome capabilities to disable blank data page while opening
                                DesiredCapabilities capabilities = DesiredCapabilities.chrome();
                                capabilities.setCapability("chrome.binary",strChromeBinPath    );
                
                                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                                capabilities.setCapability(CapabilityType.PROXY,proxy);

                                // initiate driver
                                WebDriver driver = new ChromeDriver(capabilities);

                                // EventFiringWebDriver eventDriver = new EventFiringWebDriver(driver);
                                //
                                // EventHandler handler = new EventHandler();
                                // eventDriver.register(handler);

                                return driver;
                }

                public static WebDriver getChromeDriver() {

                                System.setProperty("webdriver.chrome.driver",
                                                                GenericUtils.getProperty("ChromeDriver"));

                                // set chrome options to disable blank data page while opening
                                ChromeOptions options = new ChromeOptions();
                                options.addArguments("test-type");
                                options.addArguments("--start-maximized");
                                options.addArguments("user-data-dir="
                                                                + GenericUtils.getProperty("ChromeDefaultProfile"));

                                // set chrome capabilities to disable blank data page while opening
                                DesiredCapabilities capabilities = DesiredCapabilities.chrome();
                                capabilities.setCapability("chrome.binary",
                                                                GenericUtils.getProperty("ChromeDriver"));
                                capabilities.setCapability(ChromeOptions.CAPABILITY, options);


                                // initiate driver
                                WebDriver driver = new ChromeDriver(capabilities);

                                // EventFiringWebDriver eventDriver = new EventFiringWebDriver(driver);
                                //
                                // EventHandler handler = new EventHandler();
                                // eventDriver.register(handler);

                                return driver;
                }

               /* public static WebDriver getHtmlUnitDriver() {

                                org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
                                proxy.setHttpProxy(PROXY).setFtpProxy(PROXY).setSslProxy(PROXY);

                                cap.setCapability(CapabilityType.PROXY, proxy);
                                WebDriver driver = new HtmlUnitDriver(cap);

                                return driver;
                }*/

                public static WebDriver getFirefoxDriverNoProxy() {

                                //final String firebugPath = "C:\\automation\\Common\\libs\\firebug\\firebug-2.0.11-fx.xpi";
                                FirefoxProfile profile = new FirefoxProfile();

                                // add firebug if required
                                // try {
                                // profile.addExtension(new File(firebugPath));
                                // } catch (IOException e) {
                                // e.printStackTrace();
                                // }

                                // profile.setPreference("webdriver.load.strategy", "unstable");
                                profile.setPreference("network.proxy.type", 0);
                                return new FirefoxDriver(profile);
                }

                public static WebDriver getExitingFirefoxDriver() {
                                WebDriver driver;

                                try {
                                                URL hubUrl = new URL("http://localhost:7055/hub"); // firefox:7055

                                                System.out.println(System.getProperty("webdriver.firefox.port"));
                                                driver = new RemoteWebDriver(hubUrl, DesiredCapabilities.firefox());
                                                // driver.get("http://www.google.com/finance");

                                                System.out.println("existing browser");
                                } catch (Exception e) {
                                                System.out.println("new broswer " + e.getMessage());
                                                driver = BrowserUtils.getFirefoxDriver();
                                                // driver.get("http://www.google.com");
                                                System.out.println("new broswer");
                                                System.out.println(System.getProperty("webdriver.firefox.port"));

                                }/*
                                * 
                                 * try{ URL hubUrl = new URL("http://localhost:7055/hub"); //firefox
                                * uses port 7055 as default driver = new RemoteWebDriver(hubUrl,
                                * DesiredCapabilities.firefox());
                                * //driver.get("http://www.google.com/finance");
                                * System.out.println("existing browser"); } catch(Exception e){
                                * System.out.println("Exception " + e.getMessage()); driver =
                                * getFirefoxDriver(); //driver.get("http://www.google.com");
                                * System.out.println("new broswer"); }
                                */
                                return driver;
                }

                public static WebDriver getFirefoxDriver() {
                                // The Firefox driver supports javascript

                                String PROXY = "wwwisa04.rbsgrp.net:80";

                                org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
                                proxy.setHttpProxy(PROXY).setFtpProxy(PROXY).setSslProxy(PROXY);
                                DesiredCapabilities cap = new DesiredCapabilities();
                                cap.setCapability(CapabilityType.PROXY, proxy);

                                WebDriver driver = new FirefoxDriver(cap);

                                /*
                                * final String firebugPath =
                                * "C:/TEMP/Automation/Lib/Selenium/fireBug/firebug-2.0.9-fx.xpi";
                                * FirefoxProfile profile = new FirefoxProfile(); try {
                                * profile.addExtension(new File(firebugPath)); } catch (IOException e)
                                * { e.printStackTrace(); }
                                * 
                                 * FirefoxBinary binary = new FirefoxBinary(new
                                * File("c:\\temp\\myFF\\Firefox.exe")); WebDriver driver = new
                                * FirefoxDriver(binary, profile, cap);
                                */
                                return driver;
                }

                public static WebDriver getIE8() {

                                System.setProperty("webdriver.ie.driver",
                                                                GenericUtils.getProperty("IE8Driver"));
                                WebDriver driver = new InternetExplorerDriver();

                                return driver;
                }

                public static WebDriver SetupAndLaunchBrowser() {
                                if (CurrentBrowser.toUpperCase().toUpperCase()
                                                                .equalsIgnoreCase("FIREFOX")) {
                                                // launch firefox
                                                return BrowserUtils.getFirefoxDriver();

                                } else if (CurrentBrowser.toUpperCase().equalsIgnoreCase("CHROME")) {
                                                // launch chrome
                                                return BrowserUtils.getChromeDriver();
                                } else if (CurrentBrowser.toUpperCase().equalsIgnoreCase("IE8")) {
                                                // launch ie8
                                                return BrowserUtils.getIE8();

                                }
                                return null;

                }
public static WebDriver getChrome(){
		ChromeOptions options = new ChromeOptions();
		options.addArguments("chrome.switches","--disable-extensions");
		options.addArguments("--incognito"); 
        options.setExperimentalOption("useAutomationExtension", false);
                    DesiredCapabilities capabilities = DesiredCapabilities.chrome();
                    capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
                    System.setProperty("webdriver.chrome.driver",
                                                    GenericUtils.getProperty("ChromeDriver"));
                    
                    LoggingPreferences logPrefs = new LoggingPreferences();
                    logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
                    capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
                    capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                    
                   
                    /*ChromeOptions options = new ChromeOptions();
                    options.addArguments("chrome.switches","--disable-extensions");
                    options.addArguments("--incognito"); 
                    options.setExperimentalOption("useAutomationExtension", false);*/
                    
                    //WebDriver driver = new ChromeDriver(options);
                    WebDriver driver = new ChromeDriver(capabilities);
                    return driver;
    } 

                public static void CloseBrowser() {
                                /*System.out.println("closing .. :" + driver.getTitle());
                                driver.close();*/
                                System.out.println("closing .. :" + BasePage.driver.getTitle());
                                BasePage.driver.close();
                                
                                BasePage.driver.quit();
                                BasePage.driver=null;
                }
                
public static WebDriver getIE8NoProxy() {
                                
                                DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
                                
                                dc.setCapability("ie.usePerProcessProxy", true);
        dc.setCapability("ie.usePerProcessProxy", true);
        dc.setCapability("ie.setProxyByServer", true);
        
        dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS , true);

        
        Proxy p = new Proxy();
                                p.setProxyType(ProxyType.DIRECT);

                                dc.setCapability(CapabilityType.PROXY, p);
        
                                
                                // initiate driver
                                System.setProperty("webdriver.ie.driver",GenericUtils.getProperty("IE8Driver"));
                                
                                WebDriver driver = new InternetExplorerDriver(dc);

                                return driver;
                }

}
