package com.rbs.automation.commonutils;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
/*import org.testng.Reporter;
import org.testng.asserts.Assertion;*/

import com.google.common.base.Function;
import com.rbs.bpm.automation.bbconnect.objects.TestCase;
import com.rbs.bpm.automation.bbconnect.tests.TestBase;
//import com.sun.media.sound.Toolkit;
import com.rbs.pages.BasePage;

public class BBConnectUtils extends BasePage {
	
	public String Status;
	static public String URL;
	static public String Text;

	public static void main(String args[]) throws IOException {
		BBConnectUtils util = new BBConnectUtils();
		

	}

	private void test() {
		// TODO Auto-generated method stub
		String a = "Account Opening Process Id : 25283 for : Instance";
		System.out.println(a.replaceAll("[^0-9]+", ""));
	}
	
	//zambesi
	public void clickStartButton(String linkText) {
        // button[text()='Next']
        waitForLoading();
        waitForLoadingElementInvisibility(driver);
        try {
              WebElement expButtonToClick = findAnyWebElement(
                          By.xpath("//button[@class='popover coachmark down left sticky']"),
                          linkText);
              ReporterA.reportPassWithSnapshot(linkText
                          + " validate if present ", linkText
                          + "should be displayed", linkText
                          + "is displayed", driver);
              Thread.sleep(4);
              //button[@class='hud-download-btn']
              //button//span[text()='"+linkText+"']
              if (expButtonToClick != null) {
                    
                    expButtonToClick.click();
                    
                    /*ReporterA.reportPassWithSnapshot(linkText
                                + " validate if present ", linkText
                                + "should be displayed", linkText
                                + "is displayed", driver);*/
                    Logger.LogMessage("Button has been clicked---" + linkText);
              }
        } catch (Exception e) {
              // TODO Auto-generated catch block
              Logger.LogMessage("Button could not be clicked---" + linkText);
              e.printStackTrace();
        }
        
  }

		public void CancelApplication() {

			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				
				WebElement expButtonToClick = driver
						.findElement(By
								.xpath("//a[contains(text(),'Cancel application')]"));
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
					
				
					Logger.LogMessage("Link has been clicked---");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Link could not be clicked---");
				e.printStackTrace();
			}

		}
		//good news 

		public void ZambesiCheckboxgoodnews() {
			
			waitForLoading();
			//waitForLoadingElementInvisibility(driver);
			try {
				WebElement expYesOrNoButton = driver
						.findElement(By
								.xpath("//label[@class='control-label']/input[@type='checkbox']/../span[@class='checkbox-image']"));
				
				if (expYesOrNoButton != null) {
						expYesOrNoButton.click();
						
					}
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public void CancelRadioButton(String radio, String text) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = driver
						.findElement(By
								.xpath("//label[@for='"+radio+"'][@id='"+text+"']"));
						
				
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
			
					Logger.LogMessage("Button has been clicked---");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---");
				e.printStackTrace();
			}
			
		}
		public void inputInTextBoxZambesiCancelReaon(WebDriver driver,String spFieldName,String Value) {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
		
			try {
				WebElement expTextBoxFrame = driver
						.findElement(By
								.xpath("//textarea[@type='"+spFieldName+"']"));
				
				
				if (expTextBoxFrame != null) {
					
						
						validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
						
						waitForLoading();
						Logger.LogMessage("Input in text box---successfull");
					}
					
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("exception occured while entering value in---");
				e.printStackTrace();
			}


	}
		
		public void javascriptexecutorcodedocheaderLE(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//span[contains(@class,'ProductHeader_title')][text()='"+LabelName+"']"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		public  String pricingOD(String rband,String amount) throws IOException {
			try
			{
			String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Pricing.xls";  
			FileInputStream fis1 = new FileInputStream(sMasterTDWorkbook);
			HSSFWorkbook wb1 = new HSSFWorkbook(fis1);
			int riskband=0;
			int endamount=0;
			int startamount=0;
			String interestrate=null;
			int bammount=Integer.parseInt(amount);
			int band=Integer.parseInt(rband);
			Sheet sh1 = wb1.getSheet("Overdraft");
			Row row;
			int noofrow=sh1.getPhysicalNumberOfRows();
			System.out.println(noofrow);
			for (int k = 1; k < noofrow-1; k++)
			{
				row = sh1.getRow(k);
				riskband=(int) row.getCell(2).getNumericCellValue();
				startamount=(int) row.getCell(0).getNumericCellValue();
				endamount=(int) row.getCell(1).getNumericCellValue();
				if(((bammount>=startamount) && (bammount<=endamount)) && (band ==riskband))
			{
			interestrate= row.getCell(8).getStringCellValue();
			}
				
			}
			return interestrate;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println(e);	
				return null;
			}	
		}
		public void WritevalueToExcel(String respval, int rownum,int columnnumber, String sheetname,String workbookname) {
		       try {
		              String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\DBValidations_"+workbookname+".xls";  
		              FileInputStream fis1 = new FileInputStream(sMasterTDWorkbook);
		              HSSFWorkbook wb1 = new HSSFWorkbook(fis1);
		              Sheet sh1 = null;
		              sh1 = wb1.getSheet(sheetname);
		              Row row;
		              row = sh1.getRow(rownum);
		              int j=columnnumber;
		              Cell cell = row.createCell(j);    
		              cell.setCellValue("");
		              cell.setCellType(cell.CELL_TYPE_STRING);
		              cell.setCellValue(respval);
		              FileOutputStream fos = new FileOutputStream(sMasterTDWorkbook);
		        wb1.write(fos);
		              fos.close();  
		       }
		 catch (FileNotFoundException e) {
		              
		              e.printStackTrace();
		       } catch (IOException e) {
		       
		              e.printStackTrace();
		       }
		       
		}
		public String Formatamount(String Labelname)
		{
			
		int length = Labelname.length();
		int convamt=Integer.parseInt(Labelname);
		DecimalFormat ForAmt =new DecimalFormat("000");
		DecimalFormat ForAmount =new DecimalFormat("0,000");
		if(length<=3)
		{
			Labelname=ForAmt.format(convamt);	
		}
		else if(length>3)
		{
			Labelname=ForAmount.format(convamt);		
		}
		return Labelname;		
		}
		public String Formatdecimal(String Labelname)
		{
			float convamt = Float.parseFloat(Labelname);
		DecimalFormat ForAmt =new DecimalFormat("0.00");
		Labelname=ForAmt.format(convamt);	
		System.out.println(Labelname);
		return Labelname;		
		}
		public String Formatdecimalsingle(String Labelname)
		{
			float convamt = Float.parseFloat(Labelname);
		DecimalFormat ForAmt =new DecimalFormat("0.0");
		Labelname=ForAmt.format(convamt);	
		System.out.println(Labelname);
		return Labelname;		
		}
		public String Togettextfromyourquote(String Text) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			String ZambesiTexth1;
			
			try {
				List<WebElement>expButtonToClick = driver
						.findElements(
						By.xpath("//div[contains(text(),'"+Text+"')]/div"));
				WebElement expButtonClick=expButtonToClick.get(0);
				ZambesiTexth1	= expButtonClick.getText();
					return ZambesiTexth1;
				
			}
			 catch (Exception e) {
				// TODO Auto-generated catch block
				//Logger.LogMessage("Button could not be clicked---" + Text);
				e.printStackTrace();
				return null;
			}

		}
		public String Formatdouble(String Labelname)
		{
	    double convamt= Double.parseDouble(Labelname); 
		DecimalFormat ForAmt =new DecimalFormat("#.##");
		 ForAmt.setRoundingMode(RoundingMode.CEILING);
		Labelname=ForAmt.format(convamt);
		System.out.println(Labelname);
		return Labelname;		
		}
		public void javascriptexecutorcodedocsubheaderLE(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//span/b[contains(text(),'"+LabelName+"')]"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			//jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		
		public void javascriptexecutorcodePCILE(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//span[contains(text(),'"+LabelName+"')]"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			//jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		
		public void clickdocOption(String LabelName, String option)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//span[contains(@class,'ProductHeader_title')][text()='"+LabelName+"']/ancestor::div[contains(@class,'ApprovedPage_acceptableDocument')]//a[contains(text(),'"+option+"')]"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			//jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			expTextBoxFrame.click();
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		
		public void clickdocConfirm(String LabelName, String option)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//span[contains(@class,'ProductHeader_title')][text()='"+LabelName+"']/ancestor::div[contains(@class,'ApprovedPage_acceptableDocument')]//button[text()='"+option+"']"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			//jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
			expTextBoxFrame.click();
			
		
		}
		
		public void clickAnybuttonInZambesicallback(String buttonText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//button[text()='" + buttonText + "']"),
						buttonText);
				if (expButtonToClick != null) {
					expButtonToClick.click();
					
					//validateAndClick(buttonText, expButtonToClick);
					// doubleClick(buttonText, expButtonToClick);
					Logger.LogMessage("Button has been clicked---" + buttonText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + buttonText);
				e.printStackTrace();
			}

		}
		
		
		//close button for callback
				public void closeButtonforCallback(String buttonText) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						
						List<WebElement> expButtonToClick = driver
								.findElements(
										By.xpath("//button[text()='" + buttonText + "']"));
						
						if (expButtonToClick != null) {
							
							expButtonToClick.get(1).click();
							/*ReporterA.reportPassWithSnapshot(buttonText
									+ " validate if present ", buttonText
									+ "should be displayed", buttonText
									+ "is displayed", driver);*/
							//validateAndClick(buttonText, expButtonToClick);
							// doubleClick(buttonText, expButtonToClick);
							Logger.LogMessage("Button has been clicked---" + buttonText);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + buttonText);
						e.printStackTrace();
					}

				}

		
		//zambesi
				public void selectlombardcard(String linktext) {

					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						JavascriptExecutor jse = (JavascriptExecutor) driver;
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//span[text()='Hire Purchase']/../following-sibling::div//a[contains(text(),'"+linktext+"')]"),
								linktext);
						if (expButtonToClick != null) {
							//Thread.sleep(1000);
							jse.executeScript("arguments[0].scrollIntoView(true);",expButtonToClick);
							
							ReporterA.reportPassWithSnapshot("Lombard"
									+ " validate if present ","Lombard"
							+ "should be displayed","Lombard"
									+ "is displayed", driver);
							Thread.sleep(1000);
							
							
							expButtonToClick.click();
							URL = driver.getCurrentUrl();
						/*	WebElement value = driver
									.findElement(By
											.xpath("//span[contains(text(),' The page cannot be displayed')]"));
							Thread.sleep(5000);
							ReporterA.reportPassWithSnapshot(value
									+ " validate if present ", value
									+ "should be displayed", value
									+ "is displayed", driver);
							driver.close();*/
							
									
							
							Logger.LogMessage("Button has been clicked---" + linktext);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + linktext);
						e.printStackTrace();
					}

				}
				public void selectcreditcard(String linktext) {

					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						JavascriptExecutor jse = (JavascriptExecutor) driver;
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//span[text()='Credit Cards']/../following-sibling::div//a[contains(text(),'business credit cards.')]"),
								linktext);
						if (expButtonToClick != null) {
							//Thread.sleep(1000);
							jse.executeScript("arguments[0].scrollIntoView(true);",expButtonToClick);
							
							ReporterA.reportPassWithSnapshot("business credit cards."
									+ " validate if present ","business credit cards."
							+ "should be displayed","business credit cards."
									+ "is displayed", driver);
							Thread.sleep(1000);
							
							
							expButtonToClick.click();
							URL = driver.getCurrentUrl();
						
							Logger.LogMessage("Button has been clicked---" + linktext);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + linktext);
						e.printStackTrace();
					}

				}
				/*public void selectlombardcard(WebDriver driver,String linktext) {
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
				
					try {
						List<WebElement> expCheckBox = driver
								.findElements(By
										.xpath("//span[text()='Hire Purchase']/../following-sibling::div//a[contains(text(),'"+linktext+"')]"));
						if (expCheckBox != null) {
							
								if(expCheckBox.size()>=1)
								{
									validateAndClick(linktext, expCheckBox.get(0));
								}
								
								waitForLoading();
								Logger.LogMessage("Input in text box---successfull");
							}
							
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("exception occured while entering value in---"
								+ linktext);
						e.printStackTrace();
					}

				}*/
				public String selectlombardcardURL() {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String URL= null;
					try {
						String mainwindow = driver.getWindowHandle();
						
						ArrayList<String> tab = new ArrayList <String> (driver.getWindowHandles());
						driver.switchTo().window(tab.get(1));
						waitForLoading();
						waitForLoadingElementInvisibility(driver);
							URL = driver.getCurrentUrl();
							ReporterA.reportPassWithSnapshot("Lombard/Card"
									+ " validate if present ", "Lombard/Card"
									+ "should be displayed", "Lombard/Card"
									+ "is displayed", driver);
						
						return URL;
						}
					catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" );
						e.printStackTrace();
						return null;
					}

				}
				
				public void javascriptexecutorcodeforbutton(String LabelName)  {
				       JavascriptExecutor jse = (JavascriptExecutor) driver;
				       WebElement expTextBoxFrame = driver
				                     .findElement(By
				                                  .xpath("//span[text()='" + LabelName + "']"));
				       
				       jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
				                                  sleepTime(2);
				       ReporterA.reportPassWithSnapshot(LabelName
				                     + " validate if present ", LabelName
				                     + "should be displayed", LabelName
				                     + "is displayed", driver);
				 
				} 


		//zambesi
				public String Togettext(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String OverDraftText;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//h3[contains(text(),'" +Text+ "')]"),
								Text);
					
							OverDraftText	= expButtonToClick.getText();
							return OverDraftText;
						}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				
				
				public String TogettextInZambesih1(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth1;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//h1[contains(text(),'" +Text+ "')]"),
								Text);
					
						ZambesiTexth1	= expButtonToClick.getText();
							return ZambesiTexth1;
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				//R6 Pre credit
				/*
				  public String TogettextInZambesih1(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth1;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//h1[contains(text(),'" +Text+ "')]"),
								Text);
					
						ZambesiTexth1	= expButtonToClick.getText();
							return ZambesiTexth1;
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				 */
				public  void switch2WindowLn() {

					try {
						JavascriptExecutor jse = (JavascriptExecutor) driver;
						String windHandbefore = driver.getWindowHandle();
			 			System.out.println(driver.getCurrentUrl());
						ArrayList<String> Latesttab = new ArrayList<String>(
								driver.getWindowHandles());
						driver.switchTo().window(Latesttab.get(1));
						System.out.println(driver.getCurrentUrl());
						pageheader("Small business loans");
						ReporterA.reportPassWithSnapshot( "Smallbusinessloans"
								+ " validate if present ", "Smallbusinessloans"
								+ "should be displayed", "Smallbusinessloans"
								+ "is displayed", driver);
						WebElement expTextBoxFrame = driver
								.findElement(By
										.xpath("//a[contains(text(),'Credit scoring guide')]"));
						jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
						jse.executeScript("window.scrollBy(0,-100)","");
						ReporterA.reportPassWithSnapshot("Credit scoring guide"
								+ " validate if present ", "Credit scoring guide"
								+ "should be displayed", "Credit scoring guide"
								+ "is displayed", driver);
						expTextBoxFrame.click();
						
						Thread.sleep(10000);
						ArrayList<String> Latestwin = new ArrayList<String>(
								driver.getWindowHandles());
						driver.switchTo().window(Latestwin.get(2));
						WebElement value = driver
								.findElement(By
										.xpath("//span[contains(text(),' The page cannot be displayed')]"));
						Thread.sleep(5000);
						ReporterA.reportPassWithSnapshot(value
								+ " validate if present ", value
								+ "should be displayed", value
								+ "is displayed", driver);
						Thread.sleep(1000);
						System.out.println(driver.getCurrentUrl());
						driver.close();
						Thread.sleep(1000);
						driver.switchTo().window(Latestwin.get(1));
						System.out.println(driver.getCurrentUrl());
						WebElement close=driver.findElement(By.xpath("//button[contains(text(),'Close')]"));
						close.click();
						driver.switchTo().window(Latestwin.get(0));
						Thread.sleep(1000);
						System.out.println(driver.getCurrentUrl());
						
						
						//javascriptexecutorcodeScrolldown("Credit scoring guide");
						//newTab.remove(oldTab);
						// change focus to new tab
						
						//driver.close();
						// change focus back to old tab
						} catch (Exception e) {
							e.printStackTrace();
						System.out.println("Tab switching not done ");
						}
					}
					public  void switch2WindowOD() {

						try {
							JavascriptExecutor jse = (JavascriptExecutor) driver;
							String windHandbefore = driver.getWindowHandle();
				 			System.out.println(driver.getCurrentUrl());
							ArrayList<String> Latesttab = new ArrayList<String>(
									driver.getWindowHandles());
							driver.switchTo().window(Latesttab.get(1));
							System.out.println(driver.getCurrentUrl());
							pageheader("Business overdrafts");
							waitForLoading();
							ReporterA.reportPassWithSnapshot( "Business overdrafts"
									+ " validate if present ", "Business overdrafts"
									+ "should be displayed", "Business overdrafts"
									+ "is displayed", driver);
							WebElement expTextBoxFrame = driver
									.findElement(By
											.xpath("//a[contains(text(),'Credit scoring guide')]"));
							jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
							jse.executeScript("window.scrollBy(0,-100)","");
							ReporterA.reportPassWithSnapshot("Credit scoring guide"
									+ " validate if present ", "Credit scoring guide"
									+ "should be displayed", "Credit scoring guide"
									+ "is displayed", driver);
							expTextBoxFrame.click();
							
							Thread.sleep(10000);
							ArrayList<String> Latestwin = new ArrayList<String>(
									driver.getWindowHandles());
							driver.switchTo().window(Latestwin.get(2));
							WebElement value = driver
									.findElement(By
											.xpath("//span[contains(text(),' The page cannot be displayed')]"));
							Thread.sleep(5000);
							ReporterA.reportPassWithSnapshot(value
									+ " validate if present ", value
									+ "should be displayed", value
									+ "is displayed", driver);
							Thread.sleep(1000);
							System.out.println(driver.getCurrentUrl());
							driver.close();
							Thread.sleep(1000);
							driver.switchTo().window(Latestwin.get(1));
							System.out.println(driver.getCurrentUrl());
							WebElement close=driver.findElement(By.xpath("//button[contains(text(),'Close')]"));
							jse.executeScript("arguments[0].scrollIntoView(true);",close);
							jse.executeScript("window.scrollBy(0,-100)","");
							ReporterA.reportPassWithSnapshot("Close"
									+ " validate if present ", "Close"
									+ "should be displayed", "Close"
									+ "is displayed", driver);
							close.click();
							driver.switchTo().window(Latestwin.get(0));
							Thread.sleep(1000);
							System.out.println(driver.getCurrentUrl());
							
							
							//javascriptexecutorcodeScrolldown("Credit scoring guide");
							//newTab.remove(oldTab);
							// change focus to new tab
							
							//driver.close();
							// change focus back to old tab
							} catch (Exception e) {
								e.printStackTrace();
							System.out.println("Tab switching not done ");
						}

				}

				public void Exit(String value,String sheet)
				{
					if(sheet.equalsIgnoreCase("Yes")){
						
					
					try {
						WebElement linkToCLick = driver
								.findElement(By
										.xpath("//span[text()='"+value+"']"));
						if (linkToCLick != null) {
							validateAndClick(value, linkToCLick);
							/*
							 * Thread.sleep(4); scrollElementToView(driver, linkToCLick);
							 * 
							 * linkToCLick.click();
							 */

							Logger.LogMessage("Clicking on the Link--" + value);
							waitForLoading();
							clickAnybuttonInZambesi("Exit");
							String mainwindow = driver.getWindowHandle();
							ReporterA.reportPassWithSnapshot(value
									+ " validate if present ", value
									+ " should be displayed", value
									+ " is displayed", driver);
							ArrayList<String> tab = new ArrayList <String> (driver.getWindowHandles());
							driver.switchTo().window(tab.get(0));
							/*WebElement header = driver
									.findElement(By
											.xpath("//span[contains(text(),' The page cannot be displayed')]"));
							Thread.sleep(5000);
							ReporterA.reportPassWithSnapshot(header
									+ " validate if present ", header
									+ "should be displayed", header
									+ "is displayed", driver);
							waitForLoading();
							*/
							
							
							//driver.close();
						} else {
							Logger.LogMessage("Could not cLick on the Link--" + value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Could not cLick on the Link--" + value);
						e.printStackTrace();
					}
				
					
					}}
				public void WritevalueToExcel(String respval, int rownum,int columnnumber, String sheetname) {
				       try {
				              String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\DBValidations_"+sheetname+".xls";  
				              FileInputStream fis1 = new FileInputStream(sMasterTDWorkbook);
				              HSSFWorkbook wb1 = new HSSFWorkbook(fis1);
				              Sheet sh1 = null;
				              sh1 = wb1.getSheet(sheetname);
				              Row row;
				              row = sh1.getRow(rownum);
				              int j=(columnnumber*3);
				              Cell cell = row.createCell(j);    
				              cell.setCellValue("");
				              cell.setCellType(cell.CELL_TYPE_STRING);
				              cell.setCellValue(respval);
				              FileOutputStream fos = new FileOutputStream(sMasterTDWorkbook);
				        wb1.write(fos);
				              fos.close();  
				       }
				 catch (FileNotFoundException e) {
				              
				              e.printStackTrace();
				       } catch (IOException e) {
				       
				              e.printStackTrace();
				       }
				       
				}

				
				public String Togettextfromrecevaccdetails(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth1;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//select[@name='receiving']//..//div[contains(text(),'"+Text+"')]"),
								Text);
					
						ZambesiTexth1	= expButtonToClick.getText();
						ReporterA.reportPassWithSnapshot("Snapshot of account details page","is displayed","sucessfully", driver);
							return ZambesiTexth1;
							
							
						
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				public String Togettextfromrepayaccdetails(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth1;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//select[@name='repayment']//..//div[contains(text(),'"+Text+"')]"),
								Text);
					
						ZambesiTexth1	= expButtonToClick.getText();
							return ZambesiTexth1;
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				public String Togettextfromyourdetails(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiText;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//label[contains(text(),'"+Text+"')]//..//h4"),
								Text);
					
						ZambesiText	= expButtonToClick.getText();
							return ZambesiText;
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				
				public String Togettextfromcurrentaddress(String Text,int i) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiText;
										
					try {
						
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//label[contains(text(),'"+Text+"')]//..//h4/div/span["+i+"]"),Text);
					
						ZambesiText	= expButtonToClick.getText();
						return ZambesiText;
						
					}
					
					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("field not available---" + Text);
						//e.printStackTrace();
						return null;
					}
					}
				String ZambesiTextAdd;
				public String Togettextfromcurrentaddressupdated(String Text,int i) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiText;
										
					try {
						;
						
						
						List<WebElement>	 expButtonToClick = driver.findElements(
								By.xpath("//strong[contains(text(),'Current address')]//..//following-sibling::div//h4"));
					
						if (expButtonToClick != null) {
						
							ZambesiTextAdd = expButtonToClick.get(i).getText();
							}
						//ZambesiText	= expButtonToClick.getText();
						return ZambesiTextAdd;
						
					}
					
					
					 catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("field not available---" + Text);
						//e.printStackTrace();
						return null;
					}
					}
				
				
				public String TogettextInZambesih4(String labelname) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth4;
					
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//div[contains(@class,'PurposeWithImageDisplay_container')]/h4[text()='"+labelname+"']"),
								labelname);
					
						ZambesiTexth4	= expButtonToClick.getText();
							return ZambesiTexth4;
						
					}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}

				}
				
				/*commenting it for R6
				//h2 text
				public String TogettextInZambesih2(String Text) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth2;
					
					try {
						/*already commented
						 * WebElement expButtonToClick = findAnyWebElement(
						 
								By.xpath("//h2[contains(text(),'" +Text+ "')]"),Text);
					
						ZambesiTexth2	= expButtonToClick.getText();
							return ZambesiTexth2;*/
						/*	WebElement expButtonToClick = findAnyWebElement(
									By.xpath("//span[contains(text(),'"+Text+"')]//..//h2"),Text);
						
							ZambesiTexth2	= expButtonToClick.getText();
								return ZambesiTexth2;
						}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}
				}*/
				 //R6 Pre credit
				
				    public String TogettextInZambesih2(String LabelName) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					String ZambesiTexth2;
					
					try {
							
							/*WebElement expButtonToClick = findAnyWebElement(
									By.xpath("//span[contains(@class,'text')][contains(text(),'"+LabelName+"') or contains(text(),'"+LabelName2+"')]/..//h2"),Text);*/
						
						//WebElement expButtonToClick = findAnyWebElement(
								//By.xpath("//h2[contains(text(),'" +LabelName+ "')]"),
								//Text);
					WebElement expButtonToClick = findAnyWebElement(
                             By.xpath("//div[contains(@class,'"+LabelName+"')]//h2"),
							Text); 

							
							ZambesiTexth2	= expButtonToClick.getText();
								return ZambesiTexth2;
						}
					 catch (Exception e) {
						// TODO Auto-generated catch block
						//Logger.LogMessage("Button could not be clicked---" + Text);
						e.printStackTrace();
						return null;
					}
				}
				
				//zambesi wait for URL
				public void waitForURLToAppear(String URL1, String URL2) {

					Logger.LogMessage("Entering waitForElementToAppear");
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

						WebDriverWait wait = new WebDriverWait(driver, 30);
						try
						{
						if((wait.until(ExpectedConditions.urlContains(URL1))) || (wait.until(ExpectedConditions.urlContains(URL2))))
						{
							System.out.println("inside URL if loop");
						}
						}
						catch(Exception e)
						{
							System.out.println(e);
						}
						
						// wait.until(ExpectedConditions.elementToBeClickable(element));
						/*ReporterA.reportPassWithSnapshot(
								"Wait for element: " + elementName, elementName
										+ " should appear", elementName + " has appeared",
								driver);*/
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Exception in waitforelementtoAppear in Base Page--");
						driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						e.printStackTrace();
					}

					Logger.LogMessage("Exiting waitForElementToAppear");
				}

				//login validation
				public String checkLoginvalidationByLabelName() {
					String loginStatus="";
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						sleepTime(10);
						waitForURLToAppear("welcome","inEligible");
						 URL = driver.getCurrentUrl();
						System.out.println(URL);
						/*WebElement elet = driver
								.findElement(By
										.xpath("//h1[contains(text(),'Welcome')]"));
						String txt = elet.getText();*/
						
						if(URL.contains("welcome"))
							//https://bbc.nwb-qa-1.mybank.managedtest.com/content/#/welcome?_k=14dunp
						{
							loginStatus="Eligible customer";
							
						}
						else if(URL.contains("inEligible"))
							//.equalsIgnoreCase("https://bbc.nwb-qa-1.mybank.managedtest.com/inEligible")
							
						{
							loginStatus="Ineligible customer";
							
							
						}
						else
							loginStatus="Time out issue";
						
							return loginStatus;
							
					} 
					catch (NoSuchElementException e)
					{
						
						return "invalidlogin";
						
					}
					catch (Exception e)
					{
						
						return "invalidlogin";
						
					}

				}	
					// R6 pre credit
					/*
					 *  public String checkLoginvalidationByLabelName() {
					 
					   String loginStatus="";
					   waitForLoading();
					  waitForLoadingElementInvisibility(driver);
					  		try {
						sleepTime(30);
						waitForURLToAppear("Hello","inEligible");
						 URL = driver.getCurrentUrl();
						System.out.println(URL);
						
						
						if(URL.contains("Hello"))
							//https://bbc.nwb-qa-1.mybank.managedtest.com/content/#/welcome?_k=14dunp
						{
							loginStatus="Eligible customer";
							
						}
						else if(URL.contains("inEligible"))
							//.equalsIgnoreCase("https://bbc.nwb-qa-1.mybank.managedtest.com/inEligible")
							
						{
							loginStatus="Ineligible customer";
						}
						else
							loginStatus="Time out issue";
						
							return loginStatus;
							
					}
					 
					 
					catch (NoSuchElementException e)
					{
						
						return "invalidlogin";
						
					}
					catch (Exception e)
					{
						
						return "invalidlogin";
						
					}
					}	
			*/	

		//zambesi hyper link
		public void clickAnylinkInZambesi(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//a[@href='" + linkText + "']"),
						linkText);
				//a[@href='#/help?tab=contactUs']
				//button[text()='" + buttonText + "']
				if (expButtonToClick != null) {
					expButtonToClick.click();
					
					
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		
		public void inputInTextBoxZambesiContactNumber(WebDriver driver,String spFieldName,String Value) {
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
      
            try {
                  WebElement expTextBoxFrame = driver
                              .findElement(By
                                          .xpath("//input[@class='"+spFieldName+"']"));
                  ReporterA.reportPassWithSnapshot(spFieldName
                        + " validate if present ", spFieldName
                        + "should be displayed",spFieldName
                        + "is displayed", driver);
                  Thread.sleep(4);
                  
                  if (expTextBoxFrame != null) {
                        
                              
                              validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
                              ReporterA.reportPassWithSnapshot(spFieldName
                                    + " validate if present ", spFieldName
                                    + "should be displayed",spFieldName
                                    + "is displayed", driver);
                              Thread.sleep(4);
                              waitForLoading();
                              Logger.LogMessage("Input in text box---successfull");
                        }
                        
                  
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("exception occured while entering value in---"
                              + spFieldName);
                  e.printStackTrace();
            }


}

		public void receipt(String linkText,int position) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  List<WebElement> expButtonToClick = driver
                              .findElements(By.xpath("//button[text()='" + linkText + "']"));
                  ReporterA.reportPassWithSnapshot(linkText
                        + " validate if present ", linkText
                        + "should be displayed",linkText
                        + "is displayed", driver);
                  Thread.sleep(4);
                  if (expButtonToClick != null) {
                        WebElement button=expButtonToClick.get(position);
                        button.click();
                        ReporterA.reportPassWithSnapshot(linkText
                              + " validate if present ", linkText
                              + "should be displayed",linkText
                              + "is displayed", driver);
                        Thread.sleep(4);
                        Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }

		public void clickAnybuttonInZambesi(String buttonText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                              By.xpath("//button[text()='" + buttonText + "']"),
                              buttonText);
                  if (expButtonToClick != null) {
                        ReporterA.reportPassWithSnapshot(buttonText
                                    + " validate if present ", buttonText
                                    + "should be displayed", buttonText
                                    + "is displayed", driver);
                        Thread.sleep(3);
                        expButtonToClick.click();
                        
                        //validateAndClick(buttonText, expButtonToClick);
                        // doubleClick(buttonText, expButtonToClick);
                        Logger.LogMessage("Button has been clicked---" + buttonText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + buttonText);
                  e.printStackTrace();
            }

      }


		public void downloadpdf(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//button[@class='"+linkText+"']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		
		
		public void clickStartButtontab(String linkText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                              By.xpath("//button[@class='requiredFieldsIcon badge']"),
                              linkText);
                  //button[@class='hud-download-btn']
                  //button//span[text()='"+linkText+"']
                  if (expButtonToClick != null) {
                        ReporterA.reportPassWithSnapshot(linkText
                                    + " validate if present ", linkText
                                    + "should be displayed", linkText
                                    + "is displayed", driver);
                        //expButtonToClick.click();
                        expButtonToClick.sendKeys(Keys.TAB.TAB.ENTER);
                  
                        Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }
		public void signButton(String linkText, int index) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  List<WebElement> expButtonToClick = driver.findElements(
                              By.xpath("//div[@role='button'][@class='faux_field']"));
                  
                  if (expButtonToClick != null) {
                        /*ReporterA.reportPassWithSnapshot(linkText
                                    + " validate if present ", linkText
                                    + "should be displayed", linkText
                                    + "is displayed", driver);*/
                        expButtonToClick.get(index).click();
                        Thread.sleep(3);
                        ReporterA.reportPassWithSnapshot(linkText
                                    + " validate if present ", linkText
                                    + "should be displayed", linkText
                                    + "is displayed", driver);
                        Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }
public void typesignature(String linkText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                              By.xpath("//input[@class='form-control signature-type-name adobehanda']"),
                              linkText);
                  //button[@class='hud-download-btn']
                  //button//span[text()='"+linkText+"']
                  if (expButtonToClick != null) {
                        
                        expButtonToClick.click();
                        expButtonToClick.sendKeys(linkText);
                        ReporterA.reportPassWithSnapshot(linkText
                                    + " validate if present ", linkText
                                    + "should be displayed", linkText
                                    + "is displayed", driver);
                        Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }


		public void clickreqfieldstab(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//button[@class='requiredFieldsIcon badge']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					//expButtonToClick.click();
					expButtonToClick.sendKeys(Keys.ENTER);
				
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		public void signButton(String linkText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                                By.xpath("//div[@role='button'][@class='faux_field']"),
                                linkText);
                  //button[@class='hud-download-btn']
                  //button//span[text()='"+linkText+"']
                  if (expButtonToClick != null) {
                         
                         expButtonToClick.click();
            
                         Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
     }
		public void navigatetopage(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//input[@class='hud-current-num']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
					expButtonToClick.clear();
					expButtonToClick.sendKeys(linkText);
					expButtonToClick.sendKeys(Keys.ENTER);
					
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		
		public void signButtonsbunreg(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//div[@role='button'][@class='faux_field']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		public void ButtoninAdobe(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//button[@role='button'][text()='"+linkText+"']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		public void ButtoninAdobetab(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//button[@role='button'][text()='"+linkText+"']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.sendKeys(Keys.TAB.ENTER);
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		public void Startinhotdoc(String linkText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                              By.xpath("//button[@class='"+linkText+"']"),
                              linkText);
                  ReporterA.reportPassWithSnapshot(linkText
                        + " validate if present ", linkText
                        + "should be displayed",linkText
                        + "is displayed", driver);
                  Thread.sleep(4);
                  if (expButtonToClick != null) {
                        expButtonToClick.click();
                                          Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }

		public void receiptButtoninAdobe(String linkText) {
            // button[text()='Next']
            waitForLoading();
            waitForLoadingElementInvisibility(driver);
            try {
                  WebElement expButtonToClick = findAnyWebElement(
                              By.xpath("//button[text()='"+linkText+"']"),
                              linkText);
                  //button[@class='hud-download-btn']
                  //button//span[text()='"+linkText+"']
                  ReporterA.reportPassWithSnapshot(linkText
                        + " validate if present ", linkText
                        + "should be displayed", linkText
                        + "is displayed", driver);
                  Thread.sleep(3);
                  if (expButtonToClick != null) {
                        
                        expButtonToClick.click();
            
                        Logger.LogMessage("Button has been clicked---" + linkText);
                  }
            } catch (Exception e) {
                  // TODO Auto-generated catch block
                  Logger.LogMessage("Button could not be clicked---" + linkText);
                  e.printStackTrace();
            }
            
      }

		
		public void downloadaCopy(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//a[@id='download-signed-pdf']"),
						linkText);
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		public void ilataken(String linkText) {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expButtonToClick = null;
				if(linkText.equalsIgnoreCase("Yes"))
				{
					expButtonToClick = findAnyWebElement(
						By.xpath("//input[@name='ilaChoice'][@value='Taken'][@type='radio']"),
						linkText);
				}
				else if(linkText.equalsIgnoreCase("No"))
				{
					expButtonToClick = findAnyWebElement(
							By.xpath("//input[@name='ilaChoice'][@value='NotTaken'][@type='radio']"),
							linkText);
				}
				//button[@class='hud-download-btn']
				//button//span[text()='"+linkText+"']
				if (expButtonToClick != null) {
					
					expButtonToClick.click();
					expButtonToClick.sendKeys(Keys.TAB);
					//expButtonToClick.sendKeys(linkText);
			
					Logger.LogMessage("Button has been clicked---" + linkText);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Button could not be clicked---" + linkText);
				e.printStackTrace();
			}
			
		}
		
		
		// for javascriptexecutorcode
		public void javascriptexecutorcodewithScrolldown(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//h1[contains(@class,'PageHeading_headingText_41R5')][contains(text(),'"+LabelName+"')]"));
			//h1[contains(@class,'PageHeading_headingText_41R5')][contains(text(),'Thank you - application received')]
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}

		public String getHeaderInelig() {
			// button[text()='Next']
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			String textval = null;
			try {
				WebElement expButtonToClick = driver.findElement(
						By.xpath("//h1[contains(@class,'IneligiblePage_header')]"));
				if (expButtonToClick != null) {
					textval=expButtonToClick.getText();
					ReporterA.reportPassWithSnapshot("IneligHeader"
							+ " validate if present ", "IneligHeader"
							+ "should be displayed", "IneligHeader"
							+ "is displayed", driver);
										Logger.LogMessage("Button has been clicked---" + "IneligHeader");
				
				}
				return textval;
			} catch (Exception e) {
				
				Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
				e.printStackTrace();
				return null;
			}

		}
public void clickLinkInfoundacct() {
			
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			
			try {
				WebElement expButtonToClick = driver.findElement(
						By.xpath("//a[@role='link']"));
				if (expButtonToClick != null) {
					expButtonToClick.click();
					sleepTime(3);
					ReporterA.reportPassWithSnapshot("IneligHeader"
							+ " validate if present ", "IneligHeader"
							+ "should be displayed", "IneligHeader"
							+ "is displayed", driver);
										Logger.LogMessage("Button has been clicked---" + "IneligHeader");
				
				}
				
			} catch (Exception e) {
				
				Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
				e.printStackTrace();
				
			}

		}

public String getHeaderIneligfoundacct() {
	// button[text()='Next']
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	String textval = null;
	try {
		WebElement expButtonToClick = driver.findElement(
				By.xpath("//div[contains(@class,'IneligiblePage_header')]/h1"));
		if (expButtonToClick != null) {
			textval=expButtonToClick.getText();
			ReporterA.reportPassWithSnapshot("IneligHeader"
					+ " validate if present ", "IneligHeader"
					+ "should be displayed", "IneligHeader"
					+ "is displayed", driver);
								Logger.LogMessage("Button has been clicked---" + "IneligHeader");
		
		}
		return textval;
	} catch (Exception e) {
		
		Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
		e.printStackTrace();
		return null;
	}

}
		//zambesi  contact number text box
public void downloadsignedpdf(String linkText) {
    // button[text()='Next']
    waitForLoading();
    waitForLoadingElementInvisibility(driver);
    try {
          WebElement expButtonToClick = findAnyWebElement(
                      By.xpath("//h3//..//a[contains(text(),'"+linkText+"')]"),
                      linkText);
          ReporterA.reportPassWithSnapshot(linkText
                      + " validate if present ", linkText
                      + "should be displayed", linkText
                      + "is displayed", driver);
          if (expButtonToClick != null) {
                expButtonToClick.click();
                Logger.LogMessage("Button has been clicked---" + linkText);
                ReporterA.reportPassWithSnapshot(linkText
                            + " validate if present ", linkText
                            + "should be displayed", linkText
                            + "is displayed", driver);
          }
    } catch (Exception e) {
          // TODO Auto-generated catch block
          Logger.LogMessage("Button could not be clicked---" + linkText);
          e.printStackTrace();
    }
    
}

			
		//zambesi hyper link
				public void TabInZambesi(String tabText) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						WebElement expButtonToClick = findAnyWebElement(
								By.xpath("//a[@id='" + tabText + "']"),
								tabText);
						//a[@href='#/help?tab=contactUs']
						//button[text()='" + buttonText + "']
						if (expButtonToClick != null) {
							expButtonToClick.click();
							ReporterA.reportPassWithSnapshot(tabText
									+ " validate if present ", tabText
									+ "should be displayed", tabText
									+ "is displayed", driver);
							//validateAndClick(buttonText, expButtonToClick);
							// doubleClick(buttonText, expButtonToClick);
							Logger.LogMessage("Button has been clicked---" + tabText);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + tabText);
						e.printStackTrace();
					}
				}
	//zambesi
			public void inputInTextBoxZambesi(WebDriver driver,String spFieldName,String Value) {
				//waitForLoading();
				waitForLoadingElementInvisibility(driver);
			
				try {
					WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//input[@id='"+spFieldName+"']"));
					
					
					if (expTextBoxFrame != null) {
						
							
							validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
							
							waitForLoading();
							//Logger.LogMessage("Input in text box---successfull");
						}
						
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ spFieldName);
					e.printStackTrace();
				}


		}
			
			
			//choose account number

			public void ZambesiRadioButtonCreditAccNumber(WebDriver driver,String idval,String expRadioButton) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expYesOrNoButton = driver
							.findElement(By
									.xpath("//label[@id='"+ idval +"']"));
					
					
						if (expYesOrNoButton != null) {
							expYesOrNoButton.click();
							ReporterA.reportPassWithSnapshot(expRadioButton
									+ " validate if present ", expRadioButton
									+ "should be displayed", expRadioButton
									+ "is displayed", driver);
						}
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			
			//credit name to write in excel from UI

			public String ZambesiCreditgetText(String iconName,int indexval,String value) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					List<WebElement> expName = driver
							.findElements(By
									.xpath("//div[contains(@class,'PersonalInfoDisplay')]/img[contains(@class,'profileImage')][@alt='"+iconName+"']/../span"));
					if(expName.size()>1)
					{
					
						WebElement value1 = expName.get(indexval);
				value = value1.getText();
					}
							
						} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return value;
			}

			//without list

			public String ZambesiCreditgetTextwithoutList(String iconName,int indexval,String value) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expName = driver
							.findElement(By
									.xpath("//div[contains(@class,'PersonalInfoDisplay')]/img[contains(@class,'profileImage')][@alt='"+iconName+"']/../span"));
					
					
						 value = expName.getText();
				
					
							
						} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return value;
			}

			public String ZambesiCreditgetTextDOB(int indexval,String value) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					List<WebElement> expName = driver
							.findElements(By
									.xpath("//div[contains(@class,'PersonalInfoDisplay')]/h5/../span"));
					if(expName.size()>1)
					{
					
						WebElement value1 = expName.get(indexval);
				value = value1.getText();
					}
							
						} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return value;
			}

			//without list

			public String ZambesiCreditgetTextDOBwithoutList(int indexval,String value) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expName = driver
							.findElement(By
									.xpath("//div[contains(@class,'PersonalInfoDisplay')]/h5/../span"));
					
				value = expName.getText();
					
							
						} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return value;
			}


public String ZambesiCreditgetTextBI(int indexval,String value) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
		List<WebElement> expName = driver
				.findElements(By
						.xpath("//div[contains(@class,'BusinessInformation_currentAddress')]//div/div"));
		if(expName.size()>1)
		{
		
			WebElement value1 = expName.get(indexval);
	value = value1.getText();
		}
				
			} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return value;
}


public String ZambesiCreditgetTextwithoutList(String iconName,String value) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
	       WebElement expName = driver
				.findElement(By
						.xpath("//div[contains(@class,'PersonalInfoDisplay')]/img[contains(@class,'profileImage')][@alt='"+iconName+"']/../span"));
		
		
	value = expName.getText();
		
				
			} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return value;
}

public String ZambesiCreditgetTextwithoutListTelNO(String iconName,String value) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
	       WebElement expName = driver
				.findElement(By
						.xpath("//div[contains(@class,'PersonalInformation')]/img[@alt='"+iconName+"']/../span"));
		
		
	value = expName.getText();
		
				
			} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return value;
}




//without list
public String ZambesiCreditgetTextAddwithoutList(int indexval,String value) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
		WebElement expName = driver
				.findElement(By
						.xpath("//div[contains(@class,'HomeAddress')]/img[@alt='Profile Icon']/../span "));
		
	value = expName.getText();
		
				
			} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return value;
}



public String ZambesiCreditgetTextAdd(int indexval,String value) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
		List<WebElement> expName = driver
				.findElements(By
						.xpath("//div[contains(@class,'HomeAddress')]/img[@alt='Profile Icon']/../span "));
		if(expName.size()>1)
		{
		
			WebElement value1 = expName.get(indexval);
	value = value1.getText();
		}
				
			} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return value;
}

			
//			credit enter data in  more about your business field using list
			
					public void inputInTextBoxZambesilist(WebDriver driver,String spFieldName,String Value, int position) {
						//waitForLoading();
						waitForLoadingElementInvisibility(driver);
					
						try {
							List<WebElement> expTextBoxFrame = driver
									.findElements(By
											.xpath("//input[@id='"+spFieldName+"']"));
							
							
							if (expTextBoxFrame != null) {
								
									
									validateAndSendKeys(spFieldName,expTextBoxFrame.get(position-1),Value);
									
									waitForLoading();
									Logger.LogMessage("Input in text box---successfull");
								}
								
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							Logger.LogMessage("exception occured while entering value in---"
									+ spFieldName);
							e.printStackTrace();
						}


				}
			
					
					// Hyperlink for credit list 
					
					public void clickAnylinkInZambesiCreditlist(String linkText,int position) {
						// button[text()='Next']
						waitForLoading();
						waitForLoadingElementInvisibility(driver);
						try {
							List<WebElement> expButtonToClick = driver.findElements(By.xpath("//a[contains(text(),'"+linkText+"')]"));
							//a[@href='#/help?tab=contactUs']
							//button[text()='" + buttonText + "']
							if (expButtonToClick != null) {
								expButtonToClick.get(position-1);
								ReporterA.reportPassWithSnapshot(linkText
										+ " validate if present ", linkText
										+ "should be displayed", linkText
										+ "is displayed", driver);
								//validateAndClick(buttonText, expButtonToClick);
								// doubleClick(buttonText, expButtonToClick);
								Logger.LogMessage("Button has been clicked---" + linkText);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							Logger.LogMessage("Button could not be clicked---" + linkText);
							e.printStackTrace();
						}
						
					}
			//R6 pre credit Phone number & EmailAddress
			 /* public void inputInTextBoxZambesi(WebDriver driver,String spFieldName,String Value) {
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
			
				try {
					WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//input[@id='"+spFieldName+"']"));
					
					
					if (expTextBoxFrame != null) {
						
							
							validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
							
							waitForLoading();
							Logger.LogMessage("Input in text box---successfull");
						}
						
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ spFieldName);
					e.printStackTrace();
				}


		}
			
			 */
					public void waitForPageHeaderToAppearCredit(String expHeaderText) {
						// WebElement header =
						// findAnyWebElement(By.xpath("//h2[contains(text(),'"+expHeaderText+"')]"),
						// expHeaderText);
                       
						waitForElementToAppear(expHeaderText,
								By.xpath("//h2[contains(text(),'" + expHeaderText + "')]"));
						
						
                        }
//zambesitry
			public void ZambesiRadioButton(WebDriver driver,String expRadioButton) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expYesOrNoButton = driver
							.findElement(By
									.xpath("//label[@id='radioYes']"));
					
						if (expYesOrNoButton != null) {
							expYesOrNoButton.click();
							ReporterA.reportPassWithSnapshot(expRadioButton
									+ " validate if present ", expRadioButton
									+ "should be displayed", expRadioButton
									+ "is displayed", driver);
						}
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
public void ZambesidiffRadioButton(WebDriver driver,String expRadioButton) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expYesOrNoButton = driver
							.findElement(By
									.xpath("//label[@id='radionewAccount']"));
					
						if (expYesOrNoButton != null) {
							expYesOrNoButton.click();
							ReporterA.reportPassWithSnapshot(expRadioButton
									+ " validate if present ", expRadioButton
									+ "should be displayed", expRadioButton
									+ "is displayed", driver);
						}
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			//zambesi
						public void ZambesiRadioButtoninAcctpage(WebDriver driver,String expRadioButton) {
							
							waitForLoading();
							waitForLoadingElementInvisibility(driver);
							try {
								WebElement expYesOrNoButton = driver
										.findElement(By
												.xpath("//input[@id='"+expRadioButton+"']"));
								
									if (expYesOrNoButton != null) {
										expYesOrNoButton.click();
										ReporterA.reportPassWithSnapshot(expRadioButton
												+ " validate if present ", expRadioButton
												+ "should be displayed", expRadioButton
												+ "is displayed", driver);
									}
								
								
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
			
public void ZambesiRadioAcctpage(WebDriver driver,String expRadioButton) {
							
							waitForLoading();
							waitForLoadingElementInvisibility(driver);
							try {
								WebElement expYesOrNoButton = driver
										.findElement(By
												.xpath("//label[@id='"+expRadioButton+"']"));
								
									if (expYesOrNoButton != null) {
										expYesOrNoButton.click();
										ReporterA.reportPassWithSnapshot(expRadioButton
												+ " validate if present ", expRadioButton
												+ "should be displayed", expRadioButton
												+ "is displayed", driver);
									}
								
								
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
			//zambesi check box
			
public void ZambesiCheckbox(WebDriver driver,String expRadioButton) {
				
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expYesOrNoButton = driver
							.findElement(By
									.xpath("//label[@for='"+ expRadioButton+ "']"));
					//label[@for='creditCheckBox']
					//input[@id='creditCheckBox']
					
					
						if (expYesOrNoButton != null) {
							expYesOrNoButton.click();
							
						}
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

//zambesi
public void ZambesiDropDown(WebDriver driver,String ID,String expRadioButton) {
	
	waitForLoading();
	waitForLoadingElementInvisibility(driver);
	try {
		WebElement expYesOrNoButton = driver
				.findElement(By
						.xpath("//select[@id='"+ID+"']/option[contains(text(),'"+expRadioButton+"')]")); 
		//label[@id='"+ expRadioButton+ "']
		//select[@id='repaymentDate']/option[@value='2']
		
			if (expYesOrNoButton != null) {
				expYesOrNoButton.click();
				ReporterA.reportPassWithSnapshot(expRadioButton
						+ " validate if present ", expRadioButton
						+ "should be displayed", expRadioButton
						+ "is displayed", driver);
			}
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public String getlabeltext( String labelname, String classname) {
		
		waitForLoading();
		
		waitForLoadingElementInvisibility(driver);
		String labelvalue;
		try {
			WebElement inforeqelt = driver.findElement(By
					.xpath("//label[@class='"+classname+"'][@for='"+labelname+"']"));
			labelvalue = inforeqelt.getText();
			return labelvalue;
			}
		catch (Exception e) {
			
		
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
		
	}

public void updateSecPin ( String labelname, String classname,char value) {
	
	waitForLoading();
	
	waitForLoadingElementInvisibility(driver);
	String labelvalue;
	try {
		WebElement inforeqelt = driver.findElement(By
				.xpath("//input[@class='"+classname+"'][@id='"+labelname+"']"));
		String val = Character.toString(value);
		inforeqelt.sendKeys(val);
		}
	catch (Exception e) {
		
	
		System.out.println(e);
		e.printStackTrace();
		
	}
	
}

public void selectBorrowingPurp ( String labelname) {
	
	waitForLoading();
	
	waitForLoadingElementInvisibility(driver);
	String labelvalue;
	try {
		WebElement inforeqelt = driver.findElement(By
				.xpath("//div[contains(@class,'PurposeWithImageDisplay_container')]/h4[text()='"+labelname+"']"));
	
		inforeqelt.click();
		}
	catch (Exception e) {
		
	
		System.out.println(e);
		e.printStackTrace();
		
	}
	
}
//R6 Pre Credit
/*
 * public void selectBorrowingPurp ( String labelname) {
	
	waitForLoading();
	
	waitForLoadingElementInvisibility(driver);
	String labelvalue;
	try {
		WebElement inforeqelt = driver.findElement(By
				.xpath("//div[contains(@class,'PurposeWithImageDisplay_container')]/h4[text()='"+labelname+"']"));
	
		inforeqelt.click();
		}
	catch (Exception e) {
		
	
		System.out.println(e);
		e.printStackTrace();
		
	}
	
}

 */

public void clickContButton ( String labelname) {
	
	waitForLoading();
	
	waitForLoadingElementInvisibility(driver);
	String labelvalue;
	try {
		WebElement inforeqelt = driver.findElement(By
				.xpath("//button[@class='continue-button'][text()='"+labelname+"']"));
		inforeqelt.click();
		}
	catch (Exception e) {
		
	
		System.out.println(e);
		e.printStackTrace();
		
	}
	
}


	
public void editInfoReq( String Sectypr) {
		
		waitForLoading();
		
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement inforeqelt = driver.findElement(By
					.xpath("//div[contains(@data-binding,'local.securityData.newSecurityDetails[index].securityName')]//span[text()='"+Sectypr+"']/ancestor::tr//div[contains(@data-binding,'local.securityData.newSecurityDetails[index].newOrExisting')]/span[text()='Edit']"));
			if (inforeqelt != null) {
				inforeqelt.click();
			
				Logger.LogMessage("Check Box---" + Sectypr
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ Sectypr);
			e.printStackTrace();
		
		
		}
		
	}
	public String checkInfoReqinSecSummary(WebDriver driver, String Sectypr) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		String inforeq = null;
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[contains(@data-binding,'local.securityData.newSecurityDetails[index].securityName')]//span[text()='"+Sectypr+"']/ancestor::tr//div[contains(@data-binding,'local.securityData.newSecurityDetails[index].informationRequired')]//span[@class='text']"));
			if (checkBoxNo != null) {
				 inforeq = checkBoxNo.getText();
			
				Logger.LogMessage("Check Box---" + Sectypr
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ Sectypr);
			e.printStackTrace();
		
		
		}
		return inforeq;
	}
	
	public void clickLinkTextInOtherSecTable(WebDriver driver, int SecurityNum) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[@data-bindingrt='local.securityData.otherSecurityDetails["+SecurityNum+"].newOrExisting']/span[text()='Edit']"));
			if (checkBoxNo != null) {
				checkBoxNo.click();
				// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
				Logger.LogMessage("Check Box---" + SecurityNum
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ SecurityNum);
			e.printStackTrace();
		}
	}

	
	// to select check box for lambard product from app basket page
	public void selectCheckboxAppBasketLP(WebDriver driver,String facilityName) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
		try {
			List<WebElement> expCheckBox = driver
					.findElements(By
							.xpath("//a[text()='"+facilityName +"']/../../td/center/input[@class='checkbox']"));
			if (expCheckBox != null) {
				
					if(expCheckBox.size()>1)
					{
						validateAndClick(facilityName, expCheckBox.get(0));
					}
					
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ facilityName);
			e.printStackTrace();
		}

	}
	
	// to get information req details from other security table
			public String checkLinkTextInOtherSectable( String SecurityNum) {
				// label[text()='General Public']/preceding-sibling::div//input
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				String inforeq = null;
				try {
					WebElement checkBoxNo = driver.findElement(By
							.xpath("//div[contains(@data-bindingrt,'local.securityData.otherSecurityDetails["+SecurityNum+"].informationRequired')]//span[@class='text readonly']"));
					if (checkBoxNo != null) {
						  inforeq = checkBoxNo.getText();
						Logger.LogMessage("Link Text---" + inforeq
								+ "----is displayed");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Exception occured while finding checkbox---"
							+ SecurityNum);
					e.printStackTrace();
				}
				return inforeq;
			}
			
	// to get security status based on security id
			public String getSecStatforExisSec(WebDriver driver, int row, String idname) {
				String[] idnamefull = idname.split("-");
				String idvalue = idnamefull[1];
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement status  = driver.findElement(By
							.xpath("//div[@data-binding='local.securityData.existingSecurityDetails[index].securityId']//span[text()='"+idvalue+"']/ancestor::tr//div[@data-binding='local.securityData.existingSecurityDetails[index].securityStatus']//span[@class='text']"));
					
						String statustxt = status.getText();
											
						Logger.LogMessage(status + "text is retrived");
						return statustxt;
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Exception occured while getting text for security status");
					e.printStackTrace();
					return null;
				}
			}
	public void clickLinkFromSideBar(WebDriver driver, String expLinkName) {
		// div[@id='tasklist_sidebar_widget_target']
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement linkToCLick = driver
					.findElement(By
							.xpath("//div[@id='tasklist_sidebar_widget_target']//a[text()='"
									+ expLinkName + "']"));
			if (linkToCLick != null) {
				validateAndClick(expLinkName, linkToCLick);
				/*
				 * Thread.sleep(4); scrollElementToView(driver, linkToCLick);
				 * 
				 * linkToCLick.click();
				 */

				Logger.LogMessage("Clicking on the Link--" + expLinkName);
			} else {
				Logger.LogMessage("Could not cLick on the Link--" + expLinkName);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Could not cLick on the Link--" + expLinkName);
			e.printStackTrace();
		}

	}

	public void scrollElementToView(WebDriver driver, WebElement element) {
		waitForLoadingElementInvisibility(driver);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		try {
			// jsExecutor.executeScript("arguments[0].scrollIntoView(false);",
			// element);
			jsExecutor.executeScript("window.scrollTo("
					+ element.getLocation().x + ","
					+ (element.getLocation().y - 20) + ");");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// to get security status based on security id
		public String getSecStatSecID(WebDriver driver, int row) {
			// label[text()='General Public']/preceding-sibling::div//input
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement id  = driver.findElement(By
						.xpath("//div[@data-bindingrt='local.securityData.newSecurityDetails["+row+"].newOrExisting']//span[@class='text']"));
				
					String idTxt = id.getText();
					
					Logger.LogMessage(id + "text is retrived");
					return idTxt;
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Exception occured while getting text for security ID");
				e.printStackTrace();
				return null;
			}
		}
	
	// for checking security sub type
			public String getSecSubTypeTextInsecsumamryPage( String SecurityNum) {
				// label[text()='General Public']/preceding-sibling::div//input
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				String inforeq = null;
				try {
					WebElement checkBoxNo = driver.findElement(By
							.xpath("//div[contains(@data-bindingrt,'local.securityData.newSecurityDetails["+SecurityNum+"].securitySubtypeSelected')]//span[@class='text']"));
					if (checkBoxNo != null) {
						  inforeq = checkBoxNo.getText();
						Logger.LogMessage("sectype" + inforeq
								+ "----is displayed");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Exception occured while finding checkbox---"
							+ SecurityNum);
					e.printStackTrace();
				}
				return inforeq;
			}
	public String getSecTypeTextInsecsumamryPage( String SecurityNum) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String inforeq = null;
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[contains(@data-bindingrt,'local.securityData.newSecurityDetails["+SecurityNum+"].securityName')]//span[@class='text']"));
			if (checkBoxNo != null) {
				  inforeq = checkBoxNo.getText();
				Logger.LogMessage("sectype" + inforeq
						+ "----is displayed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ SecurityNum);
			e.printStackTrace();
		}
		return inforeq;
	}
	// to get information req details from sec ltv table
	public String checkLinkTextInSecLTVtable( String SecurityNum) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String inforeq = null;
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[contains(@data-bindingrt,'local.securityData.newSecurityDetails["+SecurityNum+"].informationRequired')]//span[@class='text readonly']"));
			if (checkBoxNo != null) {
				  inforeq = checkBoxNo.getText();
				Logger.LogMessage("Link Text---" + inforeq
						+ "----is displayed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ SecurityNum);
			e.printStackTrace();
		}
		return inforeq;
	}
	
	
	
	
	// code to select exisiting security based on security type and sec ID
		public void selectExistingSec(String exissectype, String exissecid) throws Exception {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			

			// find table from RBS
		/*	WebElement expand = driver
					.findElement(By
							.xpath("//div[contains(@data-binding,'local.rmpExistingSecurityDetails[index].securityType')]//span[text()='"+exissectype+"']/ancestor::tr//div[contains(@data-binding,'local.rmpExistingSecurityDetails[index].securityId')]//span[text()='"+exissecid+"']/ancestor::tr//span[contains(@class,'dojoxGridRowSelectorStatusText')]/.."));
		*/	//div[contains(@data-binding,'local.securityData.existingSecurityDetails[index].securityType')]//span[text()='Charge over Life Policy']/ancestor::tr//div[contains(@data-binding,'local.securityData.existingSecurityDetails[index].securityId')]//span[text()='3']/ancestor::tr//span[contains(@class,'dojoxGridRowSelectorStatusText')]/..
			WebElement expand = driver
					.findElement(By
							.xpath("//div[contains(@data-binding,'local.securityData.existingSecurityDetails[index].securityType')]//span[text()='"+exissectype+"']/ancestor::tr//div[contains(@data-binding,'local.securityData.existingSecurityDetails[index].securityId')]//span[text()='"+exissecid+"']/ancestor::tr//span[contains(@class,'dojoxGridRowSelectorStatusText')]/.."));	
			expand.click();
					sleepTime(2);
							
					
				
		
		}

	public void inputInTextBoxLendingRBSTASPage(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='Horizontal_Section  CoachView BPMSection CoachView_show']//span[contains(text(),'"+expLabelName+"')]/ancestor::td/following-sibling::td//div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					//expTextField.sendKeys("Unsure");
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	

	public void inputInTextBoxLendingRBSTASPageCPB(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'LND_URL_CV')]//a[contains(text(),'"+expLabelName+"')]/ancestor::td/following-sibling::td//div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					//expTextField.sendKeys("Unsure");
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	// to select business Approver in Application Summary Screen
		public void updateBusinessPricingApprover(String LabelName, String LabelName2,
				String value, String databind) throws Exception {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			System.out.println("Value" + value);

			// find table from RBS
			//span[contains(@class,'text')][contains(text(),'Business Banking or Regional Director') or contains(text(),'Regional Managing Director') ]/ancestor::div[@data-binding='local.roleOfBusinessApprover']/following-sibling::div[contains(@data-binding,'List[]')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]
			/*WebElement metricvalues = driver
					.findElement(By
							.xpath("//span[contains(@class,'text')][contains(text(),'"+LabelName+"')]/ancestor::div[@data-binding='"+databind+"']/following-sibling::div[contains(@data-binding,'List[]')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
			*/
			WebElement metricvalues = driver
					.findElement(By
							.xpath("//span[contains(@class,'text')][contains(text(),'"+LabelName+"') or contains(text(),'"+LabelName2+"') ]/ancestor::div[@data-binding='"+databind+"']/following-sibling::div[contains(@data-binding,'List[]')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
			if (metricvalues != null) 
			{
				
				
					validateAndSendKeys("Input", metricvalues,
									value);
							
				
						

			} 
		
		}
	
	//to enter RM Justification comments in App Summary screen 
	public void inputInTextAreaLendingRBSInAppSum(WebDriver driver,String spFieldName,String Value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//label[contains(text(),'"+ spFieldName +"')]/../..//textarea"));
			if (expTextBoxFrame != null) {
				
					
					validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
					
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ spFieldName);
			e.printStackTrace();
		}

	}
	
	public void inputInTextBoxLendingRBSTASPageCPBMonitoring(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='BPMSectionInner']//a[contains(text(),'"+ expLabelName +"')]/../../..//div[contains(@class,'dijitInputField dijitInputContainer')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					//expTextField.sendKeys("Unsure");
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	
	public void inputInTextBoxLendingRBSASPageCPB(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='textReadonlyDiv']/span[contains(text(),'"+expLabelName+"')]/..//following::div/div[contains(@id,'FilteringSelect')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[@value='Please select...']"));
				if (expTextField != null) {
					
					expTextField.click();
					expTextField.clear();
					expTextField.sendKeys(value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	public String getInstanceIDInRBS(WebDriver driver) {
		waitForLoadingElementInvisibility(driver);
		String instanceIDRBS = null;
		try {
			WebElement instanceID = driver
					.findElement(By
							.xpath("//div[contains(text(),'Process lending application')]"));
			if (instanceID != null) {
				instanceIDRBS = instanceID.getText();

				instanceIDRBS = instanceIDRBS.replaceAll("[^0-9]+", "").trim();

				Logger.LogMessage("Process ID fetched successfully--"
						+ instanceIDRBS);
			} else {
				Logger.LogMessage("Could not fetch Process ID--");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Could not fetch Process ID--");
			e.printStackTrace();
		}

		return instanceIDRBS;
	}

	
	public String getTasInRBS(WebDriver driver) {
		waitForLoadingElementInvisibility(driver);
		String TasIDRBS = null;
		try {
			WebElement TasID = driver
					.findElement(By
							.xpath("//div[@class='myLink']/a"));
			if (TasID != null) {
				TasIDRBS = TasID.getText();

				

				Logger.LogMessage("Process ID fetched successfully--"
						+ TasIDRBS);
			} else {
				Logger.LogMessage("Could not fetch Process ID--");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Could not fetch Process ID--");
			e.printStackTrace();
		}

		return TasIDRBS;
	}

	public void lendinginputInTextBoxRBS(WebDriver driver, String expLabelName,
			String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			/*WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));*/
			
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='textLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@class,'dijitTextBox')]/div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					/*validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();*/
					 expTextField.click(); 
					 expTextField.clear();
					 expTextField.sendKeys(value);
					 expTextField.sendKeys(Keys.TAB);
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	//to enter value in text box in security input screen (description/Comments)
	
	public void inputInTextAreaLendingRBSInsecinputPage(WebDriver driver,String commentFieldName,String Value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//label[contains(text(),'"+commentFieldName+"')]/../..//textarea"));
			if (expTextBoxFrame != null) {
				
					
					validateAndSendKeys(commentFieldName,expTextBoxFrame,Value);
					
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ commentFieldName);
			e.printStackTrace();
		}

	}


	//to enter security provider comments in security inputs screen 
			public void inputInTextAreaLendingRBSInSecInput(WebDriver driver,String spFieldName,String Value) {
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
			
				try {
					List<WebElement> expTextBoxFrame = driver
							.findElements(By
									.xpath("//label[contains(text(),'"+ spFieldName +"')]/../..//textarea"));
					if (expTextBoxFrame != null) {
						
							if(expTextBoxFrame.size()>1)
							{
							validateAndSendKeys(spFieldName,expTextBoxFrame.get(1),Value);
							}
							
							waitForLoading();
							Logger.LogMessage("Input in text box---successfull");
						}
						
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ spFieldName);
					e.printStackTrace();
				}

			}
			
			public void lendinginputInTextBoxRBSGV(WebDriver driver, String expLabelName,
					String value) {
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				
				try {
				
					WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//div[@class='textLabel']/label[contains(text(),'"
											+ expLabelName
											+ "')]/..//following-sibling::div/div[contains(@class,'dijitTextBox')]/div[contains(@class,'dijitInputField')]"));
					if (expTextBoxFrame != null) {
						WebElement expTextField = expTextBoxFrame.findElement(By
								.xpath(".//input[not(@type='hidden')]"));
						if (expTextField != null) {
							expTextField.click();
							expTextField.clear();
							expTextField.sendKeys(value);
							waitForLoading();
							Logger.LogMessage("Input in text box---successfull");
						}
						// div[text()='Yes']/preceding-sibling::div/input
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ expLabelName);
					e.printStackTrace();
				}

			}
			
	// text box entry for connection direct limit
	
	public void lendinginputInTextBoxRBSCPB(WebDriver driver, String expLabelName,
			String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			/*WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));*/
			
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='textLabel']/label[contains(text(),'"+expLabelName+"')]/..//following-sibling::div/div[contains(@class,'dijitTextBox')]/div[contains(@class,'dijitInputField')]//input[@id='uniqName_1_7'][not(@type='hidden')]"));
			
					
					validateAndSendKeys(expLabelName, expTextBoxFrame, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				
				// div[text()='Yes']/preceding-sibling::div/input
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	
	// Combobox in lending Application
	public void inputInTextBoxRBS(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...'][not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	
	// to enter values in Input MGS
	
	public void inputInTextBoxRBSCPBInputMGS(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try {
			List<WebElement> inputvalues = driver
					.findElements(By
							.xpath("//div[@class='selectLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div/div[contains(@id,'FilteringSelect')]//div[contains(@class,'dijitInputField')]//input[@value='Please select...'][not(@type='hidden')]"));
			if (inputvalues != null) {
				
				if (inputvalues.size() >1) 
				{	
					validateAndSendKeys("Input", inputvalues.get(1),
									value);
						
				
			}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	// for cpb transaction details page
	
	public void inputInTextBoxRBSCPB(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"+expLabelName+"')]/../..//div[@class='dijitReset dijitInputField dijitInputContainer']/input[not(@type='hidden')]"));
			
						
					validateAndSendKeys(expLabelName, expTextBoxFrame, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}
	}
	
	public void lendingHyperLinkLabelInputInTextBoxWithSelect(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='myLink']//a[text()='"+expLabelName+"']/../../following-sibling::div//div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[@value='Please select...']"));
				if (expTextField != null) {
					
					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	
	public void inputInTextBoxRBSNotSelect(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expTextField = driver
					.findElement(By
							.xpath("//div[@class='textLabel']/label[contains(text(),'"+expLabelName+"')]/..//following-sibling::div/div[contains(@class,'TextBox')]/div[contains(@class,'InputField')]/Input"));
			
			
			
					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}


	public void inputInTextBoxNotSelect(WebDriver driver, String expLabelName,
			String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]/div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {
					expTextField.click();
					expTextField.clear();
					expTextField.sendKeys(value);
					 expTextField.sendKeys(Keys.TAB);
					//validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}
	}
	
	public void inputInDateFinderLending(WebDriver driver, String expLabelName,
			String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			/*WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]/div[contains(@class,'dijitInputField')]"));
			*/
			
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'Output_Text')]//label[contains(text(),'"
									+ expLabelName
									+ "')]/../../following-sibling::div//div[contains(@class,'dijitInputField')]"));
			
			
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {

					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}
	}

	public void inputInTextBoxNotSelect(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility();
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]/div[contains(@class,'dijitInputField')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[not(@type='hidden')]"));
				if (expTextField != null) {

					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}
	}

	public void inputInTextBoxRBSContains(WebDriver driver,
			String expLabelName, String value) {
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[@value='Please select...']"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}

	public void inputInTextBoxRBSContains(String expLabelName, String value) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//input[@value='Please select...']"));
				if (expTextField != null) {

					validateAndSendKeys(expLabelName, expTextField, value);
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	// div[contains(@class,'textLabel')]/label[text()='Business/ Organisation
	// name']/..//following-sibling::div//div[contains(@id,'ComboBox')]

	public void inputInComboBoxRBS(WebDriver driver, String expLabelName,
			String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'ComboBox')]"));
				waitForLoading();
				expTextBox.clear();
				expTextBox.click();
				expTextBox.sendKeys(value);
				// waitForLoading();
				// validateAndSendKeys("Trading description", expTextBox,
				// value);
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public void inputInComboBoxRBSNotIfMatch(WebDriver driver,
			String expLabelName, String value, String expMatch) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'ComboBox')]"));
				String expAttribute = null;
				try {

					expAttribute = expTextBox.getAttribute("value");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (!(expAttribute == null)) {
					if (!expAttribute.equalsIgnoreCase(expMatch)) {
						waitForLoading();
						expTextBox.clear();
						expTextBox.click();
						expTextBox.sendKeys(value);
						// waitForLoading();
						// validateAndSendKeys("Trading description",
						// expTextBox,
						// value);
						// validateAndSendKeys(expLabelName, expComboBoxFrame,
						// value);
						Logger.LogMessage("Input in text box---successfull");
					}
				} else {
					waitForLoading();
					expTextBox.clear();
					expTextBox.click();
					expTextBox.sendKeys(value);
					// waitForLoading();
					// validateAndSendKeys("Trading description", expTextBox,
					// value);
					// validateAndSendKeys(expLabelName, expComboBoxFrame,
					// value);
					Logger.LogMessage("Input in text box---successfull");
				}

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public void inputInComboBoxRBS(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		System.out.println(expLabelName);
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'ComboBox')]"));
				waitForLoading();
				expTextBox.clear();
				expTextBox.click();
				expTextBox.sendKeys(value);
				// waitForLoading();
				// validateAndSendKeys("Trading description", expTextBox,
				// value);
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public void inputInUniqueNameTextBoxRBS(WebDriver driver,
			String expLabelName, String value) {
		// /..//following-sibling::div//input[contains(@id,'uniqName')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expComboBoxFrame = driver.findElement(By
					.xpath("//div[contains(@class,'textLabel')]/label[text()='"
							+ expLabelName + "']/..//following-sibling::div"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'uniqName')]"));
				waitForLoading();
				expTextBox.clear();
				expTextBox.click();
				expTextBox.sendKeys(value);
				// waitForLoading();
				// validateAndSendKeys("Trading description", expTextBox,
				// value);
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}
	}

	public void inputInUniqueNameTextBoxRBSContains(WebDriver driver,
			String expLabelName, String value) {
		// /..//following-sibling::div//input[contains(@id,'uniqName')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'uniqName')]"));
				waitForLoading();
				expTextBox.clear();
				expTextBox.click();
				expTextBox.sendKeys(value);
				// waitForLoading();
				// validateAndSendKeys("Trading description", expTextBox,
				// value);
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}
	}

	public void inputInUniqueNameTextBoxRBSContains(String expLabelName,
			String value) {
		// /..//following-sibling::div//input[contains(@id,'uniqName')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'uniqName')]"));
				waitForLoading();
				expTextBox.clear();
				expTextBox.click();
				expTextBox.sendKeys(value);
				// waitForLoading();
				// validateAndSendKeys("Trading description", expTextBox,
				// value);
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}
	}

	public void inputInComboBoxRBSContains(WebDriver driver,
			String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'ComboBox')]"));
				expTextBox.clear();
				expTextBox.sendKeys(value);
				waitForLoading();
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public void inputInComboBoxRBSContains(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'ComboBox')]"));
				expTextBox.clear();
				expTextBox.sendKeys(value);
				waitForLoading();
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public void inputIntextAreaInRBS(String expLabelName, String value) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTextFrame = driver.findElement(By
					.xpath("//label[contains(text(),'" + expLabelName
							+ "')]/../following-sibling::textarea"));

			if (expTextFrame != null) {

				expTextFrame.sendKeys(value);

				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}
	}

	// text area CPB cust info
	
	public void inputIntextAreaInRBSCPB(String expLabelName, String value) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTextFrame = driver.findElement(By
					.xpath("//label[contains(text(),'"+expLabelName+"')]/../../textarea[@id='dijit_form_Textarea_2']"));

			if (expTextFrame != null) {

				expTextFrame.sendKeys(value);

				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}
	}
	
	public void inputCurrentDatesInRBSByLabelName(WebDriver driver,
			String explabelName, String dateInMMDDYYY) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]
		String expDate[] = dateInMMDDYYY.split(" ");
		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ explabelName
									+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"));
			for (WebElement nav : allDateTextBoxes) {
				validateAndSendKeys("Day", nav, expDate[counter]);

				counter++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//to enter value in text box in property value screen (description/Comments)
	
		public void inputInTextBoxLendingRBSInPropetyValuePage(WebDriver driver,String commentFieldName,String Value) {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
		
			try {
				WebElement expTextBoxFrame = driver
						.findElement(By
								.xpath("//label[contains(text(),'"+ commentFieldName +"')]/../../following-sibling::div//textarea"));
				if (expTextBoxFrame != null) {
					
					expTextBoxFrame.clear();
					expTextBoxFrame.click();
					expTextBoxFrame.sendKeys(Value);
						//validateAndSendKeys(commentFieldName,expTextBoxFrame,Value);
						
						waitForLoading();
						Logger.LogMessage("Input in text box---successfull");
					}
					
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("exception occured while entering value in---"
						+ commentFieldName);
				e.printStackTrace();
			}

		}
		
		//to enter value in property value screen (security Provider)
		
		public void inputInTextBoxLendingRBSInPropetyValuePageSP(WebDriver driver,String spFieldName,String Value) {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
		
			try {
				WebElement expTextBoxFrame = driver
						.findElement(By
								.xpath("//label[contains(text(),'"+ spFieldName +"')]/../..//textarea"));
				if (expTextBoxFrame != null) {
					
						
						validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
						
						waitForLoading();
						Logger.LogMessage("Input in text box---successfull");
					}
					
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("exception occured while entering value in---"
						+ spFieldName);
				e.printStackTrace();
			}

		}

		// To enter Basic of Valuation values in PropertyValue Screen
		public void inputInTextBoxLendingRBSInPropetyValueScreen(String ValuationBasisName, String value) {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
		
			try {
				WebElement expTextBoxFrame = driver
						.findElement(By
								.xpath("//div[@class='Horizontal_Section  CoachView BPMSection BPMHSectionChild CoachView_show']//span[text()='"+ValuationBasisName+"']/../../../../following-sibling::div[@class='Decimal reduceDecimalWidth reduceWidth300 CoachView BPMHSectionChild CoachView_show']"));
				if (expTextBoxFrame != null) {
					WebElement expTextField = expTextBoxFrame.findElement(By
							.xpath(".//input[@class='dijitReset dijitInputInner']"));
					if (expTextField != null) {
						
						//validateAndSendKeys(ValuationBasisName, expTextField, value);
						expTextField.click();
						expTextField.clear();
						expTextField.sendKeys(value);
						
						waitForLoading();
						Logger.LogMessage("Input in text box---successfull");
					}
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("exception occured while entering value in---"
						+ ValuationBasisName);
				e.printStackTrace();
			}

		}
		
		public void inputInComboBoxRBSPV(WebDriver driver, String expLabelName,
				String value, int fieldnum ) {
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			
			try {
				List<WebElement> expComboBoxFrame = driver
						.findElements(By
								.xpath("//div[contains(@class,'textLabel')]/label[text()='"
										+ expLabelName
										+ "']/..//following-sibling::div//div[contains(@id,'ComboBox')]//input[contains(@id,'ComboBox')]"));
				if (expComboBoxFrame != null) {

					
					expComboBoxFrame.get(fieldnum-1).clear();
					expComboBoxFrame.get(fieldnum-1).click();
					expComboBoxFrame.get(fieldnum-1).sendKeys(value);
					Logger.LogMessage("Input in text box---successfull");

					
				}
			} catch (Exception e) {
				
				Logger.LogMessage("Input in text box---Not Successfull");
				e.printStackTrace();
			}

		}
		//to click on the check box with ref to CIN number in property value screen
		

		public void selectCheckBoxByTextInPropertyPage(WebDriver driver, String expCheckBoxText) {
			// label[text()='General Public']/preceding-sibling::div//input
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expCHeckBox = driver.findElement(By
						.xpath("//div[@class='Table_HT  CoachView BPMTable BPMHSectionChild CoachView_show']//div[contains(@data-binding,'CIN')]//span[contains(text(),'"+expCheckBoxText+"')]/../../..//div[contains(@class,'dijitCheckBox')]"));
				if (expCHeckBox != null) {
					expCHeckBox.click();
					// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
					Logger.LogMessage("Check Box---whose CIN value is" + expCheckBoxText
							+ "----has been clicked");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Exception occured while finding checkbox---"
						+ expCheckBoxText);
				e.printStackTrace();
			}
		}

		// to select checkbox under faclity table
		
		public void selectCheckBoxByTextInSecurityAllocation(WebDriver driver, String expCheckBoxText) {
			// label[text()='General Public']/preceding-sibling::div//input
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expCHeckBox = driver.findElement(By
						.xpath("//div[@class='ContentBox BPMSectionBody LastContentBox']//table[@class='facTable']//td[contains(text(),'"+expCheckBoxText+"')]/..//input[@type='checkbox']"));
				if (expCHeckBox != null) {
					expCHeckBox.click();
					// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
					Logger.LogMessage("Check Box---whose Facility Value  is" + expCheckBoxText
							+ "----has been clicked");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Exception occured while finding checkbox---"
						+ expCheckBoxText);
				e.printStackTrace();
			}
		}
		
		
		//to select checkbox under security table
		
				public void selectCheckBoxByTextInSecurityAllocationST(WebDriver driver, String sectype, String secname) {
					// label[text()='General Public']/preceding-sibling::div//input
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						WebElement expCHeckBox = driver.findElement(By
								.xpath("//div[@class='ContentBox BPMSectionBody LastContentBox']//table[@class='secTable']//td[contains(text(),'"+sectype+"') and contains(.,'"+secname+"')]/..//input[@type='checkbox']"));
						if (expCHeckBox != null) {
							expCHeckBox.click();
							// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
							Logger.LogMessage("Check Box---whose Security Value  is" + secname
									+ "----has been clicked");
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Exception occured while finding checkbox---"
								+ secname);
						e.printStackTrace();
					}
				}
				
		
		//to select checkbox under security table
		
		public void selectCheckBoxByTextInSecurityAllocationST(WebDriver driver, String expCheckBoxText) {
			// label[text()='General Public']/preceding-sibling::div//input
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expCHeckBox = driver.findElement(By
						.xpath("//div[@class='ContentBox BPMSectionBody LastContentBox']//table[@class='secTable']//td[contains(.,'"+expCheckBoxText+"')]/..//input[@type='checkbox']"));
				if (expCHeckBox != null) {
					expCHeckBox.click();
					// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
					Logger.LogMessage("Check Box---whose Security Value  is" + expCheckBoxText
							+ "----has been clicked");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Exception occured while finding checkbox---"
						+ expCheckBoxText);
				e.printStackTrace();
			}
		}
		
		// to select the checkbox in ApplicationSummary page.
		
		public void selectCheckBoxInApplicationSummaryPage(WebDriver driver, int value) {
			// label[text()='General Public']/preceding-sibling::div//input
			waitForLoading();
			waitForLoadingElementInvisibility(driver);
			try {
				WebElement expCHeckBox = driver.findElement(By
						.xpath("//div[contains(@class,'CheckboxNoWrap')]//div[contains(@widgetid,'dijit_form_CheckBox_"+value+"')]//input[(@class='dijitReset dijitCheckBoxInput')]"));
				if (expCHeckBox != null) {
					//expCHeckBox.click();
					// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
					JavascriptExecutor executor = (JavascriptExecutor)driver;
					executor.executeScript("arguments[0].click();",expCHeckBox);
					Logger.LogMessage("Check Box---whose checkbox value is" + value
							+ "----has been clicked");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Exception occured while finding checkbox---"
						+ value);
				e.printStackTrace();
			}
		}
		
		
		// for javascriptexecutorcode
		public void javascriptexecutorcode(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//h2[contains(@class,'BPMSectionHeader box blue')][text()='"+LabelName+"']"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		
		// for javascriptexecutorcodeCS
		public void javascriptexecutorcodelabelnameCS(String LabelName)  {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'LastContentBox noHeader')]/p[text()='"+LabelName+"']"));
			
			jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
			jse.executeScript("window.scrollBy(0,-100)","");
			sleepTime(2);
			ReporterA.reportPassWithSnapshot(LabelName
					+ " validate if present ", LabelName
					+ "should be displayed", LabelName
					+ "is displayed", driver);
		
		}
		
		
	public void inputCurrentDatesInRBSByLabelNameComma(WebDriver driver,
			String explabelName, String dateInMMDDYYY) {
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String expDate[] = dateInMMDDYYY.split("/");
		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ explabelName
									+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"));

			for (WebElement nav : allDateTextBoxes) {
				waitForLoadingElementInvisibility(driver);
				validateAndSendKeys("Day", nav, expDate[counter]);

				counter++;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void inputCurrentDatesInRBSByLabelNameCommaETB(WebDriver driver,
			String explabelName, String dateInMMDDYYY) {
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String expDate[] = dateInMMDDYYY.split("/");
		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = findObjectList(
					By.xpath("//div[contains(@class,'textLabel')]/label[text()='"
							+ explabelName
							+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"),
					"Date Field");
			if (allDateTextBoxes.size() < 3) {
				for (int i = 0; i < 3; i++) {

					validateAndSendKeys("Day", allDateTextBoxes.get(i),
							expDate[counter]);

					counter++;
				}
			} else {
				for (int i = 3; i < 6; i++) {
					validateAndSendKeys("Day", allDateTextBoxes.get(i),
							expDate[counter]);

					counter++;
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void inputCurrentDatesInRBSByLabelNameComma(String explabelName,
			String dateInMMDDYYY) {
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String expDate[] = dateInMMDDYYY.split("/");
		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ explabelName
									+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"));
			for (WebElement nav : allDateTextBoxes) {
				validateAndSendKeys("Day", nav, expDate[counter]);

				counter++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	public String getFutureDateByYearInDDMMYYY(int years) {

		// waitForLoading();
		// waitForLoadingElementInvisibility(driver);
		try {
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.set(Calendar.DAY_OF_WEEK_IN_MONTH, Calendar.MONDAY);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY");
			System.out.println("current instance---"
					+ formatter.format(c.getTime()));
			c.add(Calendar.YEAR, years);

			System.out.println(formatter.format(c.getTime()));

			String expDate = formatter.format(c.getTime());
			return expDate;
		} catch (Exception e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
			return null;
		}

	}

	public String getFutureDateByMonthInDDMMYYY(int months) {

		// waitForLoading();
		// waitForLoadingElementInvisibility(driver);
		try {
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.set(Calendar.DAY_OF_WEEK_IN_MONTH, Calendar.MONDAY);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY",
					Locale.UK);
			System.out.println("current instance---"
					+ formatter.format(c.getTime()));
			c.add(Calendar.MONTH, months);

			System.out.println(formatter.format(c.getTime()));

			String expDate = formatter.format(c.getTime());
			return expDate;
		} catch (Exception e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
			return null;
		}

	}

	public String getPastDateByYearInDDMMYYY(int years) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY",
					Locale.UK);
			System.out.println("current instance---"
					+ formatter.format(c.getTime()));
			c.add(Calendar.YEAR, -years);

			System.out.println(formatter.format(c.getTime()));

			String expDate = formatter.format(c.getTime());
			return expDate;
		} catch (Exception e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
			return null;
		}

	}

	public void sleepTime(int seconds) {
		waitForLoadingElementInvisibility(driver);
		int sleepTime = seconds * 1000;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			Thread.sleep(sleepTime);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			e.printStackTrace();
		}
	}
	
	
	public String getappIdAsstJourneyCD() {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String textval = null;
		try {
			WebElement expButtonToClick = driver.findElement(
					By.xpath("//p[contains(@class,'DetailsReview_referenceID')]"));
			if (expButtonToClick != null) {
				textval=expButtonToClick.getText();
				ReporterA.reportPassWithSnapshot("IneligHeader"
						+ " validate if present ", "IneligHeader"
						+ "should be displayed", "IneligHeader"
						+ "is displayed", driver);
									Logger.LogMessage("Button has been clicked---" + "IneligHeader");
			
			}
			return textval;
		} catch (Exception e) {
			
			Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
			e.printStackTrace();
			return null;
		}

	}


	public void clickAnybuttonInRBS(String buttonText) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//button[text()='" + buttonText + "']"),
					buttonText);
			if (expButtonToClick != null) {
				expButtonToClick.click();
				ReporterA.reportPassWithSnapshot(buttonText
						+ " validate if present ", buttonText
						+ "should be displayed", buttonText
						+ "is displayed", driver);
				//validateAndClick(buttonText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}

	}
	
	public void changeExceptionValueMarginFeeLoan(WebDriver driver,
			 String value, String datbindname) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> excep = driver
					.findElements(By
							.xpath("//div[contains(@data-binding,'"+datbindname+"')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
			
			excep.get(0).clear();
			excep.get(0).click();
			excep.get(0).sendKeys(value);
			
			ReporterA.reportPassWithSnapshot("Exception input"
					+ " validate if present ", "Exception input"
					+ "should be displayed", "Exception input"
					+ "is displayed", driver);
					
					
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	public void updateTAS (String columnName,
			 int tablenumber,int fieldNumber, String Classname, String value) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);
		
		List<WebElement> Tables = driver
				.findElements(By
						.xpath("//table[@class='dojoxGridRowTable']"));
		if(Tables.size()>1)
		{
			WebElement tabnum = Tables.get(tablenumber);
			
			List<WebElement>  fieldupdate = tabnum.findElements(By.xpath(".//div[contains(@class,'"+Classname+"')]//div[contains(@class,'dijitInputField')]//input[not(contains(@type,'hidden'))]"));
			if(fieldupdate.size()>1)
			{
				validateAndSendKeys(columnName, fieldupdate.get(fieldNumber-1),
						value);
			}
			else if(fieldupdate.size()==1)
			{
				validateAndSendKeys(columnName, fieldupdate.get(0),
						value);
			}
		}
	}
	
	public void clickbuttonInSecurityScreen(String buttonText, String SecurityType) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//div[@class='Vertical_Section  CoachView BPMSection CoachView_show']//h2[text()='"+ SecurityType +"']/../..//button[text()='" + buttonText + "']"),
					buttonText);
			
			if (expButtonToClick != null) {
				expButtonToClick.click();
				//validateAndClick(buttonText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}

	}
	
	public void selectCheckBoxSelectScenario(WebDriver driver, int checkBoxNumber) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[contains(@class,'dijitCheckBox')]//input[contains(@id,'dijit_form_CheckBox_" +checkBoxNumber+"')]"));
			if (checkBoxNo != null) {
				checkBoxNo.click();
				// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
				Logger.LogMessage("Check Box---" + checkBoxNumber
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ checkBoxNumber);
			e.printStackTrace();
		}
	}

	
	// lambard product select
	
	public void selectCheckBoxLombard(WebDriver driver, String labelname) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[@class='outputTextLabel']/label[text()='"+ labelname +"']/../../following-sibling::div[contains(@data-binding,'local.pricingScenario.isSelected')]//div[contains(@class,'CheckboxNoWrap')]//input[@role='checkbox']"));
			if (checkBoxNo != null) {
				checkBoxNo.click();
				// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
				Logger.LogMessage("Check Box---" + labelname
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ labelname);
			e.printStackTrace();
		}
	}
	
	public void clickLinkTextInSelectScenarioPage(WebDriver driver, int SecurityNum) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement checkBoxNo = driver.findElement(By
					.xpath("//div[@data-bindingrt='local.securityData.newSecurityDetails["+SecurityNum+"].newOrExisting']/span[text()='Edit']"));
			if (checkBoxNo != null) {
				checkBoxNo.click();
				// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
				Logger.LogMessage("Check Box---" + SecurityNum
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ SecurityNum);
			e.printStackTrace();
		}
	}

	public void clickAnybuttonInRBSContains(String buttonText) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//button[contains(text(),'" + buttonText + "')]"),
					buttonText);
			if (expButtonToClick != null) {
				validateAndClick(buttonText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}

	}

	public void clickAnybuttonInRBS(By by, String buttonText) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(by, buttonText);
			if (expButtonToClick != null) {
				validateAndClick(buttonText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}

	}

	public void clickLinkByText(String linkText) throws Exception {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//a[text()='" + linkText + "']"), linkText);
			if (expButtonToClick != null) {
				validateAndClick(linkText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Link has been clicked---" + linkText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Link could not be clicked---" + linkText);
			e.printStackTrace();
		}

	}

	public void clickAnybuttonInRBSWoutValidation(String buttonText)
			throws Exception {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//button[text()='" + buttonText + "']"),
					buttonText);
			if (expButtonToClick != null) {
				expButtonToClick.click();

				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}

	}

	public boolean getResponseCode(String urlString) {
		boolean isValid = false;
		try {
			java.net.URL u = new java.net.URL(urlString);
			HttpURLConnection h = (HttpURLConnection) u.openConnection();
			h.setRequestMethod("GET");
			h.connect();
			System.out.println(h.getResponseCode());
			if (h.getResponseCode() != 404) {
				isValid = true;
			}
		} catch (Exception e) {

		}
		return isValid;
	}

	public void clickAnyCheckBoxInRBS(String labelUniqueKey) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expCheckBoxToClick = findAnyWebElement(
					By.xpath("//div[contains(@class,'checkbox control')]/label[contains(text(),'"
							+ labelUniqueKey
							+ "')]/..//following-sibling::div//input[contains(@id,'CheckBox')]"),
					"CheckBOx");

			if (expCheckBoxToClick != null) {
				// validateAndClick(buttonText, expButtonToClick);
				validateAndClick(labelUniqueKey, expCheckBoxToClick);
				Logger.LogMessage("Checkbox has been clicked---"
						+ labelUniqueKey);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("CheckBox could not be clicked---"
					+ labelUniqueKey);
			e.printStackTrace();
		}

	}
	
	
	public void clickAnyCheckBoxByLabelContainsInRBS(String labelUniqueKey) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expCheckBoxToClick = findAnyWebElement(
					By.xpath("//div[contains(@class,'CheckboxNoWrap')]//label[contains(text(),'"+labelUniqueKey+"')]/..//preceding-sibling::div//input[contains(@id,'CheckBox')]"),
					"CheckBOx");

			if (expCheckBoxToClick != null) {
				// validateAndClick(buttonText, expButtonToClick);
				validateAndClick(labelUniqueKey, expCheckBoxToClick);
				Logger.LogMessage("Checkbox has been clicked---"
						+ labelUniqueKey);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("CheckBox could not be clicked---"
					+ labelUniqueKey);
			e.printStackTrace();
		}

	}

	public void getAnythingFromTableInRBS(int tableNumber, int rowNum,
			int fieldNumber, String operation, String value) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@type='radio']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@value='Please
		// select...']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[contains(@id,'ComboBox')]

		// table always with one row

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//div[last()][@class='BPMBorder']

		// table xpath to get all rows
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][3]/following-sibling::div[1]//div[last()][@class='BPMBorder']/div

		// find table from RBS
		List<WebElement> expTables = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
								+ tableNumber
								+ "]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTables != null) {
			// get the expected row from table
			// WebElement expRow =
			// expTable.findElement(By.xpath("div[last()][contains(@class,'BPMBorder')]/div["+rowNum+"]"));
			// if(expRow!=null){

			if (expTables.size() == 1) {
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
										+ tableNumber
										+ "]/following-sibling::div[1]"));

				if (operation.equalsIgnoreCase("radio")) {
					WebElement radioToClick = expTable
							.findElement(By
									.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[@type='radio']"));
					if (radioToClick != null) {
						validateAndClick("Radio Button", radioToClick);
					} else {
						Logger.LogMessage("Could not click the radio button--"
								+ radioToClick);
					}

				} else if (operation.equalsIgnoreCase("input")) {
					List<WebElement> allInputs = null;
					try {
						allInputs = expTable
								.findElements(By
										.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[@value='Please select...']"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					try {
						if (allInputs.size() > 1) {
							validateAndSendKeys("Input",
									allInputs.get(fieldNumber - 1), value);

						} else {

							validateAndSendKeys("Input", allInputs.get(0),
									value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (operation.equalsIgnoreCase("textbox")) {
					try {
						List<WebElement> allInputs = expTable
								.findElements(By
										.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[contains(@id,'ComboBox')]"));
						if (allInputs.size() > 1) {
							validateAndSendKeys("Input",
									allInputs.get(fieldNumber - 1), value);

						} else {
							validateAndSendKeys("Input", allInputs.get(0),
									value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (operation.equalsIgnoreCase("checkbox")) {

					try {
						List<WebElement> allCheckBoxess = expTable
								.findElements(By
										.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[contains(@id,'CheckBox')]"));
						if (allCheckBoxess.size() > 1) {
							validateAndClick("Input",
									allCheckBoxess.get(fieldNumber - 1));

						} else {
							validateAndClick("Input", allCheckBoxess.get(0));
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				// }
			} else if (expTables.size() > 1) {

				Logger.LogMessage("This page has more than one table at same position---Please check the table on the page");

			}

		} else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}

	
	public void updateLendingTableInRBSWClassName(String scenarioNumber,String classname,
			String value, String Fieldtype) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		// find table from RBS
		List<WebElement> expTables = driver
				.findElements(By
						.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+classname+"')]"));
		if (expTables != null) 
		{
			
			if (expTables.size() == 1) 
			{
				
				if(Fieldtype.equalsIgnoreCase("ComboBox"))
					{
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+classname+"')]"));

				WebElement Inputtoupdate = expTable
							.findElement(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
					
					
					
						
						/*validateAndSendKeys(Fieldtype, Inputtoupdate,
								value);*/
				
				try {

                    //Inputtoupdate.click();

                    // Thread.sleep(100);

                    Inputtoupdate.clear();

                    // Thread.sleep(100);

                    Inputtoupdate.sendKeys(value);

                    Thread.sleep(500);

                    Inputtoupdate.sendKeys(Keys.TAB);

                    ReporterA.reportPassWithSnapshot(

                                  "Enter " + value + " in " + Inputtoupdate+ " text box",

                                  "Value should be entered",

                                  "Value Entered. Current Text ="

                                                + Inputtoupdate.getAttribute("value"), driver);

             } catch (Exception e) {

                    ReporterA.reportFailWithSnapshot("Enter " + value + " in "

                                  + Inputtoupdate + " text box", "Value should be entered",

                                  "Value Entered. Current Text =" + Inputtoupdate

                                                + " Error " + e.getMessage(), driver);

             }


					}
				else if (Fieldtype.equalsIgnoreCase("TextBox"))
				{
					WebElement expTable = driver
							.findElement(By
									.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+classname+"')]"));

					WebElement Inputtoupdate = expTable
								.findElement(By
										.xpath(".//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
						
						
						
							
							/*validateAndSendKeys(Fieldtype, Inputtoupdate,
									value);*/
					try {

                        //Inputtoupdate.click();

                        // Thread.sleep(100);

                        //Inputtoupdate.clear();

                        // Thread.sleep(100);

                        Inputtoupdate.sendKeys(value);

                        Thread.sleep(500);

                        Inputtoupdate.sendKeys(Keys.TAB);

                        ReporterA.reportPassWithSnapshot(

                                      "Enter " + value + " in " + Inputtoupdate+ " text box",

                                      "Value should be entered",

                                      "Value Entered. Current Text ="

                                                    + Inputtoupdate.getAttribute("value"), driver);

                 } catch (Exception e) {

                        ReporterA.reportFailWithSnapshot("Enter " + value + " in "

                                      + Inputtoupdate + " text box", "Value should be entered",

                                      "Value Entered. Current Text =" + Inputtoupdate

                                                    + " Error " + e.getMessage(), driver);

                 }

				}
			}
						
			else if (expTables.size() > 1) {

				Logger.LogMessage("This page has more than one table at same position---Please check the table on the page");

			}

		} 
	
	else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}
	
	public void updateROAMStatus(int scenarioNumber,
			String value) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

						List<WebElement> Inputtoupdate = driver
							.findElements(By
									.xpath("//a[text()='ROAM status']/ancestor::div[@class='Vertical_Section  CoachView BPMSection BPMHSectionChild CoachView_show']/following::div//div[contains(@data-binding,'local.roamStatusList')]//div[contains(@class,'dijitInputField')]/input[@value='Please select...']"));
										
												validateAndSendKeys("Combo Box", Inputtoupdate.get(scenarioNumber-1),
								value);

	}
	
	public void updateLendingMetricsValues(String LabelName,
			String value, int fieldnum) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		// find table from RBS
		List<WebElement> metricvalues = driver
				.findElements(By
						.xpath("//div[contains(@data-binding,'local.sempTASDetails.metricLevelFacility[index].metricParameters[index].parameterNameList[]')][contains(@class,'Select  CoachView CoachView_show')]//span[text()='"+LabelName+"']/ancestor::td/following-sibling::td//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
		if (metricvalues != null) 
		{
			
			if (metricvalues.size() >1) 
			{
				
				metricvalues.get(fieldnum-1).click();
				metricvalues.get(fieldnum-1).clear();
				metricvalues.get(fieldnum-1).sendKeys(value);
				//validateAndSendKeys("Input", metricvalues.get(0),
								//value);
						
			}
					

		} 
	
	}

	
	// code to press on "+" and expand in lending Application
	public void expandInLending(String LabelName) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		
		try
		{
		// find table from RBS
		WebElement expand = driver
				.findElement(By
						.xpath("//h2[contains(@class,'BPMCollapsibleSectionHeader')][contains(text(),'"+LabelName+"')]//span[text()='+']"));
		
				expand.click();
		}
		catch ( Exception e)
		{
			System.out.println(e);
		}
						
			
	
	}
	
	
	public void updateLendingTableInRBSWDataBindingAttribute(String scenarioNumber,String databindingname,
			String value, String Fieldtype) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		// find table from RBS
		List<WebElement> expTables = driver
				.findElements(By
						.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@data-binding,'"+databindingname+"')]"));
		if (expTables != null) 
		{
			
			if (expTables.size() == 1) 
			{
				
				if(Fieldtype.equalsIgnoreCase("ComboBox"))
					{
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@data-binding,'"+databindingname+"')]"));

				WebElement Inputtoupdate = expTable
							.findElement(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
					
					
					
						
						/*validateAndSendKeys(Fieldtype, Inputtoupdate,
								value);*/
				try {

                    //Inputtoupdate.click();

                    // Thread.sleep(100);

                    Inputtoupdate.clear();

                    // Thread.sleep(100);

                    Inputtoupdate.sendKeys(value);

                    Thread.sleep(500);

                    Inputtoupdate.sendKeys(Keys.TAB);

                    ReporterA.reportPassWithSnapshot(

                                  "Enter " + value + " in " + Inputtoupdate+ " text box",

                                  "Value should be entered",

                                  "Value Entered. Current Text ="

                                                + Inputtoupdate.getAttribute("value"), driver);

             } catch (Exception e) {

                    ReporterA.reportFailWithSnapshot("Enter " + value + " in "

                                  + Inputtoupdate + " text box", "Value should be entered",

                                  "Value Entered. Current Text =" + Inputtoupdate

                                                + " Error " + e.getMessage(), driver);

             }


					}
				else if (Fieldtype.equalsIgnoreCase("TextBox"))
				{
					WebElement expTable = driver
							.findElement(By
									.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@data-binding,'"+databindingname+"')]"));

					WebElement Inputtoupdate = expTable
								.findElement(By
										.xpath(".//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
						
						
						
							
							/*validateAndSendKeys(Fieldtype, Inputtoupdate,
									value);*/
					try {

                        //Inputtoupdate.click();

                        // Thread.sleep(100);

                        //Inputtoupdate.clear();

                        // Thread.sleep(100);

                        Inputtoupdate.sendKeys(value);

                        Thread.sleep(500);

                        Inputtoupdate.sendKeys(Keys.TAB);

                        ReporterA.reportPassWithSnapshot(

                                      "Enter " + value + " in " + Inputtoupdate+ " text box",

                                      "Value should be entered",

                                      "Value Entered. Current Text ="

                                                    + Inputtoupdate.getAttribute("value"), driver);

                 } catch (Exception e) {

                        ReporterA.reportFailWithSnapshot("Enter " + value + " in "

                                      + Inputtoupdate + " text box", "Value should be entered",

                                      "Value Entered. Current Text =" + Inputtoupdate

                                                    + " Error " + e.getMessage(), driver);

                 }

				}
			}
						
			else if (expTables.size() > 1) {

				Logger.LogMessage("This page has more than one table at same position---Please check the table on the page");

			}

		} 
	
	else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}
	
	
	public void updateLendingTableInRBSWClassDataBindingAttribute(String scenarioNumber,String databindingname,String ClassName,
			String value, String Fieldtype) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

	
				
				if(Fieldtype.equalsIgnoreCase("ComboBox"))
					{
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+ClassName+"')][contains(@data-binding,'"+databindingname+"')]"));

				WebElement Inputtoupdate = expTable
							.findElement(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
					
					
					
						
						validateAndSendKeys(Fieldtype, Inputtoupdate,
								value);
					}
				else if (Fieldtype.equalsIgnoreCase("TextBox"))
				{
					WebElement expTable = driver
							.findElement(By
									.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+ClassName+"')][contains(@data-binding,'"+databindingname+"')]"));

					WebElement Inputtoupdate = expTable
								.findElement(By
										.xpath(".//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
						
						
						
							
							validateAndSendKeys(Fieldtype, Inputtoupdate,
									value);
							
						
				}
				

	}
	
	// for entering value in exception
	
	public void changeExceptionValueMarginFeeLoan(WebDriver driver,
			int fieldnum, String value, String datbindname) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> excep = driver
					.findElements(By
							.xpath("//div[contains(@data-binding,'"+datbindname+"')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
			
			excep.get(0).clear();
			excep.get(0).click();
			excep.get(0).sendKeys(value);
			
			ReporterA.reportPassWithSnapshot("Exception input"
					+ " validate if present ", "Exception input"
					+ "should be displayed", "Exception input"
					+ "is displayed", driver);
					
					
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	
	public void changeExceptionValueMarginFee(WebDriver driver,
			int fieldnum, String value) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> excep = driver
					.findElements(By
							.xpath("//div[contains(@data-binding,'OverdraftReturnsCalc.final')]//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
			
			excep.get(fieldnum-1).clear();
			excep.get(fieldnum-1).click();
			excep.get(fieldnum-1).sendKeys(value);
			
			ReporterA.reportPassWithSnapshot("Exception input"
					+ " validate if present ", "Exception input"
					+ "should be displayed", "Exception input"
					+ "is displayed", driver);
					
					
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	// Overdraft CPB
	
	public void updateLendingTableInRBSWDataBindingAttributeOverdraft(String scenarioNumber,String databindingname,
			String value, String Fieldtype) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

	
				
				if(Fieldtype.equalsIgnoreCase("ComboBox"))
					{
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@class,'Vertical_Section featureHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/../..//div[contains(@data-binding,'"+databindingname+"')]"));

				WebElement Inputtoupdate = expTable
							.findElement(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
					
					
					
						
						validateAndSendKeys(Fieldtype, Inputtoupdate,
								value);
					}
				else if (Fieldtype.equalsIgnoreCase("TextBox"))
				{
					WebElement expTable = driver
							.findElement(By
									.xpath("//div[contains(@class,'Vertical_Section featureHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/../..//div[contains(@data-binding,'"+databindingname+"')]"));

					WebElement Inputtoupdate = expTable
								.findElement(By
										.xpath(".//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
						
						
						
							
							validateAndSendKeys(Fieldtype, Inputtoupdate,
									value);
							
						
				}
				

	}
	
	public void updateLendingTableInRBSWClassDataBindingAttributeINCPB(String scenarioNumber,String databindingname,String ClassName,
			String value, String Fieldtype) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		
				
				if(Fieldtype.equalsIgnoreCase("ComboBox"))
					{
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+ClassName+"')][contains(@data-binding,'"+databindingname+"')]"));

				WebElement Inputtoupdate = expTable
							.findElement(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[@value='Please select...']"));
					
					
				Inputtoupdate.click();
				Inputtoupdate.sendKeys(value);
						
						//validateAndSendKeys(Fieldtype, Inputtoupdate,value);
					}
				else if (Fieldtype.equalsIgnoreCase("TextBox"))
				{
											
							WebElement expTable = driver
									.findElement(By
											.xpath("//div[contains(@class,'Vertical_Section secHeight CoachView BPMSection BPMHSectionChild CoachView_show')]//h2[contains(text(),'"+scenarioNumber+"')]/..//div[contains(@class,'"+ClassName+"')][contains(@data-binding,'"+databindingname+"')]"));

							List<WebElement> Inputtoupdate = expTable
										.findElements(By
												.xpath(".//div[contains(@class,'dijitInputField')]//input[not(@type='hidden')]"));
								
								
									validateAndSendKeys(Fieldtype, Inputtoupdate.get(0),
											value);
				}
			

	}
	
	public void getAnythingFromLendingTableInRBS(String columnName,int tablenumber,
			int fieldNumber, String operation, String value) throws Exception {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		System.out.println("Value" + value);

		// find table from RBS
		List<WebElement> expTables = driver
				.findElements(By
						.xpath("//div[contains(@widgetid,'dojox_grid_EnhancedGrid_"+tablenumber+"')]"));
		if (expTables != null) {
			
			if (expTables.size() == 1) {
				WebElement expTable = driver
						.findElement(By
								.xpath("//div[contains(@widgetid,'dojox_grid_EnhancedGrid_"+tablenumber+"')]"));

				List<WebElement> Inputtoupdate = expTable
							.findElements(By
									.xpath(".//div[contains(@class,'dijitInputField')]//input[not(contains(@type,'hidden'))]"));
					
					
					if (Inputtoupdate.size() > 1) {
						/*validateAndSendKeys(operation,
								Inputtoupdate.get(fieldNumber - 1), value);*/
						try {

                            Inputtoupdate.get(fieldNumber - 1).click();

                            // Thread.sleep(100);

                            Inputtoupdate.get(fieldNumber - 1).clear();

                            // Thread.sleep(100);

                            Inputtoupdate.get(fieldNumber - 1).sendKeys(value);

                            Thread.sleep(500);

                            Inputtoupdate.get(fieldNumber - 1).sendKeys(Keys.TAB);

                            

                     } catch (Exception e) {

                            ReporterA.reportFailWithSnapshot("Enter " + value + " in "

                                          + Inputtoupdate.get(fieldNumber - 1) + " text box", "Value should be entered",

                                          "Value Entered. Current Text =" + Inputtoupdate.get(fieldNumber - 1)

                                                       + " Error " + e.getMessage(), driver);

                     }


					} else {
						validateAndSendKeys(operation, Inputtoupdate.get(0),
								value);
					}

						
			} else if (expTables.size() > 1) {

				Logger.LogMessage("This page has more than one table at same position---Please check the table on the page");

			}

		} else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}

	public void getAllRowsFromTableByColName(String expColname,
			String xpathKey, String matcherRow, String operation,
			String valuesToSelectOrSend) throws Exception {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show']//span[text()='Full
		// Name']/../../../../following-sibling::div
		// WebElement mainTable =
		// driver.findElement(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']//span[text()='"+expColname+"']/../../../../following-sibling::div"));
		WebElement mainTable = findAnyWebElement(
				By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']//span[text()='"
						+ expColname + "']/../../../../following-sibling::div"),
				"Main Table");

		// iterate namewise from excel--main loop
		String vals[] = null;
		String valsToSelect[] = null;
		int counter = 1;

		if (matcherRow.contains(",")) {
			vals = matcherRow.split(",");
			counter = vals.length;
			// just for printing
			for (String j : vals) {
				System.out.println("Expected text from excel---" + j);
			}
		}

		if (valuesToSelectOrSend.contains(",")
				&& !valuesToSelectOrSend.equalsIgnoreCase("")) {
			valsToSelect = valuesToSelectOrSend.split(",");
			counter = valsToSelect.length;
			// just for printing
			for (String j : valsToSelect) {
				System.out.println("Expected text from excel---" + j);
			}
		}

		// Get expected row

		int expRow = 0;
		// boolean found = false;
		int valueCounter = 0;
		// total rows inside the table
		if (mainTable != null) {
			List<WebElement> allRows = mainTable.findElements(By
					.xpath("div/div"));
			Logger.LogMessage("Total Rows inside the main table---"
					+ (allRows.size() - 1));
			// return allRows;

			// new logic
			// find the row in which the element is located
			for (WebElement wEle2 : allRows) {

				List<WebElement> allSpans = wEle2.findElements(By
						.tagName("span"));
				for (WebElement wEle1 : allSpans) {
					System.out.println("Eleemnt text--" + wEle1.getText());

					for (int k = 0; k <= counter - 1; k++) {
						System.out.println("iterating the values from excel--"
								+ k);
						if (wEle1.getText().trim()
								.equalsIgnoreCase(vals[k].trim())) {

							// found=true;
							valueCounter++;
							expRow++;

							if (operation.equalsIgnoreCase("click")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);
								wEle.click();
							} else if (operation.equalsIgnoreCase("select")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								Select sel = new Select(wEle);
								sel.selectByValue(valsToSelect[k].trim());
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);

							} else if (operation.equalsIgnoreCase("sendkeys")) {
								WebElement wEle = mainTable.findElement(By
										.xpath("div/div[" + expRow + "]"
												+ xpathKey));
								validateAndSendKeys("Select Group", wEle,
										valsToSelect[k].trim());
								// wEle.sendKeys(valsToSelect[k].trim());
								System.out.println("div/div[" + expRow + "]"
										+ xpathKey);
							}
							// select logic

						}

					}
				}
				// i++;
				if (valueCounter == counter) {
					break;
				}
			}

			// click anything inside expected row

			// wEle.findElement(by).click();

		} else {
			System.out.println("null");
		}

	}

	public WebElement findAnyWebElement(By by, String eleName) {
		WebElement eLe = null;
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			eLe = driver.findElement(by);
			Logger.LogMessage("Finding Element---Success---" + eleName);
			return eLe;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Finding Element---Not Success---try Again--Proceeding further"
					+ eleName);
			e.printStackTrace();
			return null;
		}

	}

	public void selectAnyRadioButtonInRBSByLabelName(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"
								+ expRadioButton
								+ "']/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					// expYesOrNoButton.click();
					validateAndClick(expRadioButton + " Button",
							expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// select tab in customer summary page (Overdraft,Trade finance)
	
	public void selectTabInCustomerSummaryByLabelName(WebDriver driver,
			String expLabelName) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement value = driver
					.findElement(By
							.xpath("//div[contains(@class,'LND_Template_CV')]//div[contains(@class,'LND_TabLinkGroup_CV ')]/span[text()='"+expLabelName+"']"));
			
					//validateAndClick(expLabelName,value);
			/*sleepTime(3);
			waitForLoading();
					//value.click();
*/				
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();",value);
	
				// div[text()='Yes']/preceding-sibling::div/input
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	public boolean checkOtherExistInCustomerSummaryByLabelName(WebDriver driver,
			String expLabelName) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement elet = driver
					.findElement(By
							.xpath("//div[contains(@class,'LND_Template_CV')]//div[contains(@class,'LND_TabLinkGroup_CV ')]/span[text()='"+expLabelName+"']"));
			
				return true;
				
		} 		
		catch (NoSuchElementException e)
		{
			System.out.println(expLabelName+"is not available");
			e.printStackTrace();
			return false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		}
	
	public void selectLinkInPropertyValueByLabelName(WebDriver driver,
			String expLabelName) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement value = driver
					.findElement(By
							.xpath("//div[contains(@data-binding,'local.linkClicked')]//span[text()='"+expLabelName+"']"));
			
					//validateAndClick(expLabelName,value);
			value.click();
	
				// div[text()='Yes']/preceding-sibling::div/input
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

	
	public void selectAnyRadioButtonInRBSByLabelName(String expLabelName,
			String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[text()='"
									+ expLabelName
									+ "']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"
								+ expRadioButton
								+ "']/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					// expYesOrNoButton.click();
					validateAndClick(expRadioButton + " Button",
							expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// to select the radio button in property value screen
	
	public void selectAnyRadioButtonInRBSByLabelNameCPBPropertyValue(WebDriver value,String expLabelName)
			 {
		
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> expRadioButtonsFrame = driver
					.findElements(By
							.xpath("//div[contains(@data-binding,'local.propertySecDetails')][contains(@class,'Output_Text wrapOutputText')]//span[contains(text(),'"+expLabelName+"')]/..//following::div[contains(@data-binding,'local.selectedMarketValue')]//div[contains(@class,'dijit dijitReset')]/input "));
			if (expRadioButtonsFrame != null) {
				
				expRadioButtonsFrame.get(0).click();
				
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickRadioButtonInRBSByLabelNameContains(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"
								+ expRadioButton
								+ "']/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					// expYesOrNoButton.click();
					validateAndClick(expRadioButton + " Button",
							expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void lendingClickRadioButtonInRBSByLabelNameContains(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[contains(text(),'"
								+ expRadioButton
								+ "')]/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					expYesOrNoButton.click();
					//validateAndClick(expRadioButton + " Button",
							//expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// to enter value in lending tracker non-complaint
	
			public void inputInDateFinderLendingtracker(WebDriver driver, String expLabelName,
					String value) {
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					/*WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//div[@class='selectLabel']/label[contains(text(),'"
											+ expLabelName
											+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]/div[contains(@class,'dijitInputField')]"));
					*/
					
					WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//div[contains(@class,'Date_Time_Picker')]//label[contains(text(),'"+expLabelName +"')]/../following-sibling::div//div[contains(@class,'dijitInputField')]"));
					
					
					if (expTextBoxFrame != null) {
						WebElement expTextField = expTextBoxFrame.findElement(By
								.xpath(".//input[not(@type='hidden')]"));
						if (expTextField != null) {

							validateAndSendKeys(expLabelName, expTextField, value);
							waitForLoading();
							Logger.LogMessage("Input in text box---successfull");
						}
						// div[text()='Yes']/preceding-sibling::div/input
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ expLabelName);
					e.printStackTrace();
				}
			}
			
			public void clickAnybuttonInRBSSearch(String buttonText) {
				// button[text()='Next']
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expButtonToClick = findAnyWebElement(
							By.xpath("//div[@class='RBS_Validation_Button_CV  CoachView CoachView_show']//button[text()='"+buttonText+"']"),
							buttonText);
					if (expButtonToClick != null) {
						expButtonToClick.click();
						//validateAndClick(buttonText, expButtonToClick);
						// doubleClick(buttonText, expButtonToClick);
						Logger.LogMessage("Button has been clicked---" + buttonText);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Button could not be clicked---" + buttonText);
					e.printStackTrace();
				}

			}
			
			public void clickAnybuttonInRBSCustInfo(String label,String buttonText) {
				// button[text()='Next']
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try{
				List<WebElement> searchvalue = driver
						.findElements(By
								.xpath("//div[@class='Vertical_Section  CoachView BPMSection CoachView_show']//h2[text()='"+label+"']/../..//button[text()='"+buttonText+"']"));
				if (searchvalue != null) 
				{
					
					if (searchvalue.size() >1) 
					{	
						validateAndClick("buttonText",searchvalue.get(0));
								
					}
				}
							
						Logger.LogMessage("Button has been clicked---" + buttonText);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Button could not be clicked---" + buttonText);
					e.printStackTrace();
				}
			}
			
			// to enter text area in cust info page
			public void inputIntextAreaInRBSBB(String expLabelName, String value) {

				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				try {
					WebElement expTextFrame = driver.findElement(By
							.xpath("//label[contains(text(),'"+expLabelName+"')]/../../textarea[@id='dijit_form_Textarea_0']"));

					if (expTextFrame != null) {

						expTextFrame.sendKeys(value);

						// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
						Logger.LogMessage("Input in text box---successfull");

						// div[text()='Yes']/preceding-sibling::div/input
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Input in text box---Not Successfull");
					e.printStackTrace();
				}
			}
			
			//for entering conn total direct limit with yes in link
			public void lendinginputInTextBoxRBSBB(WebDriver driver, String expLabelName,
					String value, String UniqueID) {
				waitForLoading();
				waitForLoadingElementInvisibility(driver);
				
				try {
					/*WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//div[@class='selectLabel']/label[text()='"
											+ expLabelName
											+ "']/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));*/
					
					WebElement expTextBoxFrame = driver
							.findElement(By
									.xpath("//div[@class='textLabel']/label[contains(text(),'"+expLabelName+"')]/..//following-sibling::div/div[contains(@class,'dijitTextBox')]/div[contains(@class,'dijitInputField')]//input[@id='"+UniqueID+"'][not(@type='hidden')]"));
					
							
							validateAndSendKeys(expLabelName, expTextBoxFrame, value);
							waitForLoading();
							Logger.LogMessage("Input in text box---successfull");
						
						// div[text()='Yes']/preceding-sibling::div/input
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("exception occured while entering value in---"
							+ expLabelName);
					e.printStackTrace();
				}

			}
	// is conn direct limit
	
	public void lendingClickRadioButtonInRBSByLabelNameContainsCPB(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> expYesOrNoButton = driver
					.findElements(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'" +expLabelName +  "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]//div[text()='"+expRadioButton+"']/preceding-sibling::div/input"));
			if (expYesOrNoButton != null) {
				
					expYesOrNoButton.get(2).click();
					
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// new to bank
	
	public void lendingClickRadioButtonInRBSByLabelNameContainsCPBNB(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> expYesOrNoButton = driver
					.findElements(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'" +expLabelName +  "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]//div[text()='"+expRadioButton+"']/preceding-sibling::div/input"));
			if (expYesOrNoButton != null) {
				
					expYesOrNoButton.get(0).click();
					
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// radiobutton for product eligibility
	
	public void lendingClickRadioButtonInRBSByLabelNameCPB(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='outputTextLabel']/label[contains(text(),'"+expLabelName+"')]/../..//following-sibling::div[contains(@class,'Radio_Buttons hideLabel')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"+expRadioButton+"']/preceding-sibling::div/input"));
				if (expButton != null) {
					expButton.click();
					//validateAndClick(expRadioButton + " Button",
							//expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void inputInTextBoxLendingRBSWOSelect(String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//div[@class='selectLabel']/label[contains(text(),'"+expLabelName+"')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]"));
			if (expTextBoxFrame != null) {
				WebElement expTextField = expTextBoxFrame.findElement(By
						.xpath(".//div[contains(@class,'dijitInputField')]/input[not(@type='hidden')]"));
				if (expTextField != null) {
					/*
					 * expTextField.click(); expTextField.clear();
					 * //sleepTime(1); expTextField.sendKeys(value,Keys.TAB);
					 */
					validateAndSendKeys(expLabelName, expTextField, value);
					//expTextField.sendKeys("Unsure");
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ expLabelName);
			e.printStackTrace();
		}

	}
	public void clickRadioButtonInRBSByLabelNameContains(String expLabelName,
			String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"
								+ expRadioButton
								+ "']/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					// expYesOrNoButton.click();
					validateAndClick(expRadioButton + " Button",
							expYesOrNoButton);
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void clickRadioButtonByAnswerLabelNameContains(String expLabelName) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			
			WebElement expRadioButton = driver
					.findElement(By
							.xpath("//div[contains(@class,'MultiSelectItemLabel')]/label[contains(text(),'"
									+ expLabelName+"')]/../preceding-sibling::div//input"));
			
					// expYesOrNoButton.click();
					validateAndClick(expRadioButton + " Button",
							expRadioButton);
				
				// div[text()='Yes']/preceding-sibling::div/input
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void clickRadioInProductScreen(String expRadioText) {
		//label[contains(text(),'urgent assistance')]/..//preceding-sibling::div[contains(@class,'dijitRadio')]//input
		//The customer would like to learn more about accepting card payments
		//div[contains(text(),'has no requirement to accept')]/..//preceding-sibling::div[contains(@class,'dijitRadio')]//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		List<WebElement> expRadioButton = null;
		try {
			if(!expRadioText.equalsIgnoreCase("has no requirement to accept")){
				expRadioButton = driver
						.findElements(By
								.xpath("//label[contains(text(),'"+expRadioText+"')]/..//preceding-sibling::div[contains(@class,'dijitRadio')]//input"));
			}else{
				expRadioButton = driver
						.findElements(By
								.xpath("//div[contains(text(),'"+expRadioText+"')]/..//preceding-sibling::div[contains(@class,'dijitRadio')]//input"));
			}



			if (expRadioButton != null) {
				validateAndClick("Radio Button", expRadioButton.get(0));
				
				//validateAndClick("Radio Button", expRadioButton.get(1));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void switchToIframe(WebDriver driver, By by) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		switchToDefaultContent(driver);
		// By.xpath("//iframe[contains(@title,'Complete Account Application')]")
		try {
			WebElement iFrame = driver.findElement(by);
			String iFrameTitle = iFrame.getAttribute("title");

			driver.switchTo().frame(iFrame);

			Logger.LogMessage("Switched to frame---Success---" + iFrameTitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Switched to frame---Not Success");
			e.printStackTrace();
		}

	}

	public void switchToDefaultContent(WebDriver driver) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			driver.switchTo().defaultContent();
			Logger.LogMessage("Switched to default page");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void selectAnyAddressInRBS(String uniqueAddressIdentifier) {
		// div[@id='RegisteredAddresSearch']//select
		// div[@id='RegisteredAddresSearch']//select/option[starts-with(@value,'4
		// THE BUTTS')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		WebElement addressSelect = findAnyWebElement(
				By.xpath("//div[contains(@id,'AddresSearch')]//select"),
				"Select Address");
		if (addressSelect != null) {
			WebElement address = addressSelect.findElement(By
					.xpath(".//option[starts-with(@value,'"
							+ uniqueAddressIdentifier + "')]"));
			if (address != null) {
				try {
					validateAndClick(uniqueAddressIdentifier, address);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}
	
public void searchAndClickInBBForAppCucu(String sTestName) throws IOException {
		
		String instanceID = readFromFile(sTestName +"_"+ "Instance");
		String RefNumber = readFromFile(sTestName +"_"+ "RefNumber");
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement inputTextInSrchBox = driver.findElement(By
					.xpath("//input[(contains(@id,'SearchBar'))]"));
			if (inputTextInSrchBox != null) {
				sleepTime(2);
				validateAndSendKeys("Search Box", inputTextInSrchBox, instanceID);
				waitForLoading();
				validateAndClick("Search Pane", inputTextInSrchBox);
				sleepTime(5);
				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoading();
				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoadingElementInvisibility();
				waitForLoading();
				WebElement linkToCLick = driver.findElement(By
						.xpath("//a[contains(text(),'" + RefNumber
								+ "')][@title]/ancestor::span//a"));
				validateAndClick("Reference Link", linkToCLick);
			
				
				//check claim task button
				searchForClaimTaskButton();
				Status = "Pass";
			}
		} catch (Exception e) {
			Status ="Fail";
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured in clicking link");
			e.printStackTrace();
		}
	}


	public void searchAndClickInBBForApp(String insanceID, String expRefNumber) {
		// input[(contains(@id,'SearchBar'))]
		// a[contains(text(),'NB00086116')][@title]/ancestor::span//a
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement inputTextInSrchBox = driver.findElement(By
					.xpath("//input[(contains(@id,'SearchBar'))]"));
			if (inputTextInSrchBox != null) {
				validateAndSendKeys("Search Box", inputTextInSrchBox, insanceID);
				waitForLoading();
				validateAndClick("Search Pane", inputTextInSrchBox);
				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoading();
				sleepTime(2);
				waitForLoadingElementInvisibility();
				WebElement linkToCLick = driver.findElement(By
						.xpath("//a[contains(text(),'" + expRefNumber
								+ "')][@title]/ancestor::span//a"));
				validateAndClick("Reference Link", linkToCLick);
				
				//check claim task button
				searchForClaimTaskButton();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured in clicking link");
			e.printStackTrace();
		}
	}
	
	public void searchAndClickInBBForAppDC(String insanceID, String expRefNumber) {
		// input[(contains(@id,'SearchBar'))]
		// a[contains(text(),'NB00086116')][@title]/ancestor::span//a
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement inputTextInSrchBox = driver.findElement(By
					.xpath("//input[(contains(@id,'SearchBar'))]"));
			if (inputTextInSrchBox != null) {
				validateAndSendKeys("Search Box", inputTextInSrchBox, insanceID);
				waitForLoading();
				validateAndClick("Search Pane", inputTextInSrchBox);
				sleepTime(2);
				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoading();
				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoadingElementInvisibility();
				WebElement linkToCLick = driver.findElement(By
						.xpath("//a[contains(text(),'" + expRefNumber
								+ "')][@title]/ancestor::span//a"));
				validateAndClick("Reference Link", linkToCLick);
				
				//check claim task button
				searchForClaimTaskButton();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured in clicking link");
			e.printStackTrace();
		}
	}
	
	public void searchForClaimTaskButton(){
		List<WebElement> allButtons = findObjectList(By.xpath("//button[text()]"), "All Buttons");
		for(WebElement wEle:allButtons){
			if(wEle.getText().equalsIgnoreCase("Claim Task")){
				try {
					validateAndClick("Claim Task Button", wEle);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
	public void sendEnterKeys(WebDriver driver, WebElement wEle) {
		waitForLoadingElementInvisibility(driver);
		Actions action = new Actions(driver);
		action.moveToElement(wEle).sendKeys(Keys.ENTER).build().perform();

	}
	
	public void getApplicationReferenceNumber(String sTestName) {
		
				switchToIframe(
						driver,
						By.xpath("//iframe[contains(@title,'Perform product selection')]"));
		waitforPageToAppear();
		waitForPageHeaderToAppear("Customer information");
		
		WebElement pageHeader = findAnyWebElement(
				By.xpath("//div[contains(@class,'instructionID')]"),
				"Ref Number");
		try {
			if (pageHeader != null) {
				String expRefNum = pageHeader.getText();
				String expReffull = expRefNum.substring(17);
				Logger.LogMessage(expReffull);
				expRefNum = expRefNum.replaceAll("[^0-9]+", "").trim();
				
				String RefNum = sTestName +"_"+ "RefNumber";
				Logger.LogMessage("Refernce number fetched successfully--"
						+ expReffull);
				writeToFileOBAO(RefNum, expReffull);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void selectCheckBoxByText(WebDriver driver, String expCheckBoxText) {
		// label[text()='General Public']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expCHeckBox = driver.findElement(By
					.xpath("//label[text()='" + expCheckBoxText
							+ "']/preceding-sibling::div//input"));
			if (expCHeckBox != null) {
				expCHeckBox.click();
				// validateAndClick(expCheckBoxText+" CheckBox", expCHeckBox);
				Logger.LogMessage("Check Box---" + expCheckBoxText
						+ "----has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while finding checkbox---"
					+ expCheckBoxText);
			e.printStackTrace();
		}
	}

	public void clickAnyButtonFocussedOut(String buttonText) {

		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//button[text()='" + buttonText + "']"),
					buttonText);
			if (expButtonToClick != null) {
				expButtonToClick.sendKeys(Keys.ENTER);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + buttonText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + buttonText);
			e.printStackTrace();
		}
	}

	public String getdefaultTextFromTable(int tableNumber, int rowNum,
			int colNum) {
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]
		// /div[last()][contains(@class,'BPMBorder')]/div[1]/div[2]//span[not(@style)]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String expValue = null;
		try {
			WebElement expTable = driver
					.findElement(By
							.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
									+ tableNumber
									+ "]/following-sibling::div[1]"));

			WebElement expElement = expTable.findElement(By
					.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
							+ rowNum + "]/div[" + colNum
							+ "]//span[not(@style)]"));
			if (expElement != null) {
				expValue = expElement.getText();
				Logger.LogMessage("Expected value from table fetched successfully");

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured while fetching value from table");
			e.printStackTrace();
		}

		return expValue;
	}

	public void fluentWaitForElementPolling(WebDriver driver, By by) {
		final By ele = by;
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(20, TimeUnit.SECONDS)
					.pollingEvery(3, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);

			wait.until(new Function<WebDriver, WebElement>() {

				@Override
				public WebElement apply(WebDriver driver) {
					// TODO Auto-generated method stub
					return driver.findElement(ele);
				}

			});
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//Logger.LogMessage("Fluent Wait Done polling");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait exception");
			e.printStackTrace();
		}

	}

	public void waitForLoadingElementInvisibility(WebDriver driver) {

		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			// WebDriverWait wait = new WebDriverWait(driver, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By
					.xpath("//img[@alt='Please Wait...']")));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//Logger.LogMessage("Fluent Wait Done polling");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait exception");
			e.printStackTrace();
		}
	}

	public void waitForLoadingElementInvisibility() {

		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			// WebDriverWait wait = new WebDriverWait(driver, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By
					.xpath("//img[@alt='Please Wait...']")));
			
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait Done polling");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait exception");
			e.printStackTrace();
		}
	}

	public void waitForElementToAppear(String elementName, By by) {

		Logger.LogMessage("Entering waitForElementToAppear");
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

			WebDriverWait wait = new WebDriverWait(driver, 30);
			// wait.until(ExpectedConditions.visibilityOf(element));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			// wait.until(ExpectedConditions.elementToBeClickable(element));
			ReporterA.reportPassWithSnapshot(
					"Wait for element: " + elementName, elementName
							+ " should appear", elementName + " has appeared",
					driver);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception in waitforelementtoAppear in Base Page--");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			e.printStackTrace();
		}

		Logger.LogMessage("Exiting waitForElementToAppear");
	}
	
	public void waitForPageToAppear(String elementName, By by) {

		//Logger.LogMessage("Entering waitForElementToAppear");
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

			WebDriverWait wait = new WebDriverWait(driver, 30);
			// wait.until(ExpectedConditions.visibilityOf(element));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			// wait.until(ExpectedConditions.elementToBeClickable(element));
			ReporterA.reportPassWithSnapshot(
					"Wait for element: " + elementName, elementName
							+ " should appear", elementName + " has appeared",
					driver);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		

		//Logger.LogMessage("Exiting waitForElementToAppear");
	}

	public void waitForElementToDisappear(String elementName, By by) {

		//Logger.LogMessage("Entering waitForElementToAppear");
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

			WebDriverWait wait = new WebDriverWait(driver, 30);
			// wait.until(ExpectedConditions.visibilityOf(element));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
			// wait.until(ExpectedConditions.elementToBeClickable(element));
			ReporterA.reportPassWithSnapshot(
					"Wait for element: " + elementName, elementName
							+ " should appear", elementName + " has appeared",
					driver);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception in waitforelementtoAppear in Base Page--");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			e.printStackTrace();
		}

		//Logger.LogMessage("Exiting waitForElementToAppear");
	}

	public void validateMultipleTablesInRBS(int dynamicTableNumber, int rowNum,
			int fieldNumber, String operation, String value) throws Exception {

		System.out.println("Value" + value);
		waitForLoading();
		waitForLoadingElementInvisibility(driver);

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@type='radio']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[@value='Please
		// select...']
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//input[contains(@id,'ComboBox')]

		// table always with one row

		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1]//div[last()][@class='BPMBorder']

		// table xpath to get all rows
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][3]/following-sibling::div[1]//div[last()][@class='BPMBorder']/div

		// find table from RBS
		List<WebElement> expTable = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTable != null) {
			// get the expected row from table
			// WebElement expRow =
			// expTable.findElement(By.xpath("div[last()][contains(@class,'BPMBorder')]/div["+rowNum+"]"));
			// if(expRow!=null){

			if (expTable.size() != 0) {
				// WebElement expTable
				// =driver.findElement(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1]"));

				if (operation.equalsIgnoreCase("radio")) {
					WebElement radioToClick = expTable
							.get(dynamicTableNumber - 1)
							.findElement(
									By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
											+ rowNum
											+ "]//input[@type='radio']"));
					if (radioToClick != null) {
						validateAndClick("Radio Button", radioToClick);
					}
				} else if (operation.equalsIgnoreCase("input")) {
					List<WebElement> allInputs = null;
					try {
						allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
										By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[@value='Please select...']"));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if (allInputs.size() > 1) {
						validateAndSendKeys("Input",
								allInputs.get(fieldNumber - 1), value);

					} else {
						/*
						 * WebElement input = expTable.findElement(By.xpath(
						 * "div[contains(@class,'BPMBorder')]")); WebElement
						 * checknext = input.findElement(By.xpath("div["+rowNum+
						 * "]//input[@value='Please select...']"));
						 */
						validateAndSendKeys("Input", allInputs.get(0), value);
					}
				} else if (operation.equalsIgnoreCase("textbox")) {
					try {
						List<WebElement> allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
										By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[contains(@id,'ComboBox')]"));
						if (allInputs.size() > 1) {
							validateAndSendKeys("Input",
									allInputs.get(fieldNumber - 1), value);

						} else {
							validateAndSendKeys("Input", allInputs.get(0),
									value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
				else if (operation.equalsIgnoreCase("checkbox")) {
					try {
						List<WebElement> allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
											By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
													+ rowNum
													+ "]//input[contains(@id,'CheckBox')]"));
						if (allInputs.size() > 1) {

							validateAndClick("checkbox",
									allInputs.get(fieldNumber - 1));

						} else {
							validateAndClick("checkbox", allInputs.get(0));
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if (operation.equalsIgnoreCase("uniqueName")) {
					// uniqName
					try {
						List<WebElement> allInputs = expTable
								.get(dynamicTableNumber - 1)
								.findElements(
										By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
												+ rowNum
												+ "]//input[contains(@id,'uniqName')]"));
						if (allInputs.size() > 1) {
							validateAndSendKeys("Input",
									allInputs.get(fieldNumber - 1), value);

						} else {
							validateAndSendKeys("Input", allInputs.get(0),
									value);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				// }
			} else if (expTable.size() == 1) {

				Logger.LogMessage("Use the component---getAnythingfromtable Please...!!");

			}

		} else {
			Logger.LogMessage("Table Number is not correct or page does not have a table");
		}

	}

	public void clickButtonNextToDynamicTable(String buttonText,
			int dynamicTableNumber) {
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]
		// .//following-sibling::div[1]//button[text()='Add row']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			List<WebElement> allDynamicTable = driver
					.findElements(By
							.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
			WebElement expButton = allDynamicTable
					.get(dynamicTableNumber - 1)
					.findElement(
							By.xpath(".//following-sibling::div[1]//button[text()='"
									+ buttonText + "']"));
			if (expButton != null) {
				validateAndClick(buttonText, expButton);
			}
			Logger.LogMessage("clicked the button from table--" + buttonText);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Unable to click the button from table--"
					+ buttonText);
			e.printStackTrace();
		}

	}

	public void clickButtonNextToTable(String buttonText, int dynamicTableNumber) {
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]
		// .//following-sibling::div[1]//button[text()='Add row']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement allDynamicTable = driver
					.findElement(By
							.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show']["
									+ dynamicTableNumber
									+ "]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
			WebElement expButton = allDynamicTable.findElement(By
					.xpath(".//following-sibling::div[1]//button[text()='"
							+ buttonText + "']"));
			if (expButton != null) {
				validateAndClick(buttonText, expButton);
			}
			Logger.LogMessage("clicked the button from table--" + buttonText);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Unable to click the button from table--"
					+ buttonText);
			e.printStackTrace();
		}

	}

	public List<WebElement> findObjectList(By by, String eleName) {

		List<WebElement> eLes = null;
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			eLes = driver.findElements(by);
			Logger.LogMessage("Finding Elements---Success---" + eleName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Finding Elemenst---Not Success---try Again--Proceeding further"
					+ eleName);
			e.printStackTrace();
		}

		return eLes;

	}

	public List<WebElement> findObjectListFromWebElement(WebElement wEle,
			By by, String eleName) {

		List<WebElement> eLes = null;
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			eLes = wEle.findElements(by);
			Logger.LogMessage("Finding Elements---Success---" + eleName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Finding Elemenst---Not Success---try Again--Proceeding further"
					+ eleName);
			e.printStackTrace();
		}

		return eLes;

	}

	public void quitWebDriver() {
		driver.quit();

	}

	// #---BB Workflows peculiar elements
	public void clickRadioButtonBBWorkflow(WebDriver driver,
			String expLabelName, String expRadioButton) {
		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expRadioButtonsFrame = driver
					.findElement(By
							.xpath("//div[@class='radioButtonsLabel']/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]"));
			if (expRadioButtonsFrame != null) {
				WebElement expYesOrNoButton = expRadioButtonsFrame
						.findElement(By.xpath(".//div[text()='"
								+ expRadioButton
								+ "']/preceding-sibling::div/input"));
				if (expYesOrNoButton != null) {
					// expYesOrNoButton.click();
					expYesOrNoButton.sendKeys(Keys.ENTER);
					/*
					 * validateAndClick(expRadioButton + " Button",
					 * expYesOrNoButton);
					 */
				}
				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void clickElementUsingSendKeys(String string,
			WebElement element) {

		try {
			if (element != null) {
				element.sendKeys(Keys.SPACE);
				Logger.LogMessage(element + " has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage(element + " has not been clicked");
			e.printStackTrace();
		}

	}

	public static void clickLinkAndButtonUsingSendKeys(String string,
			WebElement element) {

		// waitForLoadingElementInvisibility(driver);
		try {

			if (element != null) {
				//element.sendKeys(Keys.ENTER);
			element.click();
				Logger.LogMessage(element + " has been clicked");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage(element + " has not been clicked");
			e.printStackTrace();
		}
	}

	public  void logout() {

		try {
			WebElement el = driver.findElement(By
					.xpath("//div[@class='processPortalUserDropdown']"));
			BBConnectUtils.clickLinkAndButtonUsingSendKeys("Drop Down", el);

			el = driver
					.findElement(By
							.xpath("//td[@class='dijitReset dijitMenuItemLabel'][text()='Logout']"));
			BBConnectUtils.clickLinkAndButtonUsingSendKeys("Log out", el);
			Logger.LogMessage("Exception in Logout Screen");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception in Logout Screen");
			e.printStackTrace();
		}

	}

	public static void switchToWindow() {

		try {

			String oldTab = driver.getWindowHandle();
			ArrayList<String> newTab = new ArrayList<String>(
					driver.getWindowHandles());
			newTab.remove(oldTab);
			// change focus to new tab
			driver.switchTo().window(newTab.get(0));
			driver.close();
			// change focus back to old tab
			driver.switchTo().window(
					(String) driver.getWindowHandles().toArray()[0]);
		} catch (Exception e) {
			System.out.println("Tab switching not done ");
		}

	}

	public void switchToframeAndClickNext(By by) {
		switchToIframe(driver, by);
		clickAnybuttonInRBS("Next");
	}

	public static void clickOnClaimTaskButton() {

		try {
			WebElement element = driver
					.findElement(By
							.xpath(("//button[@class='bspace-style bspace-button bspace-border bspace-wrapped bspace-wrapper'][text()='Claim Task']")));

			if (element.isDisplayed()) {
				BBConnectUtils.clickLinkAndButtonUsingSendKeys("Claim Task Button",
						element);
			}
		} catch (Exception e) {
			System.out.println("Claim Task Button is not present on-screen");
		}
	}

	public void writeToFileOBAO(String key, String value) throws IOException {
		String fileName = System.getProperty("user.dir")
				+ "//DynamicData//Data.txt";
		System.out.println("file path is ---" + fileName);

		FileWriter fileWriter = null;
		BufferedWriter bufferWrite = null;
		try {
			fileWriter = new FileWriter(fileName, true);
			bufferWrite = new BufferedWriter(fileWriter);
			bufferWrite.write(key + "=" + value);
			bufferWrite.newLine();
		} catch (Exception e) {

		} finally {
			bufferWrite.close();
		}

	}

	public void clearTheFile(String key, String value) throws IOException {
		String fileName = System.getProperty("user.dir")
				+ "//DynamicData//Data.txt";
		System.out.println("file path is ---" + fileName);

		FileWriter fileWriter = null;
		BufferedWriter bufferWrite = null;
		try {
			fileWriter = new FileWriter(fileName, false);
			bufferWrite = new BufferedWriter(fileWriter);
			bufferWrite.write("");
			bufferWrite.newLine();
		} catch (Exception e) {

		} finally {
			bufferWrite.close();
		}

	}

	public void appendToExistingFile(String key, String value)
			throws IOException {
		String fileName = System.getProperty("user.dir")
				+ "//DynamicData//Data.txt";
		System.out.println("file path is ---" + fileName);

		FileWriter fileWriter = null;
		BufferedWriter bufferWrite = null;
		try {
			fileWriter = new FileWriter(fileName);
			bufferWrite = new BufferedWriter(fileWriter);
			bufferWrite.newLine();
			bufferWrite.write(key + "=" + value);
			bufferWrite.newLine();

		} catch (Exception e) {

		} finally {
			bufferWrite.close();
		}
	}

	public String readFromFile(String expKey) throws IOException {

		String fileName = System.getProperty("user.dir")
				+ "//DynamicData//Data.txt";
		System.out.println("file path is ---" + fileName);
		String line = null;
		final int key = 0;
		final int value = 1;
		FileReader filereader = null;
		BufferedReader bufferfile = null;
		TreeMap<String, String> returnValues = new TreeMap<String, String>();
		try {
			filereader = new FileReader(fileName);
			bufferfile = new BufferedReader(filereader);

			while ((line = bufferfile.readLine()) != null) {

				System.out.println(line);
				if (!line.isEmpty()) {
					String pair[] = line.trim().split("=");
					returnValues.put(pair[key], pair[value]);
				}
			}
			// bufferfile.close();
		} catch (Exception e) {
			Logger.LogMessage("Exception occured in reading file--Please check for location and Data");
		} finally {
			bufferfile.close();
		}

		// fetch the value
		return returnValues.get(expKey);

	}

	public void inputSortCodeInRBSLabelName(WebDriver driver,
			String explabelName, String sortcode) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]

		List<String> sortcodes = new ArrayList<String>();
		sortcodes.add(sortcode.substring(0, 2));
		sortcodes.add(sortcode.substring(2, 4));
		sortcodes.add(sortcode.substring(4, 6));

		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ explabelName
									+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"));
			for (WebElement nav : allDateTextBoxes) {
				validateAndSendKeys("Day", nav, sortcodes.get(counter));

				counter++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void inputSortCodeInRBSLabelName(String explabelName, String sortcode) {

		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// div[contains(@class,'textLabel')]/label[text()='When does/will your
		// financial year
		// end?']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]

		List<String> sortcodes = new ArrayList<String>();
		sortcodes.add(sortcode.substring(0, 2));
		sortcodes.add(sortcode.substring(2, 4));
		sortcodes.add(sortcode.substring(4, 6));

		int counter = 0;
		try {
			List<WebElement> allDateTextBoxes = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[text()='"
									+ explabelName
									+ "']/..//following-sibling::div//input[not(@readonly)][not(@type='hidden')]"));
			for (WebElement nav : allDateTextBoxes) {
				validateAndSendKeys("Day", nav, sortcodes.get(counter));

				counter++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getTheTestCase() {
		String filePath = System.getProperty("user.dir")
				+ "//config//Execution.properties";
		try {
			FileInputStream fin = new FileInputStream(filePath);
			Properties prop = new Properties();
			prop.load(fin);
			return prop.getProperty("TestCaseID");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public String getTheSheetNameOld() {
		String filePath = System.getProperty("user.dir")
				+ "//config//Execution.properties";
		try {
			FileInputStream fin = new FileInputStream(filePath);
			Properties prop = new Properties();
			prop.load(fin);
			return prop.getProperty("ExcelSheetName");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	
	public String getTheSheetName(String scenum) {
		TestBase getsheet = new TestBase();
		return getsheet.getSheetName(scenum);
	}

	public String getLoginID() {
		String filePath = System.getProperty("user.dir")
				+ "//config//Execution.properties";
		try {
			FileInputStream fin = new FileInputStream(filePath);
			Properties prop = new Properties();
			prop.load(fin);
			return prop.getProperty("LoginAs");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public String getrandomnumber(int max, int min) {
		Random rn = new Random();
		int randomNumber = rn.nextInt((max - min) + 1) + min;
		return String.valueOf(randomNumber);
	}

	public int countTabsAndClickAddNew(String Tab) {
		// div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		Map<String, String> getEntity = null;

		BBConnectUtils testName = new BBConnectUtils();
		String sTestName = testName.getTheTestCase();
		getEntity = ExcelUtils.getTestDataRow_BB("GettingStarted", sTestName);

		waitForPageHeaderToAppear("Key Principal Summary");
		int totalTabs = 0;
		List<WebElement> countOfTabs = findObjectList(
				By.xpath("//div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div"),
				"All Tabs");
		if (countOfTabs != null) {
			totalTabs = countOfTabs.size();
			List<WebElement> addNewButton = findObjectList(
					By.xpath("//button[text()='Add New']"), "Add New Buttons");

			if (!getEntity.get("strLegalStatus")
					.equalsIgnoreCase("Sole Trader")) {
				try {
					if (Tab.contains("company")) {
						validateAndClick("Add new Button", addNewButton.get(1));
					} else if (Tab.contains("Individual")) {
						validateAndClick("Add new Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Add new Button", addNewButton.get(2));
					} else if (Tab.contains("Contact Details")) {
						validateAndClick("Add new Button", addNewButton.get(4));
					} else if (Tab.contains("Signatory")) {
						validateAndClick("Add new Button", addNewButton.get(3));
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				try {
					if (Tab.contains("Individual")) {
						validateAndClick("Add new Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Add new Button", addNewButton.get(1));
					} else if (Tab.contains("Contact Details")) {
						validateAndClick("Add new Button", addNewButton.get(3));
					} else if (Tab.contains("Signatory")) {
						validateAndClick("Add new Button", addNewButton.get(2));
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return totalTabs;

	}

	public int countTabsAndClickAddNewBB(String Tab) {
		// div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String getEntity = null;

		BBConnectUtils testName = new BBConnectUtils();
		String sTestName = testName.getTheTestCase();
		try {
			getEntity = readFromFile("strLegalStatus");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//ExcelUtils.getTestDataRow_BB("GettingStarted", sTestName)

		waitForPageHeaderToAppear("Key Principal Summary");
		int totalTabs = 0;
		List<WebElement> countOfTabs = findObjectList(
				By.xpath("//div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div"),
				"All Tabs");
		if (countOfTabs != null) {
			totalTabs = countOfTabs.size();
			List<WebElement> addNewButton = findObjectList(
					By.xpath("//button[text()='Add New']"), "Add New Buttons");

			if (!getEntity.equalsIgnoreCase("Sole Trader")) {
				try {
					if (Tab.contains("company")) {
						validateAndClick("Add new Button", addNewButton.get(1));
					} else if (Tab.contains("Individual")) {
						validateAndClick("Add new Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Add new Button", addNewButton.get(2));
					} else if (Tab.contains("Business Contact")) {
						validateAndClick("Add new Button", addNewButton.get(3));
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				try {
					if (Tab.contains("Individual")) {
						validateAndClick("Add new Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Add new Button", addNewButton.get(1));
					} else if (Tab.contains("Business Contact")) {
						validateAndClick("Add new Button", addNewButton.get(2));
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return totalTabs;

	}

	public void clickLinkFromTopMenu(String linkName) {
		// //div[contains(@class,'TabLinkGroup')]//span
		switchToCompleteApplicationFrame();
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		completeAppFrame = true;
		waitForElementToAppear("All Links",
				By.xpath("//div[contains(@class,'TabLinkGroup')]//span"));
		List<WebElement> allLinks = findObjectList(
				By.xpath("//div[contains(@class,'TabLinkGroup')]//span"),
				"All Links");
		try {
			if (allLinks != null) {
				for (WebElement wEle : allLinks) {
					if (wEle.getText().equalsIgnoreCase(linkName)) {
						validateAndClick(linkName, wEle);
						break;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void switchToCompleteApplicationFrame() {
		switchToIframe(
				driver,
				By.xpath("//iframe[contains(@title,'Complete Account Application')]"));

	}

	public void switchToCaptureAppFrame() {
		switchToIframe(
				driver,
				By.xpath("//iframe[contains(@title,'Capture Application Detail')]"));

	}

	public void waitforPageToAppear() {
		// WebElement loadingEle =
		// findAnyWebElement(By.xpath("//div[text()='Loading...']"), "Loading");
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			// WebDriverWait wait = new WebDriverWait(driver, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By
					.xpath("//div[text()='Loading...']")));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait Done polling");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Logger.LogMessage("Fluent Wait exception");
			e.printStackTrace();
		}
	}

	public void clickRadioButtonByRadioText(String expText) {
		// div[text()='SortCode']/preceding-sibling::div//input
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		WebElement radioButton = findAnyWebElement(
				By.xpath("//div[text()='" + expText
						+ "']/preceding-sibling::div//input"), "Radio Button");
		try {
			if (radioButton != null) {
				validateAndClick(expText, radioButton);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void waitForPageHeaderToAppear(String expHeaderText) {
		// WebElement header =
		// findAnyWebElement(By.xpath("//h2[contains(text(),'"+expHeaderText+"')]"),
		// expHeaderText);

		//waitForElementToAppear(expHeaderText,
			//	By.xpath("//h1[contains(text(),'" + expHeaderText + "')]"));
		waitForPageToAppear(expHeaderText,
				By.xpath("//h1[contains(text(),'" + expHeaderText + "')]"));

	}
	public void javascriptexecutorcodeAJ(String LabelName)  {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		WebElement expTextBoxFrame = driver
				.findElement(By
						.xpath("//button[text()='Exit']"));
		
		jse.executeScript("arguments[0].scrollIntoView(true);",expTextBoxFrame);
		jse.executeScript("window.scrollBy(0,-100)","");
		sleepTime(2);
		ReporterA.reportPassWithSnapshot(LabelName
				+ " validate if present ", LabelName
				+ "should be displayed", LabelName
				+ "is displayed", driver);
	
	} 
	//credit
	
	public String getappIdAsstJourney() {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String textval = null;
		try {
			WebElement expButtonToClick = driver.findElement(
					By.xpath("//p[contains(@class,'AgreementPage_referencedID')]"));
			if (expButtonToClick != null) {
				textval=expButtonToClick.getText();
				ReporterA.reportPassWithSnapshot("IneligHeader"
						+ " validate if present ", "IneligHeader"
						+ "should be displayed", "IneligHeader"
						+ "is displayed", driver);
									Logger.LogMessage("Button has been clicked---" + "IneligHeader");
			
			}
			return textval;
		} catch (Exception e) {
			
			Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
			e.printStackTrace();
			return null;
		}

	}
	
	public String getappIdgoodNews() {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		String textval = null;
		try {
			WebElement expButtonToClick = driver.findElement(
					By.xpath("//small"));
			if (expButtonToClick != null) {
				textval=expButtonToClick.getText();
				ReporterA.reportPassWithSnapshot("getappIdgoodNews"
						+ " validate if present ", "getappIdgoodNews"
						+ "should be displayed", "getappIdgoodNews"
						+ "is displayed", driver);
									Logger.LogMessage("Button has been clicked---" + "getappIdgoodNews");
			
			}
			return textval;
		} catch (Exception e) {
			
			Logger.LogMessage("Button could not be clicked---" + "IneligHeader");
			e.printStackTrace();
			return null;
		}

	}
	
	public void inputInTextBoxZambesiCredit(WebDriver driver,String spFieldName,String Value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//input[@name ='"+spFieldName+"']"));
			
			
			if (expTextBoxFrame != null) {
				
					
					validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
					
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ spFieldName);
			e.printStackTrace();
		}


}
	
	//HyperLink for Credit
	public void clickAnylinkInZambesiCredit(String linkText) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expButtonToClick = findAnyWebElement(
					By.xpath("//a[contains(text(),'"+linkText+"')]"),
					linkText);
			//a[@href='#/help?tab=contactUs']
			//button[text()='" + buttonText + "']
			if (expButtonToClick != null) {
				expButtonToClick.click();
				ReporterA.reportPassWithSnapshot(linkText
						+ " validate if present ", linkText
						+ "should be displayed", linkText
						+ "is displayed", driver);
				//validateAndClick(buttonText, expButtonToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Button has been clicked---" + linkText);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Button could not be clicked---" + linkText);
			e.printStackTrace();
		}
		
	}
	

	
public void ZambesiRadioButtonCredit(WebDriver driver,String idval,String expRadioButton) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expYesOrNoButton = driver
					.findElement(By
							.xpath("//label[@id='"+ idval +""+expRadioButton+"']"));
			
			
				if (expYesOrNoButton != null) {
					expYesOrNoButton.click();
					ReporterA.reportPassWithSnapshot(expRadioButton
							+ " validate if present ", expRadioButton
							+ "should be displayed", expRadioButton
							+ "is displayed", driver);
				}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public String gettextcredit(String expLabelName,String Value)
{
waitForLoading();
waitForLoadingElementInvisibility(driver);
try{
WebElement exp = driver.findElement(By.xpath("//div[contains(@class,'currentAddress_36JC')]//div[contains(text(),'"+expLabelName+"')]"));

Value = exp.getText();

} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();

}
return Value;
}

//Credit drop down List

public void ZambesiDropDownCredit(WebDriver driver,String id, String value, int position) {

waitForLoading();
waitForLoadingElementInvisibility(driver);
try {
List <WebElement> expvalue = driver
		.findElements(By
				.xpath("//select[@id='"+id+"']/option[contains(text(),'"+value+"')]"));
//label[@id='"+ expRadioButton+ "']
//select[@id='repaymentDate']/option[@value='2']
if(expvalue.size()>1)
{
	//validateAndClick(linkText, expButtonToClick.get(value));
	//validateAndSendKeys(id,expvalue.get(position),value);
	expvalue.get(position).click();
	//expvalue.get(position).sendKeys(value);
	
	
	
	
}
		ReporterA.reportPassWithSnapshot(expvalue
				+ " validate if present ", expvalue
				+ "should be displayed", expvalue
				+ "is displayed", driver);
	


} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}

	// credit link these details aren't right
				public void clickAnylinkInZambesiCreditTheseDetails(WebDriver driver,String linkText,int value) {
					// button[text()='Next']
					waitForLoading();
					waitForLoadingElementInvisibility(driver);
					try {
						List <WebElement> expButtonToClick = driver.findElements(By
								.xpath("//a[contains(text(),'"+linkText+"')]")); 
						//a[@href='#/help?tab=contactUs']
						//button[text()='" + buttonText + "']
						if (expButtonToClick != null) {
							
							if(expButtonToClick.size()>1)
							{
								validateAndClick(linkText, expButtonToClick.get(value));
							}
							ReporterA.reportPassWithSnapshot(linkText
									+ " validate if present ", linkText
									+ "should be displayed", linkText
									+ "is displayed", driver);
							//validateAndClick(buttonText, expButtonToClick);
							// doubleClick(buttonText, expButtonToClick);
							Logger.LogMessage("Button has been clicked---" + linkText);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Logger.LogMessage("Button could not be clicked---" + linkText);
						e.printStackTrace();
					}
					
				}
	
	//Age Calculation
	
			public int CalculateAge(String DOB)
			{
				
			/*//	DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-mm-yyyy");
				LocalDate birthdate = new LocalDate(DOB);
				LocalDate now = new LocalDate();
				Years age = Years.yearsBetween(birthdate,now);
			   // return getAge(dob);
	*/		
			
			int dayDOB = Integer.parseInt(DOB.substring(0,2));
			int monthDOB = Integer.parseInt(DOB.substring(3,5));
			int yearDOB = Integer.parseInt(DOB.substring(6,10));
			
			DateFormat dateFormat = new SimpleDateFormat("YYYY");
			java.util.Date date = new java.util.Date();
			int thisYear = Integer.parseInt(dateFormat.format(date));
			
			dateFormat = new SimpleDateFormat("MM");
			date = new java.util.Date();
			int thisMonth = Integer.parseInt(dateFormat.format(date));
			
			dateFormat = new SimpleDateFormat("dd");
			date = new java.util.Date();
			int thisDay = Integer.parseInt(dateFormat.format(date));
			
			
				int age = thisYear - yearDOB;
			
			
			if(thisMonth<monthDOB)
			{
				age = age-1;
			}
			
			if(thisMonth == monthDOB && thisDay< dayDOB)
			{
				age=age-1;
			}
			System.out.println(age);
			return age;
				}
	
	
 
	
	public void HeaderTextInZambesi(String expHeaderText) {
		// WebElement header =
		// findAnyWebElement(By.xpath("//h2[contains(text(),'"+expHeaderText+"')]"),
		// expHeaderText);

		waitForElementToAppear(expHeaderText,
				By.xpath("//h1[contains(text(),'" + expHeaderText + "')]"));

	}
	

	public void clickSaveDetailsInKPPage() {
		try {
			clickAnybuttonInRBS("Save Details");
			// need to click yes button
			clickAnybuttonInRBS("Yes");
			waitForLoadingElementInvisibility(driver);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getAttributeValue(By by, String attriNAme) {
		WebElement wEle = findAnyWebElement(by, attriNAme);
		try {
			if (wEle != null) {
				String expATtributeVal = wEle.getAttribute(attriNAme);
				return expATtributeVal;

			} else {
				return null;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public String getStatusWebElement(String screenName) {
		try {
			// return
			// driver.findElement(By.xpath("//span[text()='"+screenName+"']//ancestor::tr[1]/td[2]/div/span"));
			WebElement statusCheck = findAnyWebElement(
					By.xpath("//span[text()='" + screenName
							+ "']//ancestor::tr[1]/td[2]/div/span"), "Text");
			if (statusCheck != null) {
				return statusCheck.getText();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void selectDirectorCheckBox(String expUserName) {
		// div[contains(@id,'Paginator')]/preceding-sibling::div[1]//table//span

		// span
		// span[contains(text(),'Ram Saran')]//ancestor::table
		// span[contains(text(),'Ram
		// Saran')]//ancestor::table//label[contains(text(),'Directors that
		// exert')]/preceding-sibling::div//input
		WebElement expCheckBox = findAnyWebElement(
				By.xpath("//span[contains(text(),'"
						+ expUserName
						+ "')]//ancestor::table//label[contains(text(),'Directors that exert')]/preceding-sibling::div//input"),
				"CheckBox");
		if (expCheckBox != null) {
			try {
				validateAndClick(expUserName, expCheckBox);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void selectUserRadioInKPPage(String expUserName) {
		// div[contains(@id,'Paginator')]/preceding-sibling::div[1]//table//span

		// span
		// span[contains(text(),'Ram Saran')]//ancestor::table
		// span[contains(text(),'ROGER
		// GAWN')]//ancestor::table//div[@role='Radio']
		WebElement expCheckBox = findAnyWebElement(
				By.xpath("//span[contains(text(),'" + expUserName
						+ "')]//ancestor::table//div[@role='Radio']"),
				"CheckBox");
		if (expCheckBox != null) {
			String checkIfAlreadyChecked = null;
			boolean found = false;
			if (expCheckBox != null) {
				try {
					checkIfAlreadyChecked = expCheckBox
							.getAttribute("aria-checked");
					found = true;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					found = false;
				}

				try {
					if (checkIfAlreadyChecked.equalsIgnoreCase("false")) {
						validateAndClick(expUserName, expCheckBox);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			/*
			 * try { validateAndClick(expUserName, expCheckBox); } catch
			 * (Exception e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 */
		}

	}

	public void clickTabInKPPage(String expTabName) {

		waitForLoadingElementInvisibility();
		switchToIframe(
				driver,
				By.xpath("//iframe[contains(@title,'Complete Account Application')]"));

		WebElement expTab = findAnyWebElement(
				By.xpath("//span[text()='" + expTabName + "']"), "Individual");
		try {
			if (expTab != null) {
				validateAndClick(expTabName, expTab);
				waitForLoadingElementInvisibility();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void standByForPageLoad() {
		// WebElement standBy =
		// findAnyWebElement(By.xpath("//div[contains(@id,'Standby')]"),
		// "Stand By");
		waitForElementToDisappear("STand By",
				By.xpath("//div[contains(@id,'Standby')]"));
	}

	public int countTabsAndClickEdit(String Tab) {
		// div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		Map<String, String> getEntity = null;

		BBConnectUtils testName = new BBConnectUtils();
		String sTestName = testName.getTheTestCase();
		getEntity = ExcelUtils.getTestDataRow_BB("GettingStarted", sTestName);

		waitForPageHeaderToAppear("Key Principal Summary");
		int totalTabs = 0;
		List<WebElement> countOfTabs = findObjectList(
				By.xpath("//div[@class='nowrapTabStrip dijitTabContainerTop-tabs']//div"),
				"All Tabs");
		if (countOfTabs != null) {
			totalTabs = countOfTabs.size();
			List<WebElement> addNewButton = findObjectList(
					By.xpath("//button[text()='Edit']"), "Edit Buttons");

			if (!getEntity.get("strLegalStatus")
					.equalsIgnoreCase("Sole Trader")) {
				try {
					if (Tab.contains("company")) {
						validateAndClick("Edit Button", addNewButton.get(1));
					} else if (Tab.contains("Individual")) {
						validateAndClick("Edit Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Edit Button", addNewButton.get(2));
					} else if (Tab.contains("Contact Details")) {
						validateAndClick("Edit Button", addNewButton.get(4));
					} else if (Tab.contains("Signatory")) {
						validateAndClick("Edit Button", addNewButton.get(3));
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				try {
					if (Tab.contains("Individual")) {
						validateAndClick("Edit Button", addNewButton.get(0));
					} else if (Tab.contains("Additional Party")) {

						validateAndClick("Edit Button", addNewButton.get(1));
					} else if (Tab.contains("Contact Details")) {
						validateAndClick("Edit Button", addNewButton.get(3));
					} else if (Tab.contains("Signatory")) {
						validateAndClick("Edit Button", addNewButton.get(2));
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return totalTabs;

	}

	public void selectRadioKPWrapper(String expUserName) {

		// span[contains(text(),'ALISON CLARE
		// REED')]//ancestor::table//div[@role="Radio"]
		WebElement expRadio = findAnyWebElement(
				By.xpath("//span[contains(text(),'" + expUserName
						+ "')]//ancestor::table//div[@role='Radio']"), "Radio");
		if (expRadio != null) {
			try {
				validateAndClick(expUserName, expRadio);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void selectKPWithRowNumber(String expUserName,int rowNumber){
		//div[contains(@class,'AOIP_kpIndTableCV')]//table/tbody/tr/td[1]/div[@role='Radio']
		List<WebElement> expRadio = findObjectList(
				By.xpath("//span[contains(text(),'" + expUserName
						+ "')]//ancestor::table//div[@role='Radio']"), "Radio");
		if (expRadio != null) {
			try {
				validateAndClick(expUserName, expRadio.get(rowNumber-1));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void getAndCompareCRAfromAnyPage(String expRisk) {
		switchToCompleteAccntAppFrame(driver);
		WebElement craWele = findAnyWebElement(
				By.xpath("//span[text()='Low' or text()='Medium' or text()='High']"),
				"Risk");
		String actualRisk = null;
		try {
			if (craWele != null) {
				actualRisk = craWele.getText();
				if (expRisk.equalsIgnoreCase(actualRisk)) {
					Logger.LogMessage("Risk is matching");
					//Reporter.log("Risk is matching");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void searchAndClickInWorkflows(String insanceID, String expTask) {
		// input[(contains(@id,'SearchBar'))]
		// a[contains(text(),'NB00086116')][@title]/ancestor::span//a
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement inputTextInSrchBox = driver.findElement(By
					.xpath("//input[(contains(@id,'SearchBar'))]"));
			if (inputTextInSrchBox != null) {
				validateAndSendKeys("Search Box", inputTextInSrchBox, insanceID);

				validateAndClick("Search Pane", inputTextInSrchBox);

				sendEnterKeys(driver, inputTextInSrchBox);
				waitForLoading();
				sleepTime(2);
				waitForLoadingElementInvisibility();

				WebElement linkToCLick = driver.findElement(By
						.xpath("//a[contains(text(),'" + expTask
								+ "')][@title]/ancestor::span//a"));

				waitForElementToAppear("Link To Click", linkToCLick);
				validateAndClick("Reference Link", linkToCLick);
				
				try {
					List<WebElement> allButtons = findObjectList(By.xpath("//button[text()]"), "All Buttons");
					for(WebElement wEle :allButtons){
						if(wEle.getText().equalsIgnoreCase("Claim Task")){
							clickAnybuttonInRBS("Claim Task");
						}
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Logger.LogMessage("Exception occured in clicking Claim Task");
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Exception occured in clicking link");
			e.printStackTrace();
		}
	}

	public void inputInComboBoxRBSContainsWebElement(int wEle,
			String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			List<WebElement> expComboBoxFrame = driver
					.findElements(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.get(wEle).findElement(
						By.xpath(".//input[contains(@id,'ComboBox')]"));
				expTextBox.clear();
				expTextBox.sendKeys(value);
				waitForLoading();
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}

	public String checkStatusInTableForCash(int dynamicTableNumber, int rowNum) {
		// TODO Auto-generated method stub
		// div[@class='Horizontal_Section tableHeader CoachView BPMSection
		// CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]
		// div[last()][contains(@class,'BPMBorder')]/div[1]//span[contains(text(),'omplete')]
		String actualStatus = null;
		List<WebElement> expTable = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTable != null) {
			// get the expected row from table
			// WebElement expRow =
			// expTable.findElement(By.xpath("div[last()][contains(@class,'BPMBorder')]/div["+rowNum+"]"));
			// if(expRow!=null){

			if (expTable.size() != 0) {
				// WebElement expTable
				// =driver.findElement(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1]"));

				WebElement actualStatusEle = expTable
						.get(dynamicTableNumber - 1)
						.findElement(
								By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
										+ rowNum
										+ "]//span[contains(text(),'omplete')]"));
				if (actualStatusEle != null) {
					try {
						actualStatus = actualStatusEle.getText();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}

		return actualStatus;
	}

	public void clickDroDownInRBS(int dynamicTableNumber, int rowNum) {
		List<WebElement> expTable = driver
				.findElements(By
						.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]"));
		if (expTable != null) {

			try {
				WebElement radioToClick = expTable
						.get(dynamicTableNumber - 1)
						.findElement(
								By.xpath(".//div[last()][contains(@class,'BPMBorder')]/div["
										+ rowNum
										+ "]//span[@class='dropDownText']/preceding-sibling::input"));
				validateAndClick("Arrow", radioToClick);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public void clickTabByName(String tabName) {
		// button[text()='Next']
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expTabToClick = findAnyWebElement(
					By.xpath("//span[@class='tabLabel'][text()='" + tabName
							+ "']"), tabName);
			if (expTabToClick != null) {
				validateAndClick(tabName, expTabToClick);
				// doubleClick(buttonText, expButtonToClick);
				Logger.LogMessage("Tab has been clicked---" + tabName);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Tab could not be clicked---" + tabName);
			e.printStackTrace();
		}
	}

	public List<WebElement> getElementsByLocator(String strElement, By locator)
			throws Exception {

		WaitUtils.waitForElement(driver, locator, 30);
		List<WebElement> elements = driver.findElements(locator);
		if (elements.size() > 0) {
			return elements;
		} else {

			ReporterA.reportFailWithSnapshot("Validate if " + strElement
					+ " is present on screen", strElement + " should appear",
					strElement + " is not appearing", driver);
			return null;
		}
	}

	public void callReporterInbetween(TestCase tc1, String actualVal,
			String expValue) {
		try {
			// ReporterA.addStep(tc1,"App Summary","Comparing Values",actualVal,
			// "C:/Snap", expValue);
			ReporterA.reportPassWithSnapshot("Comparing values", actualVal,
					expValue, driver);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void callReporterInbetweenFail(TestCase tc1, String actualVal,
			String expValue) {

		try {
			ReporterA.reportFailWithSnapshot("Comparing values", actualVal,
					expValue, driver);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void checkAndWriteToFile(String keyEtb,String valueEtb) throws IOException{

		String fileName = System.getProperty("user.dir")
				+ "//DynamicData//Data.txt";
		System.out.println("file path is ---" + fileName);
		String line = null;
		final int key = 0;
		final int value = 1;
		FileReader filereader = null;
		BufferedReader bufferfile = null;
		TreeMap<String, String> returnValues = new TreeMap<String, String>();
		try {
			filereader = new FileReader(fileName);
			bufferfile = new BufferedReader(filereader);

			while ((line = bufferfile.readLine()) != null) {

				System.out.println(line);
				if (!line.isEmpty()) {
					String pair[] = line.trim().split("=");
					returnValues.put(pair[key].trim(), pair[value].trim());
				}
			}
			// bufferfile.close();
		} catch (Exception e) {
			Logger.LogMessage("Exception occured in reading file--Please check for location and Data");
		} finally {
			bufferfile.close();
		}
		int totalEtbs = 0;
		// fetch the value
		//return returnValues.get(expKey);
		//ETBIndividual
		for(Map.Entry<String,String> entry : returnValues.entrySet()){

			try {
				if(returnValues.get(keyEtb) != null){
					if(entry.getKey().contains(keyEtb)){
						totalEtbs++;
					}

				}else{
					writeToFileOBAO(keyEtb, valueEtb);
					break;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Total Existing "+keyEtb+"--are--"+totalEtbs);
		if(totalEtbs!=0){
		writeToFileOBAO(keyEtb+totalEtbs,valueEtb);
		}

	
	}

	public void clickLinkFromSideBar(String expLinkName) {
		// div[@id='tasklist_sidebar_widget_target']
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement linkToCLick = driver
					.findElement(By
							.xpath("//div[@id='tasklist_sidebar_widget_target']//a[text()='"
									+ expLinkName + "']"));
			if (linkToCLick != null) {
				validateAndClick(expLinkName, linkToCLick);
				/*
				 * Thread.sleep(4); scrollElementToView(driver, linkToCLick);
				 * 
				 * linkToCLick.click();
				 */

				Logger.LogMessage("Clicking on the Link--" + expLinkName);
			} else {
				Logger.LogMessage("Could not cLick on the Link--" + expLinkName);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Could not cLick on the Link--" + expLinkName);
			e.printStackTrace();
		}

	}

	public void switchToFindAppFrame() {
		switchToIframe(
				driver,
				By.xpath("//iframe[contains(@title,'Find Application')]"));
	}

	public void switchToWindowWithoutClosingNewWindow() {

		try {
			String oldTab = driver.getWindowHandle();
			ArrayList<String> newTab = new ArrayList<String>(
					driver.getWindowHandles());
			newTab.remove(oldTab);
			// change focus to new tab
			driver.switchTo().window(newTab.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Tab switching not done ");
		}

	}

	public void switchToFindAppFrameBB() {
		switchToIframe(driver,
				By.xpath("//iframe[contains(@title,'Find Application')]"));
	}
	
	public String fetchTheSameKPAPByDate(String expAPORKP,String sTestName){
		
		/*ETBIndividual=QZXVD OTCP NBSYTHO 
		ETBAPIndividual=QZXVD OTCP NBSYTHO */
		Map<String, String> tdRow = null;
		//String expectedName = null;
		if(expAPORKP.contains("AP")){
			//expectedName = readFromFile(expAPORKP);			
			tdRow = ExcelUtils.getTestDataRow_BB("AdditionalParty", sTestName);
		}else{
			//expectedName = readFromFile(expAPORKP);
			tdRow = ExcelUtils.getTestDataRow_BB("AdditionalIndividual", sTestName);
		}
		//QZXVD OTCP NBSYTHO (11/09/2009)
		String dobValue = tdRow.get("strDOB");
		return expAPORKP+" ("+dobValue+")";
		
	}
	
	public List<String> fetchSameNameSignatories(String expKPorAP){
		//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]/div/div//span[contains(text(),'QZXVD OTCP')]
		//switchToCompleteAccntAppFrame(driver);
		
		
		List<String> sameNames = new ArrayList<String>();
		List<WebElement> allNames = findObjectList(By.xpath("//div[@class='Horizontal_Section tableHeader CoachView BPMSection CoachView_show'][1]/following-sibling::div[1][not(contains(@class,'hidden'))]/div/div//span[contains(text(),'"+expKPorAP+"')]"), "Names");
		if(allNames!=null){
			for(WebElement wEle:allNames){
				try {
					String ele = wEle.getText();
					checkAndWriteToFile("SAMENAME",ele);
					sameNames.add(ele);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
		}
		
		return sameNames;
		
	}
	
	public List<String> fetchSameNameContacts(String expKPorAP){
		//label[contains(text(),'Please select the Key Principal that will be the')]/..//following-sibling::div//span[text()='▼']/preceding-sibling::input
		WebElement makeListVisible = findAnyWebElement(By.xpath("//label[contains(text(),'Please select the Key Principal that will be the')]/..//following-sibling::div//span[text()='▼']/preceding-sibling::input"), "Visibility of Select Box");
		if(makeListVisible!=null){
			try {
				validateAndClick("Visible List", makeListVisible);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try { 
			expKPorAP = readFromFile(expKPorAP);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<String> sameNames = new ArrayList<String>();
		List<WebElement> allNames = findObjectList(By.xpath("//div[contains(text(),'"+expKPorAP+"')]"), "Names");
		if(allNames!=null){
			for(WebElement wEle:allNames){
				try {
					String ele = wEle.getText();
					checkAndWriteToFile("SAMECONTACT",ele);
					sameNames.add(ele);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
		}
		
		return sameNames;
	}
	
	public void selectRadioInKPForMutiplePages(String expUserName){
		//div[@role='row']/table/tbody/tr/td[2]//span
		List<WebElement> checkUserPage = null;
				
		checkUserPage= findObjectList(By.xpath("//div[contains(@class,'AOIP_kpIndTableCV')]//div[@role='row']/table/tbody/tr/td[2]//span"), "All KP's");
		
		boolean found = false;
		int totalKPs = checkUserPage.size();
		
		if(totalKPs>=8){
			//now find the page in which our KP is hiding
			
			do {
				for (WebElement wELe : checkUserPage) {
					String kpName = wELe.getText();
					if (kpName.equalsIgnoreCase(expUserName)) {
						found = true;
					} 
					if (found) {
						break;
					}
				}
				
				if(found)
					break;
				WebElement moveToNextPage = findAnyWebElement(By.xpath("//div[contains(@class,'AOIP_kpIndTableCV')]//div[contains(@class,'dojoxGridPaginatorStep')]//div[@aria-label='Next Page']"), "Next Page");
				waitForLoadingElementInvisibility();
				try {
					validateAndClick("Next Page", moveToNextPage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 checkUserPage=null;
				 checkUserPage = findObjectList(By.xpath("//div[contains(@class,'AOIP_kpIndTableCV')]//div[@role='row']/table/tbody/tr/td[2]//span"), "All KP's");
				 
				
			} while (!found);
			
		}
		
		/*while(!found){
			//div[contains(@class,'AOIP_kpIndTableCV')]//div[contains(@class,'dojoxGridPaginatorStep')]//div[@aria-label='Next Page']
			WebElement moveToNextPage = findAnyWebElement(By.xpath("//div[contains(@class,'AOIP_kpIndTableCV')]//div[contains(@class,'dojoxGridPaginatorStep')]//div[@aria-label='Next Page']"), "Next Page");
			
			try {
				validateAndClick("Next Page", moveToNextPage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		*/
		WebElement expRadio = findAnyWebElement(By.xpath("//span[contains(text(),'"+expUserName+"')]//ancestor::table//div[@role='Radio']"),"Radio");
		if(expRadio!=null){
			try {
				validateAndClick(expUserName, expRadio);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void sendKeysBySelectingText(String sElementIdentifier,
			WebElement element, String strValue){
		
		if (validateElementPresent(sElementIdentifier, element)) {
			ReporterA.reportPassWithSnapshot(sElementIdentifier
					+ " validate if present ", sElementIdentifier
					+ " should be displayed", sElementIdentifier
					+ " is displayed", driver);
			element.click();
			element.sendKeys(Keys.CONTROL+"a");
			element.sendKeys(Keys.DELETE);
			//element.clear();
			
			element.sendKeys(strValue);
		}
		
	}

	public void clickButtonByIndex(int indexNo,String buttonName){
		List<WebElement> allEles = findObjectList(By.xpath("//button[contains(text(),'"+buttonName+"')]"), buttonName);
		if(allEles!=null){
			
				try {
					validateAndClick(buttonName, allEles.get(indexNo));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
	
	public void inputInUniqTestBoxRBSContains(WebDriver driver,
			String expLabelName, String value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		// label[text()='Please select a
		// brand']//ancestor::div[contains(@id,'Border')][1]

		// div[@class='radioButtonsLabel']//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		// div[@class='radioButtonsLabel']/label[text()='Do you want to create
		// signing
		// groups?']/..//following-sibling::div[contains(@widgetid,'CheckedMultiSelect')]
		try {
			WebElement expComboBoxFrame = driver
					.findElement(By
							.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
									+ expLabelName
									+ "')]/..//following-sibling::div//div[contains(@id,'uniqName')]"));
			if (expComboBoxFrame != null) {

				// validateElementPresent(expLabelName, expComboBoxFrame);
				// scrollElementToView(driver, expComboBoxFrame);
				// highLightElement(driver, expComboBoxFrame);
				WebElement expTextBox = expComboBoxFrame.findElement(By
						.xpath(".//input[contains(@id,'uniqName')]"));
				expTextBox.clear();
				expTextBox.sendKeys(value);
				waitForLoading();
				// validateAndSendKeys(expLabelName, expComboBoxFrame, value);
				Logger.LogMessage("Input in text box---successfull");

				// div[text()='Yes']/preceding-sibling::div/input
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("Input in text box---Not Successfull");
			e.printStackTrace();
		}

	}
	//Unna Xpath
	public String pageheader(String Text) {
		// button[text()='Next']
		try
		{
		waitForLoading();
	
			 WebElement expButtonToClick = findAnyWebElement(By.xpath("//h2[contains(text(),'"+Text+"')]"), Text);					
			String pageheader = expButtonToClick.getText();
				
			/*	WebElement expButtonToClick = findAnyWebElement(
						By.xpath("//span[contains(text(),'"+Text+"')]//..//h2"),Text);
			
				ZambesiTexth2	= expButtonToClick.getText();*/
			
			return pageheader;
					
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			//Logger.LogMessage("Button could not be clicked---" + Text);
			e.printStackTrace();
			return null;
		}
	}
	public void date(WebDriver driver,String expRadioButton) {
		
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
		try {
			WebElement expYesOrNoButton = driver
					.findElement(By
							.xpath("//select[@id='repaymentDate']/option[@value='"+ expRadioButton+ "']"));
			//label[@id='"+ expRadioButton+ "']
			//select[@id='repaymentDate']/option[@value='2']
			
				if (expYesOrNoButton != null) {
					expYesOrNoButton.click();
					ReporterA.reportPassWithSnapshot(expRadioButton
							+ " validate if present ", expRadioButton
							+ "should be displayed", expRadioButton
							+ "is displayed", driver);
				}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void Acctholdernametextbox(WebDriver driver,String spFieldName,String Value) {
		waitForLoading();
		waitForLoadingElementInvisibility(driver);
	
		try {
			WebElement expTextBoxFrame = driver
					.findElement(By
							.xpath("//input[@id='"+spFieldName+"']"));
			
			
			if (expTextBoxFrame != null) {
				
					expTextBoxFrame.clear();
					expTextBoxFrame.sendKeys(Value);
					//validateAndSendKeys(spFieldName,expTextBoxFrame,Value);
					
					waitForLoading();
					Logger.LogMessage("Input in text box---successfull");
				}
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.LogMessage("exception occured while entering value in---"
					+ spFieldName);
			e.printStackTrace();
		}
	}
	public String getapplid(String text)
	{
		String applid;
		try
		{
			WebElement appl=findAnyWebElement(By.xpath("//p[contains(@class,'"+text+"')]"), text);
			applid=appl.getText();
		System.out.println(applid);
			return applid ;
			
			}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
}