package com.rbs.automation.commonutils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

import com.rbs.bpm.automation.bbconnect.objects.TestCase;

public class Logger {

	public static org.apache.log4j.Logger APPLICATION_LOGS = null;
	public static String sAppLogs = GenericUtils.getProperty("Application_Logs");
	public static boolean bAppLogs1;
	public static boolean bAppLogs2 = true;
	static PrintWriter out = null;

	public static void LogMessage(String message) {

		try {
			if (null != TestCase.TestName) {
				message = GenericUtils.getDateTime() + " :: " +  TestCase.TestE2ESetName + " : " + TestCase.TestName + " :" + message;
			}
		} catch (Exception e) {

		}

		System.out.println(message);
		if (APPLICATION_LOGS == null) {
			APPLICATION_LOGS = org.apache.log4j.Logger.getLogger("devpinoyLogger");
			// APPLICATION_LOGS = Logger.getLogger("rootLogger");
		}

		if (sAppLogs.equalsIgnoreCase("true")) {
			APPLICATION_LOGS.debug(message);
		} else {
			bAppLogs1 = true;
		}

		if (bAppLogs1 == true & bAppLogs2 == true) {
			APPLICATION_LOGS
					.debug("Update Application_Logs field in Config.Properties file to <true> to generate Logs");
			bAppLogs2 = false;
		}
	}

	public static void initLogger() {

		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.Jdk14Logger");
		/*Properties props = new Properties();
		try {
			props.load(new FileInputStream("log4j.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PropertyConfigurator.configure(props);*/

		/*
		 * try { out = new PrintWriter(new BufferedWriter(new
		 * FileWriter("c:\\temp\\myfile.txt", true))); } catch (IOException e) {
		 * // TODO Auto-generated catch block e.printStackTrace(); }
		 */
	}

	/*
	 * public static void write(String s){ s = new SimpleDateFormat(
	 * "yyyy_MM_dd hhmmss :: ").format(new Date()) + s; out.println(s );
	 * System.out.println(s); }
	 * 
	 * public static void closeReporter(){ out.close(); }
	 */

}
