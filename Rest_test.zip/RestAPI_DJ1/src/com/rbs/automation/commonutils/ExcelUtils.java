package com.rbs.automation.commonutils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;

import com.rbs.pages.PersonaliseYourQuote;
import com.stepdef.prodFinder.*;

public class ExcelUtils {

	static PrintWriter out = null;
	static BBConnectUtils tcID = new BBConnectUtils();
	public static String BBconnect_WB;
	public static int zd;
	public static int ddb;
	public static  int Ed;
	public static  int result;
	public static  int resultinput;
	 public static int testdata;
	 public static int DatafromDB;
	 public static int zambezicustomerdata;
	 public static int DatafromcoreDB;
	 public static  int resultoutput;

	public static void initReporter() {
		//System.out.println("const");
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(
					"c:\\temp\\myfile.txt", true)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	// credit
	
		private static void createExcelSheet(
				String sWorkBook, String sSheetName, String refernum) {
			
			HSSFRow row = null;
			HSSFSheet sheet = null;
			int sheetRows = 0;
			int rowCols = 0;

			try {
				deleteExcelSheet( sWorkBook,  sSheetName);
				FileInputStream file = new FileInputStream(new File(sWorkBook));

				HSSFWorkbook workbook = new HSSFWorkbook(file);
				
			
				sheet = workbook.createSheet(sSheetName);
				row = sheet.createRow(0);
				
			     HSSFCellStyle style = workbook.createCellStyle();
		    		style.setFillForegroundColor(HSSFColor.YELLOW.index);
		    		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

		    		HSSFFont font = workbook.createFont();
		    		font.setColor(HSSFColor.BLACK.index);
		    		style.setFont(font);
		    		

				
				Cell cell = row.createCell(0);
		        cell.setCellType(cell.CELL_TYPE_STRING);
	            cell.setCellValue("Label Names for Application ID:" + refernum);
	            cell.setCellStyle(style);
	            
	            Cell cell1 = row.createCell(1);
	            cell1.setCellType(cell.CELL_TYPE_STRING);
	            cell1.setCellValue("Data from Zambezi");
	            cell1.setCellStyle(style);
	            
	            Cell cell2 = row.createCell(2);
	            cell2.setCellType(cell.CELL_TYPE_STRING);
	            cell2.setCellValue("Data from DB");
	            cell2.setCellStyle(style);
	            
	            Cell cell3 = row.createCell(3);
	            cell3.setCellType(cell.CELL_TYPE_STRING);
	            cell3.setCellValue("Data from TestData");
	            cell3.setCellStyle(style);
	            
	            Cell cell4 = row.createCell(4);
	            cell4.setCellType(cell.CELL_TYPE_STRING);
	            cell4.setCellValue("Comparison Result");
	            cell4.setCellStyle(style);
	            
	            
	            
	            FileOutputStream opfile1 = new FileOutputStream(new File(sWorkBook));
	            workbook.write(opfile1);
	            
	            opfile1.close();
			}
			catch ( Exception e)
			{
				System.out.println(e);
			}
		}

		public static void getTestDataRow_BBC(String sSheetName) throws Exception{
			String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Pricing.xls"; 
			
			getMapFromExcelforpricing(
					sMasterTDWorkbook, sSheetName);
		}
		public static double rate;
		public static double APR; 
		private static void getMapFromExcelforpricing(String sWorkBook, String sSheetName) throws Exception

		{
			ArrayList<String> colNames = new ArrayList<String>();
			ArrayList<Map<String, String>> mapArray = null;
			HSSFRow row = null;
			HSSFSheet sheet = null;
			int sheetRows = 0;
			int rowCols = 0;

			Map<String, String> rowMap = null;

			try {
				
				FileInputStream file = new FileInputStream(new File(sWorkBook));

				HSSFWorkbook workbook = new HSSFWorkbook(file);
				sheet = workbook.getSheet(sSheetName);
				sheetRows = sheet.getPhysicalNumberOfRows();
				mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);
	            System.out.println(sSheetName);
	            
				row = sheet.getRow(0);
				
				for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
					colNames.add("" + row.getCell(i).getStringCellValue());
				}

				rowCols = colNames.size();
				PersonaliseYourQuote pyq = new PersonaliseYourQuote();
				
				String termstr = pyq.TermSliderValue;
				//System.out.println(termstr);
				String amountstr = pyq.AmountSliderValue;
				//System.out.println(amountstr);
				String riskbandstr = pyq.RiskBand;
				//System.out.println(riskbandstr);
				
				int term = Integer.parseInt(termstr);
				int amount = Integer.parseInt(amountstr);
				int riskband = Integer.parseInt(riskbandstr);
				
				for (int k = 1; k < sheetRows; k++) {

					row = sheet.getRow(k);
				
					
					int	Starttermstr = (int) row.getCell(0).getNumericCellValue();
					int	Endtermstr = (int) row.getCell(1).getNumericCellValue();
					int	StartAmountstr = (int) row.getCell(2).getNumericCellValue();
					int	EndAmountstr = (int) row.getCell(3).getNumericCellValue();
					int	riskbandpristr = (int) row.getCell(4).getNumericCellValue();
					
					/*System.out.println(Starttermstr);
					System.out.println(Endtermstr);
					System.out.println(StartAmountstr);
					System.out.println(EndAmountstr);*/
					
					if(((term>=Starttermstr)&&(term<=Endtermstr)) && ((amount>=StartAmountstr) && (amount<=EndAmountstr)) && (riskband==riskbandpristr))
					{
					rate = (double) row.getCell(5).getNumericCellValue();
					APR = (double) row.getCell(6).getNumericCellValue();
					//System.out.println(APR);
					//System.out.println(rate);
					}
					
			
					
				}
				/*int APRintUI;
				int TotalintUII;
				String APRUI = pyq.APR;
				System.out.println(APRUI);
				String intUI = pyq.TotalinterestLN;
				System.out.println(intUI);
				String TotalintUI = intUI.replaceAll("[%]+", "").trim();
				System.out.println(TotalintUI);
				
				if(APRUI.equalsIgnoreCase("Not Applicable"))
				{
					System.out.println("APR is not applicable");
				}
				else
				{
					APRintUI = Integer.parseInt(APRUI);
				}
				
				TotalintUII = Integer.parseInt(TotalintUI);
				System.out.println(TotalintUII);*/
				
					
			}
		 catch (IOException e) {
			//Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
		}

		}
		public static void Compare_Write(int rowNumber,String sheetname, String Product){
			String sMasterTDWorkbook =System.getProperty("user.dir")+"\\testdata\\DBValidations_E2E22.xls";
			codetoCompare(sMasterTDWorkbook, sheetname,rowNumber,Product);
		}

		private static void codetoCompare(String sMasterTDWorkbook, String sheetname,int rowNumber,String Product) {

			ArrayList<String> colNames = new ArrayList<String>();
			ArrayList<Map<String, String>> mapArray = null;
		    int sheetRows = 0;
		    int rowCols = 0;

		   Map<String, String> rowMap = null;
		   try {
		       FileInputStream file = new FileInputStream(new File(sMasterTDWorkbook));

		       HSSFRow row = null;
		         HSSFSheet sheet = null;
		         int sheetRows1 = 0;
		         int rowCols1 = 0;                      
		                HSSFWorkbook workbook = new HSSFWorkbook(file);
		                sheet = workbook.getSheet(sheetname);
		                sheetRows = sheet.getPhysicalNumberOfRows();
		                     if(sheetname.equalsIgnoreCase("Input Vs AppDB"))
		                     {
		                    	  for (int i = 2; i < sheetRows; i++) 
		                          {
		                    		  row = sheet.getRow(i);
		                              testdata=(rowNumber*2)+rowNumber-1;
		                              DatafromDB=(rowNumber*2)+rowNumber;
		                             String TData= row.getCell(testdata).getStringCellValue();
		                             String DBData = row.getCell(DatafromDB).getStringCellValue();
		                             resultinput=(rowNumber*2)+rowNumber+1;
		                             if(i==6)
		                             {
		                         		String repayacc=StringUtils.right(TData, 4); 
		                         		String dbacc=StringUtils.right(DBData, 4); 
		                         		 if (repayacc.equalsIgnoreCase(dbacc))
		                         		 {
		                         			 Cell cell = row.createCell(resultinput);
		                                     cell.setCellType(cell.CELL_TYPE_STRING);
		                                     
		                                     cell.setCellValue("Pass"); 
		                         		 }
		                         		 else
		                         		 {
		                         		    Cell cell = row.createCell(resultinput);
		                                    cell.setCellType(cell.CELL_TYPE_STRING);
		                                    cell.setCellValue("Fail"); 
		                         		 }
		                             }
		                             else
		                             {
		                             if (TData.equalsIgnoreCase(DBData))
		                             {
		                                  Cell cell = row.createCell(resultinput);
		                                  cell.setCellType(cell.CELL_TYPE_STRING);
		                                  
		                                  cell.setCellValue("Pass");
		                             }
		                             else
		                             {
		                                  Cell cell = row.createCell(resultinput);
		                                  cell.setCellType(cell.CELL_TYPE_STRING);
		                                  cell.setCellValue("Fail");
		                             }
		                              if((TData.equalsIgnoreCase("NA"))&&(DBData.equalsIgnoreCase("NA")))
		                             {
		                            	 Cell cell = row.createCell(resultinput);
		                                 cell.setCellType(cell.CELL_TYPE_STRING);
		                                 
		                                 cell.setCellValue("NA");
		                             }
		                            		
		                             }
		                          }
		                     }
		                     else if(sheetname.equalsIgnoreCase("Zambesi Vs AppDB"))
		                     {
		                    	 
		                    	 zd= (((rowNumber-1)*4)+1)+3-1;
						           ddb= (((rowNumber-1)*4)+2)+3-1;
						           Ed = (((rowNumber-1)*4)+3)+3-1;
						        result= (((rowNumber-1)*4)+4)+3-1; 
						           for (int i = 2; i < sheetRows; i++) 
			                       {
			                       row = sheet.getRow(i);
						           String Zambesidata=row.getCell(zd).getStringCellValue();
		                           String DatafromDB = row.getCell(ddb).getStringCellValue();
		                           String Expecteddata = row.getCell(Ed).getStringCellValue();
		                           if(i==5)
		                           {
		                        	   if(Zambesidata.equalsIgnoreCase(DatafromDB))
					        		   {
					        	   Cell cell = row.createCell(result);
		                           cell.setCellType(cell.CELL_TYPE_STRING); 
		                           cell.setCellValue("Pass");
					        		   }
					           
					           else
					           {
					        	     Cell cell = row.createCell(result);
		                             cell.setCellType(cell.CELL_TYPE_STRING);
		                             cell.setCellValue("Fail");  
					           }
					           if((Zambesidata.equalsIgnoreCase("NA"))&&(DatafromDB.equalsIgnoreCase("NA")))
		                       {
		                      	 Cell cell = row.createCell(result);
		                           cell.setCellType(cell.CELL_TYPE_STRING);
		                           cell.setCellValue("NA");
		                       }  
		                           }
		                           else
		                           {
						           if((Zambesidata.equalsIgnoreCase(DatafromDB))&&(Expecteddata.equalsIgnoreCase(DatafromDB)))
						        		   {
						        	   Cell cell = row.createCell(result);
		                               cell.setCellType(cell.CELL_TYPE_STRING); 
		                               cell.setCellValue("Pass");
						        		   }
						           
						           else
						           {
						        	     Cell cell = row.createCell(result);
		                                 cell.setCellType(cell.CELL_TYPE_STRING);
		                                 cell.setCellValue("Fail");  
						           }
						           if((Zambesidata.equalsIgnoreCase("NA"))&&(DatafromDB.equalsIgnoreCase("NA"))&&(Expecteddata.equalsIgnoreCase("NA")))
		                           {
		                          	 Cell cell = row.createCell(result);
		                               cell.setCellType(cell.CELL_TYPE_STRING);
		                               cell.setCellValue("NA");
		                           }
		                           }
			                          }
						      
		                     }
		                     
		                     else 
		                     {
		                    	  for (int i = 2; i < sheetRows; i++)
		           	             {
		                    	 row = sheet.getRow(i);
		                    	 zambezicustomerdata=(rowNumber*2)+rowNumber-1;
		                    	 DatafromcoreDB=(rowNumber*2)+rowNumber;
		                    	 String CustomerData= row.getCell(zambezicustomerdata).getStringCellValue();
		                         String DBcoreData = row.getCell(DatafromcoreDB).getStringCellValue();
		                    	 resultoutput=(rowNumber*2)+rowNumber+1;
		                         if(i==4)
		                          {
		                     		String repayfund=StringUtils.right(CustomerData, 4); 
		                     		String dbrepayfund=StringUtils.right(DBcoreData, 4); 
		                     		 if (repayfund.equalsIgnoreCase(dbrepayfund))
		                     		 {
		                     			 Cell cell = row.createCell(resultoutput);
		                                 cell.setCellType(cell.CELL_TYPE_STRING);
		                                 
		                                 cell.setCellValue("Pass"); 
		                     		 }
		                     		 else if((repayfund.equalsIgnoreCase("NA"))&&(dbrepayfund.equalsIgnoreCase("NA")))
		                             {
		                              	 Cell cell = row.createCell(result);
		                                   cell.setCellType(cell.CELL_TYPE_STRING);
		                                   cell.setCellValue("NA");
		                               }  
		                     		 else
		                     		 {
		                     		    Cell cell = row.createCell(resultoutput);
		                                cell.setCellType(cell.CELL_TYPE_STRING);
		                                cell.setCellValue("Fail"); 
		                     		 }
		                         }
		                    	 else
		                         {
		                         if (CustomerData.equalsIgnoreCase(DBcoreData))
		                         {
		                              Cell cell = row.createCell(resultoutput);
		                              cell.setCellType(cell.CELL_TYPE_STRING);
		                              
		                              cell.setCellValue("Pass");
		                         }
		                         else if((CustomerData.equalsIgnoreCase("NA"))&&(DBcoreData.equalsIgnoreCase("NA")))
		                         {
		                          	 Cell cell = row.createCell(result);
		                               cell.setCellType(cell.CELL_TYPE_STRING);
		                               cell.setCellValue("NA");
		                           } 
		                         else
		                         {
		                              Cell cell = row.createCell(resultoutput);
		                              cell.setCellType(cell.CELL_TYPE_STRING);
		                              cell.setCellValue("Fail");
		                         }
		                    	 
		                     }           
		                     }
		                     }
		                     FileOutputStream opfile = new FileOutputStream(new File(sMasterTDWorkbook));
		                     workbook.write(opfile);  
		                     opfile.close();      
		  }
		catch( Exception e) {

		       e.printStackTrace();
		}
		}

		  

		private static void deleteExcelSheet(String sWorkBook, String sSheetName)
		{
			HSSFRow row = null;
			HSSFSheet sheet = null;
			int sheetRows = 0;
			int rowCols = 0;
			try
			{
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			
			int index = 0;

			HSSFSheet sheetold = workbook.getSheet(sSheetName);
			if(sheetold != null)   {
			    index = workbook.getSheetIndex(sheetold);
			    workbook.removeSheetAt(index);
			    FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
	            workbook.write(opfile);
	            opfile.close();
			}
			}
			catch ( Exception e)
			{
				System.out.println(e);
			}
		}
		

	public static void createExcelSheetMethod(String sSheetName, String refernum			) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_DBValidationCredit.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		createExcelSheet(
				sMasterTDWorkbook, sSheetName,refernum);

		
	}
	

	// credit
	
		public static void setTestDataRow_BB_Writecredit(String sSheetName,
				String value, int rownum, int colnum) {

			String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_DBValidationCredit.xls"; 

			// load testdata workbook's getting started sheet into HashMap
			 WriteToExcel(
					sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

			
		}
		
	public static void write() {
		out.println("the text");
		System.out.println("in write");
	}

	public static void closeReporter() {
		out.close();
	}

	public static Map<String, String> getTestDataRow(String sSheetName,
			String sTestName, int iRow) {
		String sMasterTDWorkbook = GenericUtils
				.getProperty("masterTestDataWorkbook");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(
				sMasterTDWorkbook, sSheetName, sTestName);

		return tdRows.get(iRow);
	}

	public static Map<String, String> getTestDataRow_BB(String sSheetName,
			String sTestName) {
		String region = ProdFinderSD.Reg_Brand;
		workbook(region);
		//String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\BBconnectRegrSce01.xls"; 
		//String expSheetName = tcID.getTheSheetName(sTestName);
		//String sMasterTDWorkbook = "C:\\BBconnect_E2E\\testdata\\BBconnectRegrSce01.xls";
		//String sMasterTDWorkbook = "C:\\BBconnect_E2E\\testdata\\BBconnectRBSRegrSceE2E.xls";
		// String sMasterTDWorkbook =
		// GenericUtils.getProperty("BusinessBanking");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(
				BBconnect_WB, sSheetName, sTestName);

		return tdRows.get(0);
	}
	//to get from service data sheet
	public static Map<String, String> getTestDataRow_Service(String sSheetName,
			String sTestName) {
		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\DJ1 Result.xls"; 
		
		ArrayList<Map<String, String>> tdRows = getMapFromExcelService(
				sMasterTDWorkbook, sSheetName, sTestName);

		return tdRows.get(0);
	}
	
	public static void workbook(String Reg)
	{
		if(Reg.contains("NWB"))
		{
			BBconnect_WB = System.getProperty("user.dir") + "\\testdata\\BBconnectRegrSce01_NWB.xls"; 
		}
		else if(Reg.contains("RBS"))
		{
			BBconnect_WB = System.getProperty("user.dir") + "\\testdata\\BBconnectRegrSce01_RBS.xls"; 
		}
	}
	
	public static void setTestDataRow_BB_Write(String sSheetName,
			String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AssistedJourney.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		 WriteToExcel(
				sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

		
	}
	
	public static void setTestDataRow_BB_Write_appid(String sSheetName,
			String value, int rownum, int colnum) {

		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AppDetails.xls"; 

		// load testdata workbook's getting started sheet into HashMap
		 WriteToExcel(
				sMasterTDWorkbook, sSheetName, value,  rownum, colnum);

		
	}
	
	private static void WriteToExcel(
            String sWorkBook, String sSheetName, String respval, int rownum, int colnum) {
     ArrayList<String> colNames = new ArrayList<String>();
     ArrayList<Map<String, String>> mapArray = null;
     
     int sheetRows = 0;
     int rowCols = 0;

     Map<String, String> rowMap = null;

     try {
            FileInputStream file = new FileInputStream(new File(sWorkBook));

            HSSFWorkbook workbook = new HSSFWorkbook(file);
            HSSFSheet sheet = workbook.getSheet(sSheetName);
            HSSFRow row;
            if(colnum==0)
            {
                  row  = sheet.createRow(rownum);
            }
            else
            {
            	 row = sheet.getRow(rownum);
            }
            
             Cell cell = row.createCell(colnum);
            
            cell.setCellType(cell.CELL_TYPE_STRING);
            //System.out.println(respval);
            cell.setCellValue(respval);
          
            
            FileOutputStream opfile = new FileOutputStream(new File(sWorkBook));
            workbook.write(opfile);
            
            opfile.close();
            
     }
catch (FileNotFoundException e) {
            
            e.printStackTrace();
     } catch (IOException e) {
     
            e.printStackTrace();
     }
     
}
	

	public static Map<String, String> getTestDataRow_BBConnect(String sSheetName,
			String sTestName) {
		String sMasterTDWorkbook = System.getProperty("user.dir") + "\\testdata\\Result_AppDetails.xls"; 
		//String expSheetName = tcID.getTheSheetName(sTestName);
		//String sMasterTDWorkbook = "C:\\BBconnect_E2E\\testdata\\ApplicationDetails.xls";
		// String sMasterTDWorkbook =
		// GenericUtils.getProperty("BusinessBanking");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcelPRCRE(
				sMasterTDWorkbook, sSheetName, sTestName);

		return tdRows.get(0);
	}
	
	public static Map<String, String> getTestDataRow_PV(String sSheetName,
			String sTestName, String secname, String sectype) {

		String expSheetName = tcID.getTheSheetName(sTestName);
		String sMasterTDWorkbook = GenericUtils.getProperty(expSheetName);
		// String sMasterTDWorkbook =
		// GenericUtils.getProperty("BusinessBanking");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcelPV(
				sMasterTDWorkbook, sSheetName, sTestName, secname,sectype);

		return tdRows.get(0);
	}


	public static Map<String, String> getTestDataRow_WorkflowBB(
			String sSheetName, String sTestName) {
		String sMasterTDWorkbook = GenericUtils.getProperty("BBWorkflow");

		// load testdata workbook's getting started sheet into HashMap
		ArrayList<Map<String, String>> tdRows = getMapFromExcel(
				sMasterTDWorkbook, sSheetName, sTestName);

		return tdRows.get(0);
	}

	private static String getCellValue(HSSFCell cell) {

		String value = null;

		switch (cell.getCellType()) {

		case Cell.CELL_TYPE_BOOLEAN:

			value = "" + cell.getBooleanCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:

			double floating_value = cell.getNumericCellValue();
			double fractionalPart = floating_value % 1;
			long integralPart = (long) Math.floor(floating_value);

			if (fractionalPart >= 0.0001)
				value = "" + floating_value;
			else
				value = "" + integralPart;

			//
			break;
		case Cell.CELL_TYPE_STRING:

			value = cell.getStringCellValue();
			break;
		}

		return value;
	}

	private static ArrayList<Map<String, String>> getMapFromExcel(
			String sWorkBook, String sSheetName, String sTCName) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);

			row = sheet.getRow(0);

			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}

			rowCols = colNames.size();

			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);

				if (row.getCell(0).getStringCellValue()
						.equalsIgnoreCase(sTCName)
						&& row.getCell(1).getStringCellValue()
								.equalsIgnoreCase("Y")) {

					rowMap = new LinkedHashMap<String, String>(rowCols);

					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						String value = "" + getCellValue(row.getCell(c));
						rowMap.put(key, value);
					}

					mapArray.add(rowMap);

				}

			}
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
		} catch (IOException e) {
			Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
		}
		return mapArray;
	}
	
	private static ArrayList<Map<String, String>> getMapFromExcelService(
			String sWorkBook, String sSheetName, String sTCName) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);

			row = sheet.getRow(1);

			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}

			rowCols = colNames.size();
			for (int i = 2; i < sheetRows; i++) {

				row = sheet.getRow(i);
				if(row.getCell(0)!=null){
				if (row.getCell(0).getStringCellValue()
						.equalsIgnoreCase(sTCName)
						) {
					rowMap = new LinkedHashMap<String, String>(rowCols);

					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						
						String value = "" + getCellValue(row.getCell(c));
						//System.out.println("-----------key--------"+c+"\t"+key+"\t"+value);
						rowMap.put(key, value);
					}
					System.out.println(rowMap.get("DB ID"));
					mapArray.add(rowMap);

				}
				}

			}
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
		} catch (IOException e) {
			Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
		}
		return mapArray;
	}
	
	private static ArrayList<Map<String, String>> getMapFromExcelPRCRE(
			String sWorkBook, String sSheetName, String sTCName) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);

			row = sheet.getRow(0);

			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}

			rowCols = colNames.size();

			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);

				if (row.getCell(0).getStringCellValue()
						.equalsIgnoreCase(sTCName)
						) {

					rowMap = new LinkedHashMap<String, String>(rowCols);

					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						String value = "" + getCellValue(row.getCell(c));
						rowMap.put(key, value);
					}

					mapArray.add(rowMap);

				}

			}
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
		} catch (IOException e) {
			Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
		}
		return mapArray;
	}



	private static ArrayList<Map<String, String>> getMapFromExcelPV(
			String sWorkBook, String sSheetName, String sTCName, String secname, String sectype) {
		ArrayList<String> colNames = new ArrayList<String>();
		ArrayList<Map<String, String>> mapArray = null;
		HSSFRow row = null;
		HSSFSheet sheet = null;
		int sheetRows = 0;
		int rowCols = 0;

		Map<String, String> rowMap = null;

		try {
			FileInputStream file = new FileInputStream(new File(sWorkBook));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheet(sSheetName);
			sheetRows = sheet.getPhysicalNumberOfRows();
			mapArray = new ArrayList<Map<String, String>>(sheetRows - 1);

			row = sheet.getRow(0);

			for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
				colNames.add("" + row.getCell(i).getStringCellValue());
			}

			rowCols = colNames.size();

			for (int i = 1; i < sheetRows; i++) {

				row = sheet.getRow(i);

				if (row.getCell(0).getStringCellValue()
						.equalsIgnoreCase(sTCName)
						&& row.getCell(1).getStringCellValue()
								.equalsIgnoreCase("Y")&&row.getCell(2).getStringCellValue()
								.equalsIgnoreCase(secname)&&row.getCell(3).getStringCellValue()
								.equalsIgnoreCase(sectype)) {

					rowMap = new LinkedHashMap<String, String>(rowCols);

					for (int c = 0; c < rowCols; c++) {
						String key = colNames.get(c);
						String value = "" + getCellValue(row.getCell(c));
						rowMap.put(key, value);
					}

					mapArray.add(rowMap);

				}

			}
			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			Logger.LogMessage("File Not found--check the filename");
			e.printStackTrace();
		} catch (IOException e) {
			Logger.LogMessage("IO Exception in excel--check the path");
			e.printStackTrace();
		}
		return mapArray;
	}

	// Get row count
	public static int getTestDataRowCount(String sSheetName, String sTestName) {

		String sMasterTDWorkbook = GenericUtils
				.getProperty("masterTestDataWorkbook");

		// load testdata workbook's getting started sheet into HashMap

		ArrayList<Map<String, String>> tdRows = getMapFromExcel(
				sMasterTDWorkbook,

				sSheetName, sTestName);

		return tdRows.size();

	}

}
