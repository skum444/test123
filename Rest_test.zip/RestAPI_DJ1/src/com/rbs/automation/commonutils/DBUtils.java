package com.rbs.automation.commonutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class DBUtils {

	static Connection conn;

	public static void initConnection() {

		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String database = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+ GenericUtils.getProperty("DBPath")+";";
			conn = DriverManager.getConnection(database, "", "");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(){
		DBUtils.initConnection();
		getResultSetFromSQL("select * from sanity");
	}

	public static ResultSet getResultSetFromSQL(String sql) {

		String selTable = sql;
		
		//"SELECT Top 1 UserID, Password FROM UserCredentials where UserRole = 'Product Management Professional'";
		Statement s = null;
		ResultSet rs = null;
		
			try {
					if (! conn.isClosed())
					{
	
						s = conn.createStatement();
						s.execute(selTable);
						rs = s.getResultSet();
					}
					else
					{
						throw new Exception("Connection is not opened");
					}
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		return rs;
	}

	public static void closeConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
