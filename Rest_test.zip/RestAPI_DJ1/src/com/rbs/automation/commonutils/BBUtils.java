package com.rbs.automation.commonutils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.google.common.base.Function;
import com.rbs.pages.BasePage;

public class BBUtils extends BasePage {
	
	BBConnectUtils commoncomps = new BBConnectUtils();

		public void checkIfValuePresentSelectBox(WebDriver driver, String expLabelName,
				String value) {
			waitForLoading();
			//waitForLoadingElementInvisibility(driver);
			try {
				WebElement expTextBoxFrame = driver
						.findElement(By
								.xpath("//div[@class='selectLabel']/label[contains(text(),'"
										+ expLabelName
										+ "')]/..//following-sibling::div/div[contains(@id,'FilteringSelect')]/div[contains(@class,'dijitInputField')]"));
				if (expTextBoxFrame != null) {
					WebElement expTextField = expTextBoxFrame.findElement(By
							.xpath(".//input[not(@type='hidden')]"));
					if (expTextField != null) {

						validateAndSendKeys(expLabelName, expTextField, value);
						WebElement checkIfValueExists = expTextField.findElement(By.xpath("ancestor::div[2]"));
						
						try {
							if(!checkIfValueExists.getAttribute("class").contains("dijitError")){
								ReporterA.reportPassWithSnapshot("Select Box", value, "Not Present", driver);
								//Assert.assertTrue(true);
							}else{
								ReporterA.reportFailWithSnapshot("Select Box", value, "Present---Failed", driver);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						waitForLoading();
						Logger.LogMessage("Input in text box---successfull");
					}
					// div[text()='Yes']/preceding-sibling::div/input
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("exception occured while entering value in---"
						+ expLabelName);
				e.printStackTrace();
			}
		
	}
		
		public void verifyAbsenceOfButton(String expButton){
			List<WebElement> allButton = commoncomps.findObjectList(By.xpath("//button"), "All Buttons");
			boolean found = false;
			if(allButton!=null){
				for(WebElement nav:allButton){
					if(nav.getText().equalsIgnoreCase(expButton)){
						found = true;
						
					}
				}
				
				if(found){
					try {
						ReporterA.reportFailWithSnapshot("Check BUtton If Absent", expButton, "Is Present", driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else{
					ReporterA.reportPassWithSnapshot("Check BUtton If Absent", expButton, "Not Present", driver);
				}
			}
		}
		
		public void verifyPresenceOfButton(String expButton){
			List<WebElement> allButton = commoncomps.findObjectList(By.xpath("//button"), "All Buttons");
			boolean found = false;
			if(allButton!=null){
				for(WebElement nav:allButton){
					if(nav.getText().equalsIgnoreCase(expButton)){
						found = true;
						
					}
				}
				
				if(found){
					ReporterA.reportPassWithSnapshot("Check BUtton If Prsent", expButton, "Not Present", driver);
				}else{
					try {
						ReporterA.reportFailWithSnapshot("Check BUtton If present", expButton, "Not Present", driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		public void checkIfInvalidValueAcceptedCombo(String expLabelName, String value) {
			waitForLoading();
			commoncomps.waitForLoadingElementInvisibility(driver);
	
			try {
				WebElement expComboBoxFrame = driver
						.findElement(By
								.xpath("//div[contains(@class,'textLabel')]/label[contains(text(),'"
										+ expLabelName
										+ "')]/..//following-sibling::div//div[contains(@id,'ComboBox')]"));
				if (expComboBoxFrame != null) {

				
					validateAndSendKeys(expLabelName, expComboBoxFrame, value);
					
					WebElement checkIfValueExists = expComboBoxFrame.findElement(By.xpath("ancestor::div[2]"));
					
					try {
						if(checkIfValueExists.getAttribute("class").contains("dijitError")){
							ReporterA.reportPassWithSnapshot("Invalid Value", value, "Not Accepted", driver);
							//Assert.assertTrue(true);
						}else{
							ReporterA.reportFailWithSnapshot("Invalid Value", value, "Accepted", driver);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Logger.LogMessage("Input in text box---successfull");

					// div[text()='Yes']/preceding-sibling::div/input
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.LogMessage("Input in text box---Not Successfull");
				e.printStackTrace();
			}

		}
	
}