package com.rbs.automation.commonutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.relique.jdbc.csv.CsvDriver;

public class CSVDBUtils {

	static Connection conn;
	static Statement stmt = null;
	static ResultSet rs = null;

	public static void initConnection() {
		
		try {
			
			Class.forName("org.relique.jdbc.csv.CsvDriver");
		    Connection conn = DriverManager.getConnection("jdbc:relique:csv:" + "testdata");
		    stmt=conn.createStatement();
		      
		      
			//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			//String database = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ="
			//				+ GenericUtils.getProperty("DBPath")+";";
		    
			//conn = DriverManager.getConnection(database, "", "");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws SQLException{
		CSVDBUtils.initConnection();
		ResultSet rs1 = getResultSetFromSQL("select * from SanityTC01  Where RunMode='Y' and ENV='SIT'");
		
		ResultSetMetaData md = rs1.getMetaData();
		System.out.println( md.getColumnCount());
		
		while (rs1.next()){
			
			
		};
	}

	public static ResultSet getResultSetFromSQL(String sql) {
		Logger.LogMessage("Execution Query in csv" + sql);
		String selTable = sql;
		ResultSet rset = null;
		
		//"SELECT Top 1 UserID, Password FROM UserCredentials where UserRole = 'Product Management Professional'";
		
		
			try {
					if(true)// (! conn.isClosed()) // removed for csv enablement
					{
	
						//stmt = conn.createStatement();
						stmt.execute(selTable);
						rset = stmt.getResultSet();
					}
					/*else
					{
						throw new Exception("Connection is not opened");
					}*/
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		return rset;
	}

	public static void closeConnection() {
		try {
			if (null!=conn) conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
