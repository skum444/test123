package com.rbs.automation.commonutils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.commons.lang3.StringUtils;

import com.rbs.pages.Accountdetails;
import com.rbs.pages.ConfirmCreditCheckDBValidation;
import com.rbs.pages.FeederAccount;
import com.rbs.pages.PersonaliseYourQuote;
import com.stepdef.prodFinder.ProdFinderSD;

public class OracleDBUtils 
{
   	public static String BorrowingPurpose;
   	public static String BorrowingAmount;
   	public static String BorrowingTerm;
   	public static String SortCode;
   	public static String Accountnumber;
   	public static String SortCodeToReceiveFunds;
   	public static String AccountNumToReceiveFunds;
   	public static String SortCodeToRepayFunds;
   	public static String AccountNumToRepayFunds;
   	public static String customerName;
   	public static String RepaymentDate;
   	public static String CallBackFlag;
   	public static String EMailID;
   	public static String TelephoneNumber;
   	public static String Countrycode;
   	public static String APR;
   	public static String InterestRate;
   	public static String MonthlyPayments;
   	public static String TotalInterest;
   	public static String TotalRepayments;
   	public static String interestRate;
   	public static String Fee;
   	public static String Preferredcontactno;
   	public static String callbackreason;
   	public static String ShadowLimit;
   	public static String Lombardcardurl;
    public static String BIN;
    public static String CIN;
    
  //entity indiv table
  		public static String fullName = null;
  		public static String firstName = null;
  		public static String middleName = null;
  		public static String surName = null;
  		public static String ContactNO = null;
  		public static String electText = null;
  		public static String DOB = null;
  		public static String cinCreditGrade = null;
  		public static String cinSplCreditGrade = null;
  		public static String cinFraudMarker = null;
  		public static String politicallyexposed = null;
  		public static String cinKYC = null;
  		public static String cinRCRMarker = null;
  		public static String kpindex = null;
  		public static String countryCode = null;
  		
  	//party tb
  			public static String forecastTurnover = null;
  			public static String actualTurnover = null;
  			public static String binKYC = null;
  			public static String binCreditGrade = null;
  			public static String binSplCreditGrade = null;
  			public static String binFraudMarker = null;
  			public static String totAggBusinessDebt = null;
  			public static String binShadowLimit = null;
  			public static String netProfit = null;
  			
  			//KP credit decision
  			public static String powercurveID = null;
  			public static String KPAge = null;
  			public static String powercurveKPOutputSequence = null;
  			
  			//bus credit decision
  			public static String decisionText = null;
  			public static String powercurveBusinessOPSeq = null;
  			public static String affortabilityInd = null;
  			public static String existingBusMonthlyLoan = null;
  			public static String existingBusODavDebt = null;
  			public static String enhancedBLEdecision = null;
  			public static String palstrategy = null;
  			
  			
  			
  			//party addr tb
  			public static String bin = null;
  			public static String addrCityBI = null;
  			public static String countryBI = null;
  			public static String AL1BI = null;
  			public static String AL2BI = null;
  			public static String AL3BI = null;
  			public static String AL4BI = null;
  			public static String AL5BI = null;
  			public static String postcodeBI = null;
  			
  			//entity addr tb
  			public static String addrCityKP = null;
  			public static String countryKP = null;
  			public static String AL1KP = null;
  			public static String AL2KP = null;
  			public static String AL3KP = null;
  			public static String AL4KP = null;
  			public static String AL5KP = null;
  			public static String postcodeKP = null;
  			public static String postcodeind = null;
  			
  			//bin account DTLS
  			public static String binAccNO = null;
  			public static String binSortCode = null;
  			public static String companyName = null;
  			public static String compRegNO = null;
  			public static String entityType = null;
  			public static String binRCRMArker = null;
  			public static String reasontext = null;
  		
  			//context tb
  			public static String dbid = null;
  			public static String cin = null;
  			
  			//static declaration for creditdbvalidation page
  			
  			public static String DBId = null;
  			public static String projectedturnover = null;
  			public static String Netprofit = null;
  			public static String TotAggBusDebt = null;
  			public static String FraudMarkerBIN = null;
  			public static String FraudMarkerCIN = null;
  			public static String KYCBIN = null;
  			public static String KYCCIN = null;
  			public static String PEP = null;
  			public static String dob = null;
  			public static String CINCreditGrade = null;
  			public static String BINCreditGrade = null;
  			public static String BINCRMMarker = null;
  			public static String CINCRMMarker = null;
  			 public static String COR = null;
  			 public static String EntityType = null;
  			
  			 public static Connection connection=null;
  String sTestDataSheetName = "AppDetails";
  String qTestDataSheetName= "LoginPage1";
  private String pTestDataSheetName = "PersonaliseYourQuote";
	private String rTestDataSheetName = "PurposeOfBorrowing";
	private String xTestDataSheetName = "Account details";
	private String tTestDataSheetName = "welcome";
	BBConnectUtils commoncomps = new BBConnectUtils();
 	PersonaliseYourQuote pyq = new PersonaliseYourQuote();
   	Accountdetails ad = new Accountdetails();	
   	ConfirmCreditCheckDBValidation cdb = new ConfirmCreditCheckDBValidation();
	public HSSFWorkbook wb;
	
	
	public static Connection getConnection() throws Exception
	{ 
	   
	   Logger.LogMessage("Creating oracle connection");
      try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Logger.LogMessage("Oracle JDBC Driver Registered!");
			
			//connection string to go to property file
			String Reg = ProdFinderSD.Reg_Brand;
			//QA Connection String
			if(Reg.contains("QA"))
			{
           connection = DriverManager.getConnection(
            		"jdbc:oracle:thin:@vstcogb02d.server.rbsgrp.mde:1535:COGBLN2"
 					, "LND_APP_USER_RO",
			"L3nd09z3rR0#2346");
			}
			else if (Reg.contains("NFT"))
        // NFT Connection String
			{ connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@scan-st-n-285.server.rbsgrp.mde:1565/NOGBLEN1NFTE"
         					, "LND_APP_USER_RO",
					"L3nd09z3rR0#0001"); 
			}
			else if (Reg.contains("PSE"))
			{
			// pre-NFT conenction string
			connection = DriverManager.getConnection("jdbc:oracle:thin:@vstblod01n.server.rbsgrp.mde:1535/DOGBBPD1"
  					, "LND_APP_USER_RO",
				"L3nd09z3rR0#9881"); 
			}
            System.out.println("Connected....."); 
           
			//ReporterA.reportPass("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 ", "Should be successful",
					//"as expected");
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			ReporterA.reportFail("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 "
					, "Should be successful"
					, "Unable to connect (ClassNotFoundException)"
					+ e.getStackTrace() );
			
		} catch (Exception e) {
			e.printStackTrace();
			ReporterA.reportFail("Connect to Oracle DB vstcogb02d.server.rbsgrp.mde:1535:COGBLN2 "
					, "Should be successful"
					, "Unable to connect (Exception)"
					+ e.getStackTrace() );
			
		}  
	
    	return connection;
		
	}

	
	public void dbvalidationCreditAI(String ApplicationID,String decisiontext) throws Exception
	{
		System.out.println("ApplicationID " + ApplicationID);
		System.out.println("decisiontext "+ decisiontext);
		String AIvaluetb = "select affordability_ind from LND_APP_OWNER.LND_BUS_CREDIT_DECISION_OP_TB where Decision_text='"+decisiontext+"' and APPL_ID ='"+ApplicationID+"'";
		Connection connection=OracleDBUtils.getConnection();
		ResultSet resultSet=OracleDBUtils.getStatement(connection,AIvaluetb);
		
		while(resultSet.next())
		 {
			affortabilityInd = resultSet.getString("affordability_ind");
		 }
	}
	
	
	public void reasontextUpdate(String ApplicationID ,  String sTestName,int rowcount) throws Exception
	{
		
		Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
				qTestDataSheetName, sTestName);
		String sqlrefinfo = "select REASON_TEXT from LND_APP_OWNER.LND_REASON_TB where APPL_ID = '"+ApplicationID+"'";
		String sqlcount = "select count(*) as rowcount from LND_APP_OWNER.LND_REASON_TB where APPL_ID = '"+ApplicationID+"'";
		String Reasontxt = null;
		String APPL_ID = null;
		Connection connection=OracleDBUtils.getConnection();
		ResultSet resultSet=OracleDBUtils.getStatement(connection,sqlrefinfo);
		ResultSet resultSetcount=OracleDBUtils.getStatement(connection,sqlcount);
		int rowcount1=0;
		/*while(resultSetcount.next())
		 {
			rowcount1 = resultSet.getInt("rowcount");
			
		 }*/
		String Reason_txt = null;
		int navig = 1;
		while(resultSet.next())
		 {
			Reasontxt = resultSet.getString("REASON_TEXT");
			if(!(navig==1))
			{
			Reason_txt = Reason_txt + "," + Reasontxt;
			}
			else if (navig==1)
			{
				Reason_txt=Reasontxt;
			}
			navig++;
		 }
		ExcelUtils.setTestDataRow_BB_Write("AssitedJourney",sTestName,rowcount,0);
		ExcelUtils.setTestDataRow_BB_Write("AssitedJourney",tdqRow.get("Customer Number"),rowcount,1);
		ExcelUtils.setTestDataRow_BB_Write("AssitedJourney",ApplicationID,rowcount,2);
		ExcelUtils.setTestDataRow_BB_Write("AssitedJourney",Reason_txt,rowcount,3);
		
		
		
	}
	
	public void dbvalidationCredit(String ApplicationID,String sTestName,int rowcount) throws Exception
	{
		
		sTestDataSheetName = sTestName+"_credit";
		Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
				qTestDataSheetName, sTestName);
		String sqlentitytb = "select indiv_full_name,indiv_first_name,indiv_middle_name,indiv_surname,contact_no,elect_addr_text,DOB,cin_credit_grade,cin_spcl_credit_grade, cin_fraud_marker_code, politically_exposed,cin_kyc,cin_rcr_marker,kp_ind,tel_country_code from LND_APP_OWNER.LND_entity_indiv_tb where APPL_ID = '"+ApplicationID+"'";
		String sqlpartytb = "select forecast_turnover,actual_turnover, bin_kyc,bin_credit_grade,bin_spcl_credit_grade,bin_fraud_marker_code,tot_agg_buss_debt,bin_shadow_limit,net_profit from LND_APP_OWNER.LND_PARTY_TB where APPL_ID = '"+ApplicationID+"'";
		String sqlkpdecisiontb = "select powercurve_id,kp_age,powercurve_kp_output_seq from LND_APP_OWNER.LND_KP_CREDIT_DECISION_OP_TB where APPL_ID = '"+ApplicationID+"'";
		String sqlbusdecisiontb = "select decision_text,powercurve_bus_output_seq, affordability_ind, existing_bus_monthly_loan_rep,existing_bus_od_av_debit_bal,enhanced_ble_decision_ind,pal_strategy_flag from LND_APP_OWNER.LND_BUS_CREDIT_DECISION_OP_TB where APPL_ID = '"+ApplicationID+"'";
		String sqlpartyaddrtb = "select bin,addr_city,addr_country,addr_line_1_txt,addr_line_2_txt,addr_line_3_txt,addr_line_4_txt,addr_line_5_txt,addr_postcode from LND_APP_OWNER.LND_PARTY_ADDR_TB where APPL_ID = '"+ApplicationID+"'";
		String sqlentityaddrtb = "select addr_city,addr_country,addr_line_1_txt, addr_line_2_txt,addr_line_3_txt,addr_line_4_txt,addr_line_5_txt,addr_postcode, postcode_ind from lnd_app_owner.LND_ENTITY_ADDR_TB where appl_id = '"+ApplicationID+"'";
		String sqlbinacctb = "Select bin_acc_no,bin_sort_code,company_name,cmpny_reg_no,entity_typ,bin_rcr_marker from LND_app_Owner.LND_BIN_ACCOUNT_DTLS_TB where appl_id='"+ApplicationID+"'";
		String sqlreasontb = "select REASON_TEXT from LND_APP_OWNER.LND_REASON_TB where appl_id='"+ApplicationID+"'";
		String sqlcontexttb = "select bin,cin,dbid from LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB where appl_id='"+ApplicationID+"'";
	
		
		//String APPL_ID = null;
		Connection connection=OracleDBUtils.getConnection();
		ResultSet resultSet=OracleDBUtils.getStatement(connection,sqlentitytb);
		ResultSet resultSet1=OracleDBUtils.getStatement(connection,sqlpartytb);
		ResultSet resultSet2=OracleDBUtils.getStatement(connection,sqlkpdecisiontb);
		ResultSet resultSet3=OracleDBUtils.getStatement(connection,sqlbusdecisiontb);
		ResultSet resultSet4=OracleDBUtils.getStatement(connection,sqlpartyaddrtb);
		ResultSet resultSet5=OracleDBUtils.getStatement(connection,sqlentityaddrtb);
		ResultSet resultSet6=OracleDBUtils.getStatement(connection,sqlbinacctb);
		ResultSet resultSet7=OracleDBUtils.getStatement(connection,sqlreasontb);
		ResultSet resultSet8=OracleDBUtils.getStatement(connection,sqlcontexttb);
		
		int rowcount1=0;
		/*while(resultSetcount.next())
		 {
			rowcount1 = resultSet.getInt("rowcount");
			
		 }*/ 
		
		
		
		
		
		while(resultSet.next())
		 {
			fullName = resultSet.getString("indiv_full_name");
			firstName = resultSet.getString("indiv_first_name");
			middleName = resultSet.getString("indiv_middle_name");
			surName = resultSet.getString("indiv_surname");
			ContactNO = resultSet.getString("contact_no");
			electText = resultSet.getString("elect_addr_text");
			DOB = resultSet.getString("DOB");
			cinCreditGrade = resultSet.getString("cin_credit_grade");
			cinSplCreditGrade = resultSet.getString("cin_spcl_credit_grade");
			cinFraudMarker = resultSet.getString("cin_fraud_marker_code");
			politicallyexposed = resultSet.getString("politically_exposed");
			cinKYC = resultSet.getString("cin_kyc");
			cinRCRMarker = resultSet.getString("cin_rcr_marker");
			kpindex = resultSet.getString("kp_ind");
			countryCode = resultSet.getString("tel_country_code");
		 }
		
		while(resultSet1.next())
		 {
			forecastTurnover = resultSet1.getString("forecast_turnover");
			actualTurnover = resultSet1.getString("actual_turnover");
			binKYC = resultSet1.getString("bin_kyc");
			binCreditGrade = resultSet1.getString("bin_credit_grade");
			binSplCreditGrade = resultSet1.getString("bin_spcl_credit_grade");
			binFraudMarker = resultSet1.getString("bin_fraud_marker_code");
			totAggBusinessDebt = resultSet1.getString("tot_agg_buss_debt");
			binShadowLimit = resultSet1.getString("bin_shadow_limit");
			netProfit = resultSet1.getString("net_profit");
			
		 }
		
		while(resultSet2.next())
		 {
			powercurveID = resultSet2.getString("powercurve_id");
			KPAge = resultSet2.getString("kp_age");
			powercurveKPOutputSequence = resultSet2.getString("powercurve_kp_output_seq");
		 }
		
		while(resultSet3.next())
		 {
			decisionText = resultSet3.getString("decision_text");
			powercurveBusinessOPSeq = resultSet3.getString("powercurve_bus_output_seq");
			affortabilityInd = resultSet3.getString("affordability_ind");
			existingBusMonthlyLoan = resultSet3.getString("existing_bus_monthly_loan_rep");
			existingBusODavDebt = resultSet3.getString("existing_bus_od_av_debit_bal");
			enhancedBLEdecision = resultSet3.getString("enhanced_ble_decision_ind");
			palstrategy = resultSet3.getString("pal_strategy_flag");
		 }
		
		while(resultSet4.next())
		 {
			bin = resultSet4.getString("bin");
			addrCityBI = resultSet4.getString("addr_city");
			countryBI = resultSet4.getString("addr_country");
			AL1BI = resultSet4.getString("addr_line_1_txt");
			AL2BI = resultSet4.getString("addr_line_2_txt");
			AL3BI = resultSet4.getString("addr_line_3_txt");
			AL4BI = resultSet4.getString("addr_line_4_txt");
			AL5BI = resultSet4.getString("addr_line_5_txt");
			postcodeBI = resultSet4.getString("addr_postcode");
			
		 }
		
		while(resultSet5.next())
		 {
			addrCityKP = resultSet5.getString("addr_city");
			countryKP = resultSet5.getString("addr_country");
			AL1KP = resultSet5.getString("addr_line_1_txt");
			AL2KP = resultSet5.getString("addr_line_2_txt");
			AL3KP = resultSet5.getString("addr_line_3_txt");
			AL4KP = resultSet5.getString("addr_line_4_txt");
			AL5KP = resultSet5.getString("addr_line_5_txt");
			postcodeind = resultSet5.getString("addr_postcode");
			postcodeKP = resultSet5.getString("postcode_ind");
			
		 }
		
		while(resultSet6.next())
		 {
			binAccNO = resultSet6.getString("bin_acc_no");
			binSortCode = resultSet6.getString("bin_sort_code");
			companyName = resultSet6.getString("company_name");                                                                                                                                 
			compRegNO = resultSet6.getString("cmpny_reg_no");
			entityType = resultSet6.getString("entity_typ");
			binRCRMArker = resultSet6.getString("bin_rcr_marker");
			
		}
		
		while(resultSet7.next())
		 {
			reasontext = resultSet7.getString("REASON_TEXT");
			
		}
		
		while(resultSet8.next())
		 {
			dbid = resultSet8.getString("dbid");
			
		}
	 rowcount1 =1;
	//dbid = 1
	 DBId = cdb.DBId;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"DB Id",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,dbid,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,DBId,rowcount1,3);
		rowcount1++;
		//full name = 2
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Full Name",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,fullName,rowcount1,2);
		rowcount1++;
		//first name = 3
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"First Name",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,firstName,rowcount1,2);
		rowcount1++;
		//middle name = 4
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Middle Name",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,middleName,rowcount1,2);
		rowcount1++;
		//sur name = 5
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"SurName",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,surName,rowcount1,2);
		rowcount1++;
		//contact number = 6
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Contact No",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,ContactNO,rowcount1,2);
		rowcount1++;
		//elect text = 7
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Elect Text",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,electText,rowcount1,2);
		rowcount1++;
		//DOB = 8
		dob = cdb.DOB;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"DOB",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,DOB,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,dob,rowcount1,3);
		rowcount1++;
		//cin credit grade = 9
		CINCreditGrade = cdb.CINCreditGrade;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CIN creditgrade",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,cinCreditGrade,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,CINCreditGrade,rowcount1,3);
		rowcount1++;
		//cin spl credit grade = 10
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CIN splcreditgrade",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,cinSplCreditGrade,rowcount1,2);
		rowcount1++;
		//cin fraud marker = 11
		FraudMarkerCIN = cdb.FraudMarkerCIN;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CIN Fraud marker",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,cinFraudMarker,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,FraudMarkerCIN,rowcount1,3);
		rowcount1++;
		//PEP = 12
		PEP = cdb.PEP;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Polically Exposed person",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,politicallyexposed,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,PEP,rowcount1,3);
		rowcount1++;
		//cin KYC = 13
		KYCCIN = cdb.KYCCIN;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CIN KYC",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,cinKYC,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,KYCCIN,rowcount1,3);
		rowcount1++;
		//cin rcr marker = 14
		CINCRMMarker = cdb.CINCRMMarker;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CIN RCR marker",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,cinRCRMarker,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,CINCRMMarker,rowcount1,3);
		rowcount1++;
		//kp index = 15
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"KP index",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,kpindex,rowcount1,2);
		rowcount1++;
		//country code = 16
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Country code",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,countryCode,rowcount1,2);
		rowcount1++;
		//forecast turnover = 17 
		projectedturnover = cdb.projectedturnover;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Forecast Turnover",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,forecastTurnover,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,projectedturnover,rowcount1,3);
		rowcount1++;
		//Actual turnover = 18
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Actual Turnover",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,actualTurnover,rowcount1,2);
		rowcount1++;
		//bin KYC = 19
		KYCBIN = cdb.KYCBIN;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN KYC",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binKYC,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,KYCBIN,rowcount1,3);
		rowcount1++;
		//bin credit grade = 20
		BINCreditGrade = cdb.BINCreditGrade;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN CreditGrade",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binCreditGrade,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BINCreditGrade,rowcount1,3);
		rowcount1++;
		//bin splcredit grade = 21
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN splCreditGrade",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binSplCreditGrade,rowcount1,2);
		rowcount1++;
		//bin fraud marker = 22
		FraudMarkerBIN = cdb.FraudMarkerBIN;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN FraudMarker",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binFraudMarker,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,FraudMarkerBIN,rowcount1,3);
		rowcount1++;
		//totAggBusinessDebt = 23
		TotAggBusDebt = cdb.TotAggBusDebt;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"TotAggBusinessDebt",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,totAggBusinessDebt,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,TotAggBusDebt,23,3);
		rowcount1++;
		//bin shadow limit = 24
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN ShadowLimit",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binShadowLimit,rowcount1,2);
		rowcount1++;
		//net profit = 25
		Netprofit = cdb.Netprofit;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Net Profit",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,netProfit,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,Netprofit,rowcount1,3);
		rowcount1++;
		//powercurve id = 26
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Powercurve ID",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,powercurveID,rowcount1,2);
		rowcount1++;
		//KP age = 27
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"KPAge",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,KPAge,rowcount1,2);
		rowcount1++;
		//pc kp o/p = 28
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"PC KPO/P Sequence",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,powercurveKPOutputSequence,rowcount1,2);
		rowcount1++;
		//decision text = 29
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Decision Text",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,decisionText,rowcount1,2);
		rowcount1++;
		//pc bus o/p = 30
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"PC BusO/P Seq",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,powercurveBusinessOPSeq,rowcount1,2);
		rowcount1++;
		//bin = 31
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"bin",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,bin,rowcount1,2);
		rowcount1++;
		//addr city BI = 32
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"addrCity BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,addrCityBI,rowcount1,2);
		rowcount1++;
		//country BI = 33
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Country BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,countryBI,rowcount1,2);
		rowcount1++;
		//AddrLine1 BI = 34
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine1 BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL1BI,rowcount1,2);
		rowcount1++;
		//AddrLine2 BI = 35
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine2 BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL2BI,rowcount1,2);
		rowcount1++;
		//AddrLine3 BI = 36
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine3 BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL3BI,rowcount1,2);
		rowcount1++;
		//AddrLine4 BI = 37
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine4 BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL4BI,rowcount1,2);
		rowcount1++;
		//AddrLine5 BI = 38
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine5 BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL5BI,rowcount1,2);
		rowcount1++;
		//postcode BI = 39
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"PostCode BI",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,postcodeBI,rowcount1,2);
		rowcount1++;
		//AddrCity KP = 40
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrCity KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,addrCityKP,rowcount1,2);
		rowcount1++;
		//country KP = 41
		COR = cdb.COR;
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Country KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,countryKP,rowcount1,2);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,COR,rowcount1,3);
		rowcount1++;
		//AddrLine1 KP = 42
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine1 KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL1KP,rowcount1,2);
		rowcount1++;
		//AddrLine2 KP = 43
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine2 KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL2KP,rowcount1,2);
		rowcount1++;
		//AddrLine3 KP = 44
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine3 KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL3KP,rowcount1,2);
		rowcount1++;
		//AddrLine4 KP = 45
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine4 KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL4KP,rowcount1,2);
		rowcount1++;
		//AddrLine5 KP = 46
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AddrLine5 KP",rowcount1,0);
		ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,AL5KP,rowcount1,2);
		rowcount1++;
		//Postcode ind = 47
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Postcode ind",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,postcodeind,rowcount1,2);
				rowcount1++;
				//PostCode KP = 48
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Postcode KP",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,postcodeKP,rowcount1,2);
				rowcount1++;
				//BIN A/c NO = 49
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN AccNO",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binAccNO,rowcount1,2);
				rowcount1++;
				//BIN Sortcode = 50
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN SortCode",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binSortCode,rowcount1,2);
				rowcount1++;
				//Company Name = 51
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"CompanyName",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,companyName,rowcount1,2);
				rowcount1++;
				//Comp Reg No = 52
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Comp RegNO",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,compRegNO,rowcount1,2);
				rowcount1++;
				//Entity Type = 53
				EntityType = cdb.EntityType;
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"EntityType",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,entityType,rowcount1,2);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,EntityType,rowcount1,3);
				rowcount1++;
				//BIN RCR Marker = 54
				BINCRMMarker = cdb.BINCRMMarker;
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"BIN RCR Marker",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,binRCRMArker,rowcount1,2);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,BINCRMMarker,rowcount1,3);
				rowcount1++;
				//Reason Text = 55
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Reason Text",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,reasontext,rowcount1,2);
				rowcount1++;
				//affortabilityInd = 56
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"AffortabilityInd",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,affortabilityInd,rowcount1,2);
				rowcount1++;
				//existingBusMonthlyLoan = 57
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"ExistingBusMonthlyLoan",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,existingBusMonthlyLoan,rowcount1,2);
				rowcount1++;
				//existingBusODavDebt = 58
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"ExistingBusODavDebt",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,existingBusODavDebt,rowcount1,2);
				rowcount1++;
				//enhancedBLEdecision = 59
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"EnhancedBLEdecision",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,enhancedBLEdecision,rowcount1,2);
				rowcount1++;
				//palstrategy = 60
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,"Pal Strategy",rowcount1,0);
				ExcelUtils.setTestDataRow_BB_Writecredit(sTestDataSheetName,palstrategy,rowcount1,2);
				rowcount1++;
				System.out.println("Credit DB Validation completed sucessfully");
		
		
		
		
	}
	
	                                                                                                                                                                                                                                                                                                                                                                                                   
	public void appIdUpdate(String ApplicationID ,  String sTestName,int rowcount) throws Exception
	{
		
		ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails",sTestName,rowcount,0);
		ExcelUtils.setTestDataRow_BB_Write_appid("AppDetails",ApplicationID,rowcount,1);
		
		
		
		
	}
	public static ResultSet getStatement(final Connection  connection,final String sql) throws Exception
	{
	Statement stmt=null;
	ResultSet resultSet=null;
		try 
		{
		 stmt=connection.createStatement();
		 resultSet=stmt.executeQuery(sql);
		 ReporterA.reportPass("Executing qry " + sql, "Should be executed", "as expected");
		 
		} catch (SQLException e) 
		{
			e.printStackTrace();
			ReporterA.reportFail("Executing qry " + sql, "Should be executed", "as expected");
		}
		return resultSet;
	}
	
	public static void closeConnection(Statement  statement,Connection conn)
	{
		try 
		{
			statement.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void pricingLoanUpdate(String testName, String rowNumber)
	{
		
	}
	
	public void ApplicationDBFetch(String testName, String rowNumber,String sheetname) throws Exception
	//public static void main(String args[]) throws Exception
	{
		Map<String, String> tdRow = ExcelUtils.getTestDataRow_BBConnect(
				sTestDataSheetName, testName);
		
		Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
				pTestDataSheetName, testName);
		
		Map<String, String> tdrRow = ExcelUtils.getTestDataRow_BB(
				rTestDataSheetName, testName);
		Map<String, String> tdqRow = ExcelUtils.getTestDataRow_BB(
				tTestDataSheetName, testName);
		Map<String, String> tdtRow = ExcelUtils.getTestDataRow_BB(
				xTestDataSheetName, testName);
		
		int r=Integer.parseInt(rowNumber);
		 int k=(r*2)+r-1;
		 String loanApp = tdpRow.get("loanApplicable");
		commoncomps.WritevalueToExcel(tdrRow.get("PurpOfBorrowing"),2,k,"Input Vs AppDB","E2E22");
		commoncomps.WritevalueToExcel(tdpRow.get("AmountSliderValue"),3,k,"Input Vs AppDB","E2E22");
		commoncomps.WritevalueToExcel(tdpRow.get("TermSliderValue"),4,k,"Input Vs AppDB","E2E22");
		if(loanApp.equalsIgnoreCase("Yes"))
		{
	    String []scode=Accountdetails.repayscode.split(":");
	    //System.out.println(scode[1]);
	    String sortcod=scode[1].replaceAll("\\s", "");
	   // System.out.println(scode[0]);
		commoncomps.WritevalueToExcel(sortcod,5,k,"Input Vs AppDB","E2E22");
		String []accnumber=Accountdetails.repayaccnumber.split(":");
		//System.out.println(accnumber[1]);
	   // System.out.println(accnumber[0]);
		commoncomps.WritevalueToExcel(accnumber[1],6,k,"Input Vs AppDB","E2E22");
		commoncomps.WritevalueToExcel(tdtRow.get("repaydate"),7,k,"Input Vs AppDB","E2E22");
		}
		else
		{
			for(int i=5;i<=7;i++)
			{
				commoncomps.WritevalueToExcel("NA",i,k,"Input Vs AppDB","E2E22");
			}
		}
		commoncomps.WritevalueToExcel(tdqRow.get("eMail"),8,k,"Input Vs AppDB","E2E22");
		commoncomps.WritevalueToExcel(tdqRow.get("phoneNumber"),9,k,"Input Vs AppDB","E2E22");
		String countrycod="+".concat(tdqRow.get("countrycode"));
		commoncomps.WritevalueToExcel(countrycod,10,k,"Input Vs AppDB","E2E22");
		
		String callback;
		if(tdqRow.get("callBackRequest").equalsIgnoreCase("No"))
		{
		callback="N";
		commoncomps.WritevalueToExcel("NA",12,k,"Input Vs AppDB","E2E22");
		}
		else{
			callback="Y";
			commoncomps.WritevalueToExcel(tdqRow.get("CallBackRequestReason"),12,k,"Input Vs AppDB","E2E22");
		}
		commoncomps.WritevalueToExcel(callback,11,k,"Input Vs AppDB","E2E22");
		
		
		
		if((tdpRow.get("LombardApplicable").equalsIgnoreCase("No"))&&(tdpRow.get("CardsApplicable").equalsIgnoreCase("No")))
		{
			int rownumber = Integer.parseInt(rowNumber);
			String appID=tdRow.get("APPID");
			String bin_cin_sql = "select APPL_ID, DBID, BIN, CIN from LND_APP_OWNER.LND_APPL_DIGITAL_CONTEXT_TB where APPL_ID = '"+appID+"'";
			OracleDBUtils oracleDBUtils=new OracleDBUtils();
			Connection connection=OracleDBUtils.getConnection();
			ResultSet resultSet_bin_cin=OracleDBUtils.getStatement(connection,bin_cin_sql);
			try {
				while(resultSet_bin_cin.next())
				{
					BIN = resultSet_bin_cin.getString("BIN");
					CIN = resultSet_bin_cin.getString("CIN");
				}
			}
			catch ( Exception e)
			{
			System.out.println(e);	
			}
			
		
		//String BIN = tdRow.get("BIN");
		//int bin =Integer.parseInt(BIN);
		String sqlcallback="select CALL_BACK_FLAG,CALL_BACK_REASON from lnd_APP_Owner.LND_APPLICATION_TB ";
		String sql="select a.BORROWING_PURP,a.BORROWING_AMT,a.BOROWWING_TERM,a.SORT_CODE_TO_RECV_FUND,a.ACC_NO_TO_RECV_FUNDS,a.SORT_CODE_TO_REPAY_FUNDS,a.ACC_NO_TO_REPAY_FUNDS,a.REPYMNT_DATE,b.CALL_BACK_FLAG,b.CALL_BACK_REASON,c.TEL_NO,c.ELECT_ADDR_TEXT,c.TEL_COUNTRY_CODE,d.PRC_APR,d.MB_INTEREST_RATE,d.MB_MNTHLY_REPAYMENTS,d.MB_TOTAL_INTERST,d.PRC_TOTAL_REPAY_AMOUNT from LND_APP_OWNER.LND_APPL_FINANCE_TB a LEFT OUTER JOIN LND_APP_OWNER.LND_APPLICATION_TB b ON a.APPL_ID= b.appl_id join lnd_app_owner.LND_ENTITY_INDIV_TB c on a.appl_id=c.appl_id join lnd_app_owner.LND_PRICING_TB d on a.appl_id=d.appl_id where c.CONTACT_PRIORITY='Y' AND a.APPL_ID= '"+appID+"'";
		String sqlOverDraft = "select MB_INTEREST_RATE,PRC_FIN_FEE from lnd_App_owner.LND_PRICING_TB where APPL_ID = '"+appID+"'";
		String sqlBIN = "select BBPAL from lnd_App_owner.LND_BB_RISK_SHADOW_REF where BIN = '"+BIN +"'";
		ResultSet resultSet=OracleDBUtils.getStatement(connection,sql);
		ResultSet resultSetOverDraft=OracleDBUtils.getStatement(connection,sqlOverDraft);
		ResultSet resultBIN=OracleDBUtils.getStatement(connection,sqlBIN);
		
		
			try {
				while(resultSet.next()){
					
					int rownum=resultSet.getRow();
					if(rownum==1)
					{
						
						BorrowingPurpose = resultSet.getString("BORROWING_PURP");
					   	 BorrowingAmount = resultSet.getString("BORROWING_AMT");
					   	 BorrowingTerm= resultSet.getString("BOROWWING_TERM");
					   	SortCodeToReceiveFunds=resultSet.getString("SORT_CODE_TO_RECV_FUND");
					   	AccountNumToReceiveFunds=resultSet.getString("ACC_NO_TO_RECV_FUNDS");
					   	 SortCodeToRepayFunds= resultSet.getString("SORT_CODE_TO_REPAY_FUNDS");
					   	 AccountNumToRepayFunds= resultSet.getString("ACC_NO_TO_REPAY_FUNDS");
					    RepaymentDate= resultSet.getString("REPYMNT_DATE");
					   	 CallBackFlag= resultSet.getString("CALL_BACK_FLAG");
					   	 EMailID= resultSet.getString("ELECT_ADDR_TEXT");
					   	Countrycode= resultSet.getString("TEL_COUNTRY_CODE");
					   	Countrycode="+".concat(Countrycode);
					   	TelephoneNumber= resultSet.getString("TEL_NO");
					   	APR = resultSet.getString("PRC_APR");
					   	InterestRate = resultSet.getString("MB_INTEREST_RATE");
					   	MonthlyPayments = resultSet.getString("MB_MNTHLY_REPAYMENTS");
					   	TotalInterest = resultSet.getString("MB_TOTAL_INTERST");
					   TotalRepayments = resultSet.getString("PRC_TOTAL_REPAY_AMOUNT");
					   //Preferredcontactno=resultSet.getString("PREFERRED_CONTACT_NO");
					   callbackreason=resultSet.getString("CALL_BACK_REASON");
					            /*System.out.println("EMailID: "+ EMailID);
			   			        System.out.println("TelephoneNumber: "+ TelephoneNumber);
			   			        System.out.println("Countrycode: "+Countrycode);
					   			System.out.println("BorrowingPurpose: "+BorrowingPurpose);
					   			System.out.println("BorrowingAmount: "+BorrowingAmount);
					   			System.out.println("CallBackFlag: "+CallBackFlag);*/
					   			
				//System.out.println("Details fetched");
				
				}
			}
				if(loanApp.equalsIgnoreCase("No"))
				{
				while(resultSetOverDraft.next()){
					
						interestRate = resultSetOverDraft.getString("MB_INTEREST_RATE");
					   	 Fee = resultSetOverDraft.getString("PRC_FIN_FEE");
					
				}
				}
				
			while(resultBIN.next()){
					
					ShadowLimit = resultBIN.getString("BBPAL");
				   	 
					
			}
							
				            
				           int j=(r*2)+r;
				          
				           
					        String PreContractInfo = Accountdetails.preContractInformationText;
							commoncomps.WritevalueToExcel(BorrowingPurpose,2,j,"Input Vs AppDB","E2E22");
							commoncomps.WritevalueToExcel(BorrowingAmount,3,j,"Input Vs AppDB","E2E22");
							commoncomps.WritevalueToExcel(BorrowingTerm,4,j,"Input Vs AppDB","E2E22");
							if(loanApp.equalsIgnoreCase("Yes"))
							{
								commoncomps.WritevalueToExcel(SortCodeToRepayFunds,5,j,"Input Vs AppDB","E2E22");
								commoncomps.WritevalueToExcel(AccountNumToRepayFunds,6,j,"Input Vs AppDB","E2E22");
								AccountNumToRepayFunds=StringUtils.right(AccountNumToRepayFunds, 4);
								//System.out.println(AccountNumToRepayFunds);
								commoncomps.WritevalueToExcel(RepaymentDate,7,j,"Input Vs AppDB","E2E22");
							}
							else
							{
								for(int i=5;i<=7;i++)
								{
									commoncomps.WritevalueToExcel("NA",i,j,"Input Vs AppDB","E2E22");
								}
							}
						
							commoncomps.WritevalueToExcel(EMailID,8,j,"Input Vs AppDB","E2E22");
							commoncomps.WritevalueToExcel(TelephoneNumber,9,j,"Input Vs AppDB","E2E22");
							commoncomps.WritevalueToExcel(Countrycode,10,j,"Input Vs AppDB","E2E22");
							if(CallBackFlag.equalsIgnoreCase("N"))
							{
								
								commoncomps.WritevalueToExcel("NA",12,j,"Input Vs AppDB","E2E22");
							}
							else{
								commoncomps.WritevalueToExcel(callbackreason,12,j,"Input Vs AppDB","E2E22");
							}
							commoncomps.WritevalueToExcel(CallBackFlag,11,j,"Input Vs AppDB","E2E22");
							
							
							
						    int zd= (((r-1)*4)+1)+3-1;
					           int ddb= (((r-1)*4)+2)+3-1;
					           int Ed = (((r-1)*4)+3)+3-1;
							
					           if(loanApp.equalsIgnoreCase("Yes"))
					        		   {
					        	   if(!(PersonaliseYourQuote.APR.equalsIgnoreCase("Not Applicable")))
					    		   {
					        		   String expapr=new Double(ExcelUtils.APR).toString();   
					           commoncomps.WritevalueToExcel(expapr,2,Ed,"Zambesi Vs AppDB","E2E22");
					           String rate=commoncomps.Formatdecimalsingle(APR);
					           commoncomps.WritevalueToExcel(rate,2,ddb,"Zambesi Vs AppDB","E2E22");
					           
					    		   }
					        	   else
					        	   {
					        		   commoncomps.WritevalueToExcel("NA",2,ddb,"Zambesi Vs AppDB","E2E22");  
					        	   }
					        	   
					           commoncomps.WritevalueToExcel(InterestRate,3,ddb,"Zambesi Vs AppDB","E2E22");
					           String exprate=new Double(ExcelUtils.rate).toString(); 
					           commoncomps.WritevalueToExcel(exprate,3,Ed,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(MonthlyPayments,4,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(PersonaliseYourQuote.expMonthlyrepayment,4,Ed,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(TotalInterest,5,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel("NA",5,Ed,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(TotalRepayments,6,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(PersonaliseYourQuote.expTotalrepayment,6,Ed,"Zambesi Vs AppDB","E2E22");
					           for(int i=7;i<=10;i++)
					           {
					        	   commoncomps.WritevalueToExcel("NA",i,ddb,"Zambesi Vs AppDB","E2E22");  
					        	   commoncomps.WritevalueToExcel("NA",i,Ed,"Zambesi Vs AppDB","E2E22");  
					           }
					        		   }
					           else
					           {
					        	   for(int i=2;i<=6;i++)
						           {
						        	   commoncomps.WritevalueToExcel("NA",i,ddb,"Zambesi Vs AppDB","E2E22");  
						        	   commoncomps.WritevalueToExcel("NA",i,Ed,"Zambesi Vs AppDB","E2E22"); 
						           }
					        	   interestRate=commoncomps.Formatdecimal(interestRate);
					           commoncomps.WritevalueToExcel(interestRate,7,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(PersonaliseYourQuote.expinterestrate,7,Ed,"Zambesi Vs AppDB","E2E22");
					           BorrowingAmount=commoncomps.Formatamount(BorrowingAmount);
					           commoncomps.WritevalueToExcel(BorrowingAmount,8,ddb,"Zambesi Vs AppDB","E2E22");		
					           commoncomps.WritevalueToExcel(BorrowingAmount,8,Ed,"Zambesi Vs AppDB","E2E22");	
					           Fee=commoncomps.Formatdecimal(Fee);
					           commoncomps.WritevalueToExcel(Fee,9,ddb,"Zambesi Vs AppDB","E2E22");
					           String expfee=new Double(PersonaliseYourQuote.arrangementfee).toString();
					           String expfeeformat=commoncomps.Formatdecimal(expfee);
					           commoncomps.WritevalueToExcel(expfeeformat,9,Ed,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(BorrowingTerm,10,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(BorrowingTerm,10,Ed,"Zambesi Vs AppDB","E2E22");
					           }
					           commoncomps.WritevalueToExcel(ShadowLimit,11,ddb,"Zambesi Vs AppDB","E2E22");
					           commoncomps.WritevalueToExcel(ShadowLimit,11,Ed,"Zambesi Vs AppDB","E2E22");
			}
		
		catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	      
	
	public void ApplicationDBFetchforPricing(String testName, String rownumb) throws Exception
	//public static void main(String args[]) throws Exception
	{
		Map<String, String> tdRow = ExcelUtils.getTestDataRow_BBConnect(
				sTestDataSheetName, testName);
		
		
		String appID=tdRow.get("Application_ID");
		
		String sql="select a.BORROWING_PURP,a.BORROWING_AMT,a.BOROWWING_TERM from LND_APP_OWNER.LND_APPL_FINANCE_TB a where a.APPL_ID= '"+appID+"'";
		OracleDBUtils oracleDBUtils=new OracleDBUtils();
		Connection connection=OracleDBUtils.getConnection();
		ResultSet resultSet=OracleDBUtils.getStatement(connection,sql);
		
			try {
				while(resultSet.next()){
					
					int rownum=resultSet.getRow();
					
					//System.out.println(rownum);
						
						BorrowingPurpose = resultSet.getString("BORROWING_PURP");
					   	 BorrowingAmount = resultSet.getString("BORROWING_AMT");
					   	 BorrowingTerm= resultSet.getString("BOROWWING_TERM");
					   /*	System.out.println(BorrowingPurpose);
					   	System.out.println(BorrowingAmount);
				        System.out.println(BorrowingTerm);*/
				
				
				}
			
				String sname = System.getProperty("user.dir") + "\\testdata\\PricingValues.xls";
				FileInputStream fis = new FileInputStream(sname);
					 wb = new HSSFWorkbook(fis);
					HSSFSheet sh = wb.getSheet("PricingValues");
					int rowNumber = Integer.parseInt(rownumb);
					Row row = sh.getRow(rowNumber);
					
					Cell cell = row.createCell(1);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cell.setCellValue(BorrowingPurpose);
					
					cell = row.createCell(2);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cell.setCellValue(BorrowingAmount);
					
					cell = row.createCell(3);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cell.setCellValue(BorrowingTerm);
				
					FileOutputStream fos = new FileOutputStream(sname);
					wb.write(fos);
					fos.close();
					System.out.println("Excel file written");
						
	        
	      }
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}



public void LombardcardURLUpdate(String testName,String rowNumber, String sheetname) throws IOException
{
	Map<String, String> tdpRow = ExcelUtils.getTestDataRow_BB(
			pTestDataSheetName, testName);

	int rownum = Integer.parseInt(rowNumber);
	if((tdpRow.get("LombardApplicable").equalsIgnoreCase("Yes"))||(tdpRow.get("CardsApplicable").equalsIgnoreCase("Yes")))
	{
		commoncomps.WritevalueToExcel(pyq.LombardCardURL,rownum ,2,"Lombard_Card_URL",sheetname);
	/*System.out.println("Lombard/CArd URL: "+pyq.LombardCardURL);
	System.out.println("Excel file written with lombard card values");*/
	}
}

public void IneligUpdate(String testName,String rowNumber,String sheetname) throws IOException
{
	
	int rownum = Integer.parseInt(rowNumber);
	commoncomps.WritevalueToExcel(BBConnectUtils.URL,rownum ,2,"Ineligcust",sheetname);
	/*System.out.println("URL retrived is: "+ BBConnectUtils.URL);
	System.out.println("Excel file written with lombard card values");*/
	
}

public void feederAccountURL(String testName,String rowNumber,String sheetname) throws IOException
{
	
	int rownum = Integer.parseInt(rowNumber);
	String feederURL = FeederAccount.URL;
	commoncomps.WritevalueToExcel(feederURL,rownum ,2,"FeederAccount_URL",sheetname);
	/*System.out.println("URL retrived is: "+ BBConnectUtils.URL);
	System.out.println("Excel file written with feeder account URL");*/
	
}
}


  