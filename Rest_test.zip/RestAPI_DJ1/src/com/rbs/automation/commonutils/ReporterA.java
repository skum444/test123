package com.rbs.automation.commonutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.xerces.dom.ProcessingInstructionImpl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.rbs.bpm.automation.bbconnect.objects.Step;
import com.rbs.bpm.automation.bbconnect.objects.TestCase;

public class ReporterA {

	static HashMap<TestCase, List<Step>> testReporter;
	// private static String currentTestName;
	private static TestCase currentTest;
	private static int iteration;
	private static String batchreportDir;
	private static String batchreportDirss;
	private static String batchreportXmlDir;
	private static String currentTestReportDir;
	private static String currentTestreportXmlDir;
	private static String currentTestreportSnapshotDir;
	private static String batchreportXmlDirss;
	private static String currentTestReportDirss;
	private static String currentTestreportXmlDirss;
	private static String currentTestreportSnapshotDirss;
	public static String setpagename;

	public static void initReporter(String scename) {
		testReporter = new LinkedHashMap<TestCase, List<Step>>();
		//System.out.println("inside init reporter");

		// set batch result dir
		createNewBatchResultFolder(scename);
		//createNewBatchResultFolderSS(scename);
	}

	private static void createNewBatchResultFolder(String scename) {
		// create new folder
		batchreportDir = GenericUtils.getProperty("ReportFolderPath") + "\\"+scename+"_Batch_" + GenericUtils.getDateTime();
		//batchreportXmlDir = batchreportDir + "\\xml";

		new File(batchreportDir).mkdirs();
		//new File(batchreportXmlDir).mkdirs();
		
		/*//copy xsl to xml dir 
		File source = new File(GenericUtils.getProperty("xmlStyleSheetPath"));
		File dest = new File(batchreportXmlDir);
		try {
			FileUtils.copyFileToDirectory(source, dest );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	
	//for specific screnn shots
	private static void createNewBatchResultFolderSS(String scename) {
		// create new folder
		batchreportDirss = GenericUtils.getProperty("ReportFolderPath") + "\\"+scename+"Specific_Batch_" + GenericUtils.getDateTime();
		batchreportXmlDir = batchreportDirss + "\\xml";

		new File(batchreportDirss).mkdirs();
		new File(batchreportXmlDir).mkdirs();
		
		//copy xsl to xml dir 
		File source = new File(GenericUtils.getProperty("xmlStyleSheetPath"));
		File dest = new File(batchreportXmlDir);
		try {
			FileUtils.copyFileToDirectory(source, dest );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void initTest(TestCase currentTest) {

		List<Step> sFirst = new ArrayList<Step>();

		currentTest.setIteration(iteration);

		if (testReporter.containsKey(currentTest)) {
			// sFirst = new ArrayList<Step>();
			// store the name
			String testName = currentTest.getName() + "_" + iteration;
			String testDesc = currentTest.getDescription();
			String startTime = currentTest.getStartTime();
			String browser = currentTest.getBrowser();

			currentTest = new TestCase();

			currentTest.setName(testName);
			currentTest.setDescription(testDesc);
			currentTest.setStartTime(startTime);
			currentTest.setBrowser(browser);

			iteration = iteration + 1;
			testReporter.put(currentTest, sFirst);

		} else {
			testReporter.put(currentTest, sFirst);
		}

		ReporterA.currentTest = currentTest;

		if (currentTest.getE2eSetName().startsWith("AUT_E2E_")) {

			String E2EDir = batchreportDir  + "\\" + currentTest.getE2eSetName()+ "\\" + currentTest.getName();
			new File(E2EDir).mkdirs();
			currentTestReportDir = E2EDir;

		} else {
			currentTestReportDir = batchreportDir + "\\" + currentTest.getName();
			
		}

		//currentTestreportXmlDir = currentTestReportDir + "\\xml";
		currentTestreportSnapshotDir = currentTestReportDir + "\\snapshots";

		currentTest.setResultFolder(currentTestReportDir);

		new File(currentTest.getResultFolder()).mkdirs();
		//new File(currentTestreportXmlDir).mkdirs();
		new File(currentTestreportSnapshotDir).mkdirs();

	}
// for specific ss
	public static void initTestss(TestCase currentTest) {

		List<Step> sFirst = new ArrayList<Step>();

		currentTest.setIteration(iteration);

		if (testReporter.containsKey(currentTest)) {
			// sFirst = new ArrayList<Step>();
			// store the name
			String testName = currentTest.getName() + "_" + iteration;
			String testDesc = currentTest.getDescription();
			String startTime = currentTest.getStartTime();
			String browser = currentTest.getBrowser();

			currentTest = new TestCase();

			currentTest.setName(testName);
			currentTest.setDescription(testDesc);
			currentTest.setStartTime(startTime);
			currentTest.setBrowser(browser);

			iteration = iteration + 1;
			testReporter.put(currentTest, sFirst);

		} else {
			testReporter.put(currentTest, sFirst);
		}

		ReporterA.currentTest = currentTest;

			currentTestReportDirss = batchreportDirss + "\\" + currentTest.getName();
	
		

		currentTestreportXmlDirss = currentTestReportDirss + "\\xml";
		currentTestreportSnapshotDirss = currentTestReportDirss + "\\snapshots";

		currentTest.setResultFolder(currentTestReportDir);

		new File(currentTest.getResultFolder()).mkdirs();
		new File(currentTestreportXmlDirss).mkdirs();
		new File(currentTestreportSnapshotDirss).mkdirs();

	}

	
	
	public static void reportPass(String sStepDesc, String sExpected, String sActual) {
		Logger.LogMessage(sStepDesc);
		Logger.LogMessage(sExpected);
		Logger.LogMessage(sActual);
		
		/*if( null ==currentTest.getStatus()  || ! currentTest.getStatus().equalsIgnoreCase("Failed"))
		{
		currentTest.setStatus("Passed");
		}

		addStep(currentTest, sStepDesc, "Passed", sExpected, sActual, "");*/
	}

    public static void reportPassWithSnapshot(String sStepDesc, String sExpected, String sActual, WebDriver driver) {

        Logger.LogMessage(sStepDesc);
        Logger.LogMessage(sExpected);
        Logger.LogMessage(sActual);

        Logger.LogMessage("Status Before" + currentTest.getStatus());

        if (null == currentTest.getStatus() || !currentTest.getStatus().equalsIgnoreCase("Failed")) {
              currentTest.setStatus("Passed");
        }

        /*
        * if (!currentTest.getStatus().equalsIgnoreCase("Failed")) {
        * currentTest.setStatus("Passed"); }
        * 
         */

        Logger.LogMessage("Status After" + currentTest.getStatus());

        String snapshotFileName = currentTestreportSnapshotDir + "\\" + currentTest.getName() + "~"
                    + GenericUtils.getDateTime() + ".png";
        addStep(currentTest, sStepDesc, "Passed", sExpected, sActual,
                    GenericUtils.captureScreen(driver, snapshotFileName));
        try {
              if ((sExpected.contains("Continue")) || (sExpected.contains("Login")) || (sExpected.contains("Get started"))
                          || (sExpected.contains("Get quote")) || (sExpected.contains("Choose a loan"))
                          || (sExpected.contains("Choose an overdraft")) || (sExpected.contains("Confirm")) || (sExpected.contains("Confirm"))
                          || ((sExpected.contains("Read & sign your agreement")) || (sExpected.contains("Close"))
                                      || (sExpected.contains("Acknowledge Receipt")) || (sExpected.contains("Start"))
                                      || (sExpected.contains("Exit")) || (sExpected.contains("Download a copy"))
                                      || (sExpected.contains("Accept")) || (sExpected.contains("Log in"))
                                      || (sExpected.contains("Apply")) || (sExpected.contains("Claim"))                                     
                                      || (sExpected.contains("Sign")) || (sExpected.contains("Close"))
                                      || (sExpected.contains("Next"))|| (sExpected.contains("form-control signerName"))
                                      || (sExpected.contains("View documents")) || (sExpected.contains("Thank you"))
                                      || (sExpected.contains("signbutton"))|| (sExpected.contains("Apply"))|| (sExpected.contains("Confirm")))) {
                    wordDoc(currentTestreportSnapshotDir,
                                GenericUtils.fullScreenCapture(driver, snapshotFileName, currentTestreportSnapshotDir));
              } else if ((sExpected.contains("Ok")|| (sExpected.contains("Yes")) || (sExpected.contains("No")))) {
                    wordDoc(currentTestreportSnapshotDir, GenericUtils.captureScreen(driver, snapshotFileName));
              }
        } catch (InvalidFormatException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
        } catch (FileNotFoundException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
        } catch (IOException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
        }
  }

	public static void wordDoc(String path, String sSnapshotPath)
			throws InvalidFormatException, FileNotFoundException, IOException {

		String filePath = path.substring(0, path.lastIndexOf('\\'));
		String filePath1 = path.substring(0, filePath.lastIndexOf('\\'));
		String fileName = FilenameUtils.getBaseName(filePath1);

		File f = new File(filePath1 + "\\" + fileName + ".docx");
		XWPFDocument docum;
		if (f.exists()) {
			FileInputStream fis = new FileInputStream(f);
			OPCPackage pkg = OPCPackage.open(fis);
			docum = new XWPFDocument(pkg);
		} else {
			docum = new XWPFDocument();
		}

		XWPFParagraph p = docum.createParagraph();
		XWPFRun r = p.createRun();
		r.addBreak();
		r.addPicture(new FileInputStream(sSnapshotPath), XWPFDocument.PICTURE_TYPE_JPEG, "name", Units.toEMU(450),
				Units.toEMU(300));

		FileOutputStream out = new FileOutputStream(f);
		docum.write(out);
		out.close();
	}
	public static void reportPassWithSnapshotss(String sStepDesc, String sExpected, String sActual, WebDriver driver) {

		Logger.LogMessage(sStepDesc);
		Logger.LogMessage(sExpected);
		Logger.LogMessage(sActual);

		Logger.LogMessage("Status Before" + currentTest.getStatus());

		if( null== currentTest.getStatus()  || ! currentTest.getStatus().equalsIgnoreCase("Failed"))
		{
			currentTest.setStatus("Passed");
		}
		
		/*if (!currentTest.getStatus().equalsIgnoreCase("Failed")) {
			currentTest.setStatus("Passed");
		}
		
		*/
		
		Logger.LogMessage("Status After" + currentTest.getStatus());
				
		
		String snapshotFileName = currentTestreportSnapshotDirss + "\\" + currentTest.getName() + "~"
				+ GenericUtils.getDateTime() + ".png";
		addStep(currentTest, sStepDesc, "Passed", sExpected, sActual,
				GenericUtils.captureScreen(driver, snapshotFileName));
	}

	public static void reportFail(String sStepDesc, String sExpected, String sActual) throws Exception {
		Logger.LogMessage(sStepDesc);
		Logger.LogMessage(sExpected);
		Logger.LogMessage(sActual);

		currentTest.setStatus("Failed");
		addStep(currentTest, sStepDesc, "Failed", sExpected, sActual, "");
		throw new Exception("Step failed  " + sStepDesc + " || Expected => " + sExpected + " || Actual => " + sActual);

	}

	public static void reportFailWithSnapshot(String sStepDesc, String sExpected, String sActual, WebDriver driver)
			throws Exception {

		Logger.LogMessage(sStepDesc);
		Logger.LogMessage(sExpected);
		Logger.LogMessage(sActual);

		currentTest.setStatus("Failed");

		String snapshotFileName = currentTestreportSnapshotDir + "\\" + currentTest.getName()
				+ GenericUtils.getDateTime();
		addStep(currentTest, sStepDesc, "Failed", sExpected, sActual,
				GenericUtils.captureScreen(driver, snapshotFileName));

		try {
			throw new Exception("Step failed  " + sStepDesc + " || Expected => " + sExpected + " || Actual => " + sActual);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void addStep(TestCase sCallerTest, String sStepDesc, String sStatus, String sExpected,
			String sActual, String sSnapshotPath) {
		if (testReporter.containsKey(sCallerTest)) {
			List<Step> sList = testReporter.get(sCallerTest);
			sList.add(new Step(sStepDesc, sStatus, sExpected, sActual, sSnapshotPath));
		} else {
			List<Step> sList = new ArrayList<Step>();
			sList.add(new Step(sStepDesc, sStatus, sExpected, sActual, sSnapshotPath));
			testReporter.put(sCallerTest, sList);
		}
	}

	public static void saveBatchResultsToXML() {

		// String xmlResultsFolder =
		// GenericUtils.getProperty("xmlReportFolderPath");
		// String htmlResultsFolder =
		// GenericUtils.getProperty("htmlReportFolderPath");
		//
		String xmlResultsFolder = batchreportXmlDir;
		String htmlResultsFolder = batchreportDir;

		// String xmlResultsFileXML = xmlResultsFolder + "\\Results" +
		// GenericUtils.getDateTime() + ".xml";
		// String xmlResultsFileHTML = htmlResultsFolder + "\\Results" +
		// GenericUtils.getDateTime() + ".html";

		String xmlResultsFileXML = xmlResultsFolder + "\\Results.xml";
		String xmlResultsFileHTML = htmlResultsFolder + "\\Results.html";

		org.w3c.dom.Document doc = null;
		String xslPath = GenericUtils.getProperty("xmlStyleSheetPath");

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			doc = docBuilder.newDocument();

			// add stylessheet
			// ProcessingInstructionImpl pi = (ProcessingInstructionImpl)
			// doc.createProcessingInstruction("xml-stylesheet",
			// "type=\"text/xsl\" href=\"" + xslPath + "\"");

			Element rootElement = doc.createElement("Tests");
			doc.appendChild(rootElement);

			Element root = doc.getDocumentElement();
			// doc.insertBefore((Node) pi, root);

			Iterator<Map.Entry<TestCase, List<Step>>> entries = testReporter.entrySet().iterator();

			while (entries.hasNext()) {
				Map.Entry<TestCase, List<Step>> test = entries.next();

				// add test node
				Element testElement = doc.createElement("Test");
				rootElement.appendChild(testElement);

				Attr testAttr = doc.createAttribute("Name");
				testAttr.setValue(test.getKey().getName());
				testElement.setAttributeNode(testAttr);
				
				testAttr = doc.createAttribute("E2ESetName");
				testAttr.setValue(test.getKey().getE2eSetName());
				testElement.setAttributeNode(testAttr);
				
				testAttr = doc.createAttribute("id");
				testAttr.setValue(test.getKey().getE2eSetName()+"."+test.getKey().getName());
				testElement.setAttributeNode(testAttr);

				testAttr = doc.createAttribute("Description");
				testAttr.setValue(test.getKey().getDescription());
				testElement.setAttributeNode(testAttr);

				testAttr = doc.createAttribute("Status");
				testAttr.setValue(test.getKey().getStatus());
				testElement.setAttributeNode(testAttr);

				testAttr = doc.createAttribute("Browser");
				testAttr.setValue(test.getKey().getBrowser());
				testElement.setAttributeNode(testAttr);

				// read for each iteration if test iteration =1

				// add steps now
				List<Step> lstStep = test.getValue();

				for (Step step : lstStep) {

					Element stepElement = doc.createElement("Step");
					testElement.appendChild(stepElement);

					Attr stepAttr = doc.createAttribute("Desc");
					stepAttr.setValue(step.getsDesc());
					stepElement.setAttributeNode(stepAttr);

					stepAttr = doc.createAttribute("Status");
					stepAttr.setValue(step.getsStatus());
					stepElement.setAttributeNode(stepAttr);

					stepAttr = doc.createAttribute("Expected");
					stepAttr.setValue(step.getsExpected());
					stepElement.setAttributeNode(stepAttr);

					stepAttr = doc.createAttribute("Actual");
					stepAttr.setValue(step.getsActual());
					stepElement.setAttributeNode(stepAttr);

					int sSnapshot = step.getsSnapshotPath().indexOf(currentTestreportSnapshotDir);

					stepAttr = doc.createAttribute("Snapshot");

					String snapshotRelPath = "";
					if (step.getsSnapshotPath().length() > 0) {
						snapshotRelPath = step.getsSnapshotPath().substring(batchreportDir.length() + 1);
					}

					stepAttr.setValue(snapshotRelPath);
					stepElement.setAttributeNode(stepAttr);

					// stepAttr.setValue(step.getsSnapshotPath());
					// stepElement.setAttributeNode(stepAttr);

					stepAttr = doc.createAttribute("ExecutedAt");
					stepAttr.setValue(step.getsExecutionTimestamp());
					stepElement.setAttributeNode(stepAttr);

				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(xmlResultsFileXML));
			transformer.transform(source, result);

			Source xslDoc = new StreamSource(xslPath);
			Source xmlDoc = new StreamSource(xmlResultsFileXML);

			OutputStream htmlFile = new FileOutputStream(xmlResultsFileHTML);
			Transformer trasform = transformerFactory.newTransformer(xslDoc);
			trasform.transform(xmlDoc, new StreamResult(htmlFile));

			Logger.LogMessage("Results Saved (xml)  :: " + xmlResultsFileXML);
			Logger.LogMessage("Results Saved (html) :: " + xmlResultsFileHTML);

		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void saveTestResultsToXML() {
		org.w3c.dom.Document doc = null;
		String xslPath = GenericUtils.getProperty("xmlStyleSheetPath");

		String xmlResultsFileXML = currentTestreportXmlDir + "\\Results" + ".xml";
		String xmlResultsFileHTML = currentTestReportDir + "\\Results" + ".html";
	

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			doc = docBuilder.newDocument();

			// add stylessheet
			ProcessingInstructionImpl pi = (ProcessingInstructionImpl) doc.createProcessingInstruction("xml-stylesheet",
					"type=\"text/xsl\" href=\"" + xslPath + "\"");

			Element rootElement = doc.createElement("Tests");
			doc.appendChild(rootElement);

			Element root = doc.getDocumentElement();
			doc.insertBefore((Node) pi, root);

			// add test node
			Element testElement = doc.createElement("Test");
			rootElement.appendChild(testElement);

			Attr testAttr = doc.createAttribute("Name");
			testAttr.setValue(currentTest.getName());
			testElement.setAttributeNode(testAttr);
			
			testAttr = doc.createAttribute("E2ESetName");
			testAttr.setValue(currentTest.getE2eSetName());
			testElement.setAttributeNode(testAttr);
			
			testAttr = doc.createAttribute("id");
			testAttr.setValue(currentTest.getE2eSetName()+"."+currentTest.getName());
			testElement.setAttributeNode(testAttr);

			testAttr = doc.createAttribute("Description");
			testAttr.setValue(currentTest.getDescription());
			testElement.setAttributeNode(testAttr);

			testAttr = doc.createAttribute("Status");
			testAttr.setValue(currentTest.getStatus());
			testElement.setAttributeNode(testAttr);

			testAttr = doc.createAttribute("Browser");
			testAttr.setValue(currentTest.getBrowser());
			testElement.setAttributeNode(testAttr);

			List<Step> steps = testReporter.get(currentTest);
			for (Step step : steps) {

				Element stepElement = doc.createElement("Step");
				testElement.appendChild(stepElement);

				Attr stepAttr = doc.createAttribute("Desc");
				stepAttr.setValue(step.getsDesc());
				stepElement.setAttributeNode(stepAttr);

				stepAttr = doc.createAttribute("Status");
				stepAttr.setValue(step.getsStatus());
				stepElement.setAttributeNode(stepAttr);

				stepAttr = doc.createAttribute("Expected");
				stepAttr.setValue(step.getsExpected());
				stepElement.setAttributeNode(stepAttr);

				stepAttr = doc.createAttribute("Actual");
				stepAttr.setValue(step.getsActual());
				stepElement.setAttributeNode(stepAttr);

				stepAttr = doc.createAttribute("Snapshot");
				// stepAttr.setValue(step.getsSnapshotPath());

				String snapshotRelPath = "";
				if (step.getsSnapshotPath().length() > 0) {
					snapshotRelPath = step.getsSnapshotPath().substring(currentTestReportDir.length() + 1);
				}

				stepAttr.setValue(snapshotRelPath);
				stepElement.setAttributeNode(stepAttr);

				stepAttr = doc.createAttribute("ExecutedAt");
				stepAttr.setValue(step.getsExecutionTimestamp());
				stepElement.setAttributeNode(stepAttr);

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			StreamResult result = new StreamResult(new File(xmlResultsFileXML));
			transformer.transform(source, result);

			Source xslDoc = new StreamSource(xslPath);
			Source xmlDoc = new StreamSource(xmlResultsFileXML);

			OutputStream htmlFile = new FileOutputStream(xmlResultsFileHTML);
			Transformer trasform = transformerFactory.newTransformer(xslDoc);
			trasform.transform(xmlDoc, new StreamResult(htmlFile));

			Logger.LogMessage("Results Saved (xml)  :: " + xmlResultsFileXML);
			Logger.LogMessage("Results Saved (html) :: " + xmlResultsFileHTML);

		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void reportInfo(String sStepDesc, String sExpected, String sActual) {
		Logger.LogMessage(sStepDesc);
		Logger.LogMessage(sExpected);
		Logger.LogMessage(sActual);

		currentTest.setStatus("Done");
		addStep(currentTest, sStepDesc, "Done", sExpected, sActual, "");

	}

	public static void reportPassWithSnapshot(String sStepDesc, String sExpected, String sActual, WebDriver driver,
			By locator) throws Exception {
		if (null != driver.findElements(locator).get(0)) {
			reportPassWithSnapshot(sStepDesc, sExpected, sActual, driver);
		} else {
			reportFailWithSnapshot(sStepDesc, sExpected, sActual, driver);
		}

	}

}
